/**
 * Netlify Serverless Function: POST /api/audit
 * Manjankal Mar Shemavoon Desthuni Orthodox Syrian Church - 2026 Festival Accounts
 */

import { initializeApp, getApps } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore } from 'firebase-admin/firestore';

const SUPER_ADMIN_EMAIL = 'jijopjohn@gmail.com';

function initFirebase() {
  const projectId = process.env.FIREBASE_PROJECT_ID || process.env.GCLOUD_PROJECT;
  if (getApps().length === 0 && projectId) {
    try {
      initializeApp({ projectId });
    } catch (e) {
      console.warn('Firebase Admin init notice:', e);
    }
  }
}

export interface NetlifyEvent {
  httpMethod: string;
  headers: Record<string, string | undefined>;
  body: string | null;
}

export interface NetlifyResponse {
  statusCode: number;
  headers?: Record<string, string>;
  body: string;
}

export const handler = async (event: NetlifyEvent): Promise<NetlifyResponse> => {
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 204,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
      },
      body: '',
    };
  }

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'METHOD_NOT_ALLOWED' }),
    };
  }

  const authHeader = event.headers.authorization || event.headers.Authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return {
      statusCode: 401,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'UNAUTHORIZED', message: 'Missing Bearer token' }),
    };
  }

  const token = authHeader.split('Bearer ')[1]?.trim();
  initFirebase();

  try {
    const auth = getAuth();
    const decoded = await auth.verifyIdToken(token, true);

    if (
      !decoded.email ||
      decoded.email.toLowerCase() !== SUPER_ADMIN_EMAIL.toLowerCase() ||
      !decoded.email_verified
    ) {
      return {
        statusCode: 403,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'FORBIDDEN', message: 'Unauthorized' }),
      };
    }

    const payload = JSON.parse(event.body || '{}');
    const { action, summaryMl, amount, details } = payload;

    if (!action || !summaryMl) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'INVALID_PAYLOAD', message: 'Action and summaryMl required' }),
      };
    }

    const db = getFirestore();
    const nowIso = new Date().toISOString();
    const logId = `audit_srv_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

    await db.collection('festivals').doc('2026').collection('audit_logs').doc(logId).set({
      id: logId,
      operationId: 'administrative-event',
      timestamp: nowIso,
      userEmail: SUPER_ADMIN_EMAIL,
      action,
      entityType: 'SECURITY',
      entityId: action,
      summaryMl: String(summaryMl).slice(0, 300),
      ...(typeof amount === 'number' && amount >= 0 ? { amount: Math.round(amount) } : {}),
      ...(details ? { details } : {}),
    });

    return {
      statusCode: 201,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ success: true, logId }),
    };
  } catch (err: any) {
    return {
      statusCode: 401,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'AUDIT_FAILED', message: err.message }),
    };
  }
};
