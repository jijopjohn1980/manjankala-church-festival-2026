/**
 * Netlify Serverless Function: POST /api/auth/bootstrap
 * Manjankal Mar Shemavoon Desthuni Orthodox Syrian Church - 2026 Festival Accounts
 */

import { initializeApp, getApps } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';

const SUPER_ADMIN_EMAIL = 'jijopjohn@gmail.com';

function initFirebase() {
  const projectId = process.env.FIREBASE_PROJECT_ID || process.env.GCLOUD_PROJECT;
  if (getApps().length === 0 && projectId) {
    try {
      initializeApp({ projectId });
    } catch (e) {
      console.warn('Firebase Admin init notice:', e);
    }
  }
}

export interface NetlifyEvent {
  httpMethod: string;
  headers: Record<string, string | undefined>;
  body: string | null;
}

export interface NetlifyResponse {
  statusCode: number;
  headers?: Record<string, string>;
  body: string;
}

export const handler = async (event: NetlifyEvent): Promise<NetlifyResponse> => {
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 204,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
      },
      body: '',
    };
  }

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'METHOD_NOT_ALLOWED' }),
    };
  }

  const authHeader = event.headers.authorization || event.headers.Authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return {
      statusCode: 401,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'UNAUTHORIZED', message: 'Missing Bearer token' }),
    };
  }

  const token = authHeader.split('Bearer ')[1]?.trim();
  initFirebase();

  try {
    const auth = getAuth();
    const decoded = await auth.verifyIdToken(token, true);

    if (!decoded.email || decoded.email.toLowerCase() !== SUPER_ADMIN_EMAIL.toLowerCase()) {
      return {
        statusCode: 403,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'FORBIDDEN', message: 'Only jijopjohn@gmail.com is authorized.' }),
      };
    }

    if (!decoded.email_verified) {
      return {
        statusCode: 403,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'EMAIL_NOT_VERIFIED', message: 'Email must be verified by Google.' }),
      };
    }

    const db = getFirestore();
    const userRef = db.collection('authorized_users').doc(decoded.uid);
    const existing = await userRef.get();

    if (existing.exists) {
      return {
        statusCode: 200,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ success: true, message: 'Super Admin already initialized.' }),
      };
    }

    await userRef.set({
      uid: decoded.uid,
      email: SUPER_ADMIN_EMAIL,
      role: 'SUPER_ADMIN',
      createdAt: FieldValue.serverTimestamp(),
    });

    return {
      statusCode: 201,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ success: true, message: 'Super Admin authorization established.' }),
    };
  } catch (err: any) {
    return {
      statusCode: 401,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'BOOTSTRAP_FAILED', message: err.message }),
    };
  }
};
