/**
 * Generates an unsigned base64url JWT accepted by the Firestore Emulator
 */
function createMockJwt(claims: { sub: string; email: string; email_verified: boolean }): string {
  const header = Buffer.from(JSON.stringify({ alg: 'none', typ: 'JWT' })).toString('base64url');
  const payload = Buffer.from(JSON.stringify(claims)).toString('base64url');
  return `Bearer ${header}.${payload}.`;
}

console.log('Testing createMockJwt:', createMockJwt({ sub: 'admin-1', email: 'jijopjohn@gmail.com', email_verified: true }));
