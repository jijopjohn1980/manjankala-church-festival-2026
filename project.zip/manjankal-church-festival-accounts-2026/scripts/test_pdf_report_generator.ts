import { jsPDF } from 'jspdf';
import { createCleanInitialState, CHURCH_DETAILS } from '../src/utils/storage';
import { formatINR, numberToMalayalamWords } from '../src/utils/numberToMalayalamWords';
import { exportFestivalToExcel } from '../src/utils/exportExcel';
import { safeColorToRgb } from '../src/utils/exportPdf';
import { readFileSync } from 'fs';

console.log('=== STARTING PDF REPORT FUNCTIONALITY VERIFICATION ===\n');

// Mock data setup
const appState = createCleanInitialState();
const year = appState.years[0];
const data = appState.dataByYear[year.id];

// Add test transactions
data.headings.push(
  { id: 'h1', name: 'നേർച്ച & കാണിക്ക', type: 'INCOME', description: 'നേർച്ച' },
  { id: 'h2', name: 'പെരുന്നാൾ ലേലം', type: 'INCOME', description: 'ലേലം' },
  { id: 'h3', name: 'പന്തൽ നിർമ്മാണം', type: 'EXPENSE', description: 'പന്തൽ' },
  { id: 'h4', name: 'ലൈറ്റ് & സൗണ്ട്', type: 'EXPENSE', description: 'ലൈറ്റ്' }
);

data.incomes.push(
  {
    id: 'inc-1',
    receiptNumber: 'R-2026-001',
    donorName: 'വർഗീസ് മാത്യു & കുടുംബം',
    headingId: 'h1',
    headingName: 'നേർച്ച & കാണിക്ക',
    amount: 15000,
    date: '2026-11-23',
    description: 'നേർച്ച വഴിപാട്',
    paymentMode: 'CASH',
    createdAt: '2026-11-23T10:00:00Z',
  },
  {
    id: 'inc-2',
    receiptNumber: 'R-2026-002',
    headingId: 'h2',
    headingName: 'പെരുന്നാൾ ലേലം',
    amount: 25000,
    date: '2026-11-24',
    description: 'ലേലം പിരിവ്',
    paymentMode: 'UPI',
    createdAt: '2026-11-24T12:00:00Z',
  }
);

data.expenses.push(
  {
    id: 'exp-1',
    voucherNumber: 'V-2026-001',
    paidTo: 'റോയൽ ഡെക്കറേഷൻസ്',
    headingId: 'h3',
    headingName: 'പന്തൽ നിർമ്മാണം',
    amount: 18000,
    date: '2026-11-22',
    description: 'പന്തൽ അഡ്വാൻസ്',
    paymentMode: 'BANK',
    createdAt: '2026-11-22T14:00:00Z',
  }
);

// 1. Verify exportPdf.ts source structure and security/rendering protections
console.log('[TEST 1] Verifying exportPdf.ts implementation:');
const exportPdfSrc = readFileSync('src/utils/exportPdf.ts', 'utf-8');

const expectedKeywords = [
  'CHURCH_DETAILS.nameMl',
  'CHURCH_DETAILS.logoUrl',
  '22-11-2026 to 10-12-2026',
  'numberToMalayalamWords',
  'formatINR',
  'Name of Donor / Contributor',
  'ജനറൽ കൺവീനർ',
  'ട്രഷറർ',
  'ഇടവക ട്രസ്റ്റിമാർ',
  'വികാരി',
  'downloadPdfBlob',
  'html2canvas',
  'jsPDF',
  'safeColorToRgb',
  'createStyleProxy',
  'verifyCanvasHasContent',
  'pdf-export-stage',
  'pdf-render-overlay',
];

for (const kw of expectedKeywords) {
  if (!exportPdfSrc.includes(kw)) {
    throw new Error(`FAIL: exportPdf.ts missing required keyword: ${kw}`);
  }
}
console.log('  ✓ Church details, dates, signatures, donor name, and PDF libraries verified in exportPdf.ts');
console.log('  ✓ Rendering stage (pdf-export-stage) and loading overlay (pdf-render-overlay) verified');
console.log('  ✓ Color sanitizer (safeColorToRgb) and Canvas content verifier verified');

// 2. Test safeColorToRgb sanitization
console.log('\n[TEST 2] Testing safeColorToRgb color converter:');
const testColors = [
  { input: '#10b981', isOklab: false },
  { input: 'rgb(16, 185, 129)', isOklab: false },
  { input: 'oklab(0.7 0.1 0.2)', isOklab: true },
  { input: 'oklch(0.6 0.15 150)', isOklab: true },
];

for (const tc of testColors) {
  const result = safeColorToRgb(tc.input);
  if (tc.isOklab) {
    if (result.includes('oklab') || result.includes('oklch')) {
      throw new Error(`FAIL: safeColorToRgb failed to sanitize oklab/oklch input: ${tc.input}`);
    }
  } else {
    if (result !== tc.input) {
      throw new Error(`FAIL: safeColorToRgb altered regular color: expected ${tc.input}, got ${result}`);
    }
  }
}
console.log('  ✓ safeColorToRgb successfully strips and neutralizes modern oklab/oklch colors');

// 3. Test jsPDF multi-page generation in Node
console.log('\n[TEST 3] Testing jsPDF A4 instantiation and multi-page creation:');
const pdf = new jsPDF({
  orientation: 'portrait',
  unit: 'mm',
  format: 'a4',
  compress: true,
});

const pageWidth = pdf.internal.pageSize.getWidth();
const pageHeight = pdf.internal.pageSize.getHeight();

if (Math.round(pageWidth) !== 210 || Math.round(pageHeight) !== 297) {
  throw new Error(`FAIL: Expected A4 dimensions (210x297mm), got ${pageWidth}x${pageHeight}mm`);
}
console.log(`  ✓ A4 dimensions verified: ${pageWidth}mm x ${pageHeight}mm`);

// Test adding pages with text and watermark
pdf.setFontSize(8);
pdf.setTextColor(148, 163, 184);
pdf.text('Page 1 of 2', pageWidth - 30, pageHeight - 5);

pdf.addPage();
pdf.text('Page 2 of 2', pageWidth - 30, pageHeight - 5);

if (pdf.getNumberOfPages() !== 2) {
  throw new Error(`FAIL: Expected 2 pages, got ${pdf.getNumberOfPages()}`);
}
console.log('  ✓ Multi-page pagination verified: 2 pages created');

const pdfBuffer = pdf.output('arraybuffer');
if (!pdfBuffer || pdfBuffer.byteLength < 500) {
  throw new Error('FAIL: PDF buffer generation failed or too small');
}
console.log(`  ✓ Binary PDF generation successful (${pdfBuffer.byteLength} bytes)`);

// 4. Verify Excel Export remains functional
console.log('\n[TEST 4] Verifying Excel export regression:');
let excelError: any = null;
try {
  exportFestivalToExcel(year, data);
} catch (e) {
  excelError = e;
}
if (excelError) {
  throw new Error(`FAIL: Excel export threw an error: ${excelError.message}`);
}
console.log('  ✓ Excel export executed without errors');

// 5. Verify ReportsView.tsx UI integration
console.log('\n[TEST 5] Verifying ReportsView.tsx UI integration:');
const reportsViewSrc = readFileSync('src/components/ReportsView.tsx', 'utf-8');

if (!reportsViewSrc.includes('handleDownloadPdf')) {
  throw new Error('FAIL: ReportsView.tsx missing handleDownloadPdf');
}
if (!reportsViewSrc.includes('PDF ഡൗൺലോഡ് ചെയ്യുക')) {
  throw new Error('FAIL: ReportsView.tsx missing "PDF ഡൗൺലോഡ് ചെയ്യുക" button');
}
if (!reportsViewSrc.includes('സമ്പൂർണ്ണ കണക്ക് പുസ്തകം (PDF)')) {
  throw new Error('FAIL: ReportsView.tsx missing "സമ്പൂർണ്ണ കണക്ക് പുസ്തകം (PDF)" button');
}
if (!reportsViewSrc.includes('എക്സൽ ഡൗൺലോഡ് (Excel)')) {
  throw new Error('FAIL: ReportsView.tsx missing Excel download button');
}
if (!reportsViewSrc.includes('പ്രിന്റ് / പ്രിവ്യൂ')) {
  throw new Error('FAIL: ReportsView.tsx missing Print / Preview button');
}
console.log('  ✓ ReportsView.tsx has dedicated PDF download, Full Register PDF, Excel, and Print buttons');

// 6. Verify index.css print rules
console.log('\n[TEST 6] Verifying index.css @media print:');
const cssSrc = readFileSync('src/index.css', 'utf-8');
if (!cssSrc.includes('@page') || !cssSrc.includes('size: A4 portrait')) {
  throw new Error('FAIL: index.css missing A4 portrait @page rule');
}
if (!cssSrc.includes('print-color-adjust: exact')) {
  throw new Error('FAIL: index.css missing print-color-adjust: exact');
}
console.log('  ✓ index.css configured with A4 portrait size and exact color adjustment');

console.log('\n============================================================');
console.log('ALL PDF REPORT GENERATOR VERIFICATION TESTS PASSED: 100%');
console.log('============================================================');

