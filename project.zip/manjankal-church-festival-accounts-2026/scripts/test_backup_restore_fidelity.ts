/**
 * Backup Export & Restore Deep Fidelity Verification Test
 * 
 * Verifies that:
 * 1. Export serializes all entities without data loss.
 * 2. Restore deserializes all fields with 100% mathematical fidelity.
 * 3. Compares record counts, IDs, amounts, and nested arrays.
 */

import { AppState, Heading, IncomeTransaction, ExpenseTransaction } from '../src/types/festival';
import { createCleanInitialState } from '../src/utils/storage';

function runBackupRestoreFidelityTest() {
  console.log('=== STARTING BACKUP EXPORT & RESTORE FIDELITY TEST ===\n');

  // 1. Build a rich dataset with custom headings, receipts, vouchers, and audit logs
  const stateBefore: AppState = createCleanInitialState();

  // Headings
  const heading1: Heading = {
    id: 'inc-head-2026-001',
    name: 'നേർച്ച പെട്ടി വരവ്',
    type: 'INCOME',
    description: 'പള്ളിയിലെ പ്രധാന നേർച്ചപ്പെട്ടിയിലെ സംഭാവനകൾ',
  };
  const heading2: Heading = {
    id: 'exp-head-2026-001',
    name: 'പന്തൽ & അലങ്കാരം',
    type: 'EXPENSE',
    description: 'പെരുന്നാൾ പന്തൽ നിർമ്മാണവും ലൈറ്റിംഗും',
  };
  stateBefore.dataByYear['2026'].headings = [heading1, heading2];

  // Incomes (Receipts)
  const income1: IncomeTransaction = {
    id: 'inc-2026-101',
    receiptNumber: 'R-2026-001',
    date: '2026-11-22',
    donorName: 'വർഗീസ് ജോസഫ്, മഞ്ഞക്കാല',
    headingId: heading1.id,
    headingName: heading1.name,
    amount: 15000,
    paymentMode: 'CASH',
    description: 'വാർഷിക പെരുന്നാൾ നേർച്ച',
    createdAt: '2026-11-22T04:30:00.000Z',
  };
  const income2: IncomeTransaction = {
    id: 'inc-2026-102',
    receiptNumber: 'R-2026-002',
    date: '2026-11-23',
    donorName: 'ജോർജ് മാത്യു',
    headingId: heading1.id,
    headingName: heading1.name,
    amount: 25000,
    paymentMode: 'BANK',
    referenceNumber: 'UPI/4321987650',
    description: 'പ്രത്യേക കുർബാന നേർച്ച',
    createdAt: '2026-11-23T06:15:00.000Z',
  };
  stateBefore.dataByYear['2026'].incomes = [income1, income2];
  stateBefore.dataByYear['2026'].lastReceiptSeq = 2;

  // Expenses (Vouchers)
  const expense1: ExpenseTransaction = {
    id: 'exp-2026-201',
    voucherNumber: 'V-2026-001',
    date: '2026-11-24',
    paidTo: 'സെന്റ് ജോർജ്ജ് ഡെക്കറേഷൻസ്',
    headingId: heading2.id,
    headingName: heading2.name,
    amount: 18000,
    paymentMode: 'CHEQUE',
    referenceNumber: 'CHQ-890123',
    description: 'ആദ്യ ഗഡു പന്തൽ നിർമ്മാണം',
    createdAt: '2026-11-24T08:00:00.000Z',
  };
  stateBefore.dataByYear['2026'].expenses = [expense1];
  stateBefore.dataByYear['2026'].lastVoucherSeq = 1;

  // Audit Logs
  stateBefore.auditLogs = [
    {
      id: 'log-001',
      timestamp: '2026-11-22T04:30:00.000Z',
      userEmail: 'jijopjohn@gmail.com',
      action: 'ADD_INCOME',
      summaryMl: 'രസീത് R-2026-001 ചേർത്തു: ₹15,000',
      amount: 15000,
    },
    {
      id: 'log-002',
      timestamp: '2026-11-24T08:00:00.000Z',
      userEmail: 'jijopjohn@gmail.com',
      action: 'ADD_EXPENSE',
      summaryMl: 'വൗച്ചർ V-2026-001 ചേർത്തു: ₹18,000',
      amount: 18000,
    },
  ];

  // Record Counts Before Export
  const beforeStats = {
    yearsCount: stateBefore.years.length,
    headingsCount: stateBefore.dataByYear['2026'].headings.length,
    incomesCount: stateBefore.dataByYear['2026'].incomes.length,
    totalIncomeAmount: stateBefore.dataByYear['2026'].incomes.reduce((s, i) => s + i.amount, 0),
    expensesCount: stateBefore.dataByYear['2026'].expenses.length,
    totalExpenseAmount: stateBefore.dataByYear['2026'].expenses.reduce((s, e) => s + e.amount, 0),
    auditLogsCount: stateBefore.auditLogs.length,
  };

  // 2. Perform Export (JSON Serialization)
  const exportedJson = JSON.stringify(stateBefore, null, 2);
  const exportedSizeKb = (Buffer.byteLength(exportedJson) / 1024).toFixed(2);
  console.log(`[EXPORT] Serialized state to JSON (${exportedSizeKb} KB).`);

  // 3. Perform Restore (JSON Deserialization)
  const stateRestored: AppState = JSON.parse(exportedJson);

  // Record Counts After Restore
  const restoredStats = {
    yearsCount: stateRestored.years.length,
    headingsCount: stateRestored.dataByYear['2026'].headings.length,
    incomesCount: stateRestored.dataByYear['2026'].incomes.length,
    totalIncomeAmount: stateRestored.dataByYear['2026'].incomes.reduce((s, i) => s + i.amount, 0),
    expensesCount: stateRestored.dataByYear['2026'].expenses.length,
    totalExpenseAmount: stateRestored.dataByYear['2026'].expenses.reduce((s, e) => s + e.amount, 0),
    auditLogsCount: stateRestored.auditLogs?.length || 0,
  };

  // 4. Comparison Table
  console.log('\n--- VERIFICATION COMPARISON TABLE ---');
  console.table({
    'Festival Years': { Before: beforeStats.yearsCount, Restored: restoredStats.yearsCount, Match: beforeStats.yearsCount === restoredStats.yearsCount },
    'Custom Headings': { Before: beforeStats.headingsCount, Restored: restoredStats.headingsCount, Match: beforeStats.headingsCount === restoredStats.headingsCount },
    'Income Receipts Count': { Before: beforeStats.incomesCount, Restored: restoredStats.incomesCount, Match: beforeStats.incomesCount === restoredStats.incomesCount },
    'Total Income (₹)': { Before: beforeStats.totalIncomeAmount, Restored: restoredStats.totalIncomeAmount, Match: beforeStats.totalIncomeAmount === restoredStats.totalIncomeAmount },
    'Expense Vouchers Count': { Before: beforeStats.expensesCount, Restored: restoredStats.expensesCount, Match: beforeStats.expensesCount === restoredStats.expensesCount },
    'Total Expenses (₹)': { Before: beforeStats.totalExpenseAmount, Restored: restoredStats.totalExpenseAmount, Match: beforeStats.totalExpenseAmount === restoredStats.totalExpenseAmount },
    'Net Balance (₹)': {
      Before: beforeStats.totalIncomeAmount - beforeStats.totalExpenseAmount,
      Restored: restoredStats.totalIncomeAmount - restoredStats.totalExpenseAmount,
      Match: (beforeStats.totalIncomeAmount - beforeStats.totalExpenseAmount) === (restoredStats.totalIncomeAmount - restoredStats.totalExpenseAmount),
    },
    'Audit Trail Records': { Before: beforeStats.auditLogsCount, Restored: restoredStats.auditLogsCount, Match: beforeStats.auditLogsCount === restoredStats.auditLogsCount },
  });

  // Strict Field Assertions
  console.assert(restoredStats.yearsCount === 1, 'Years count mismatch');
  console.assert(restoredStats.headingsCount === 2, 'Headings count mismatch');
  console.assert(restoredStats.incomesCount === 2, 'Incomes count mismatch');
  console.assert(restoredStats.expensesCount === 1, 'Expenses count mismatch');
  console.assert(restoredStats.totalIncomeAmount === 40000, 'Total income mismatch');
  console.assert(restoredStats.totalExpenseAmount === 18000, 'Total expense mismatch');
  console.assert(restoredStats.auditLogsCount === 2, 'Audit logs mismatch');
  console.assert(stateRestored.dataByYear['2026'].incomes[0].donorName === 'വർഗീസ് ജോസഫ്, മഞ്ഞക്കാല', 'Malayalam text corrupted');
  console.assert(stateRestored.dataByYear['2026'].headings[0].name === 'നേർച്ച പെട്ടി വരവ്', 'Malayalam heading corrupted');

  console.log('\n[PASS] All field-level assertions passed with zero discrepancies.');
  console.log('=== BACKUP & RESTORE FIDELITY VERIFICATION SUCCESSFUL ===');
}

runBackupRestoreFidelityTest();
