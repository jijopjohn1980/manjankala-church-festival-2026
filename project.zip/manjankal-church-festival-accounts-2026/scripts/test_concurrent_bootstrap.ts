/**
 * Simultaneous Bootstrap Concurrency Stress Test
 * 
 * Verifies that:
 * 1. Multiple simultaneous bootstrap attempts (e.g. 5 concurrent requests) are serialized.
 * 2. Exactly ONE request succeeds (HTTP 201 / COMMITTED).
 * 3. All subsequent / parallel requests fail with ALREADY_INITIALIZED (HTTP 409).
 * 4. Zero duplicate records can ever be created.
 */

interface MockFirestoreDoc {
  uid: string;
  email: string;
  role: string;
  createdAt: string;
}

class SimulatedFirestoreDatabase {
  private collection: Map<string, MockFirestoreDoc> = new Map();
  private lock: Promise<void> = Promise.resolve();

  // Simulates Firestore's serializable transactional execution
  async runTransaction<T>(updateFunction: (tx: SimulatedTransaction) => Promise<T>): Promise<T> {
    // Acquire mutex lock to simulate database transactional isolation & retry serialization
    const previousLock = this.lock;
    let releaseLock: () => void;
    this.lock = new Promise<void>((resolve) => {
      releaseLock = resolve;
    });

    await previousLock;

    try {
      const tx = new SimulatedTransaction(this.collection);
      const result = await updateFunction(tx);
      tx.commit();
      return result;
    } finally {
      releaseLock!();
    }
  }

  getSnapshotCount(): number {
    return this.collection.size;
  }

  getRecord(uid: string): MockFirestoreDoc | undefined {
    return this.collection.get(uid);
  }
}

class SimulatedTransaction {
  private stagedWrites: Map<string, MockFirestoreDoc> = new Map();

  constructor(private dbMap: Map<string, MockFirestoreDoc>) {}

  async getCollectionCount(): Promise<number> {
    // Read from current committed DB state
    return this.dbMap.size;
  }

  set(docId: string, data: MockFirestoreDoc): void {
    this.stagedWrites.set(docId, data);
  }

  commit(): void {
    for (const [key, val] of this.stagedWrites.entries()) {
      this.dbMap.set(key, val);
    }
  }
}

async function simulateBootstrapRequest(
  requestId: number,
  db: SimulatedFirestoreDatabase,
  uid: string,
  email: string
): Promise<{ requestId: number; status: number; result: string }> {
  try {
    const record = await db.runTransaction(async (tx) => {
      // 1. Read existing authorized_users inside transaction
      const count = await tx.getCollectionCount();
      if (count > 0) {
        throw new Error('ALREADY_INITIALIZED');
      }

      // Add artificial micro-delay (10ms) to simulate network latency inside transaction
      await new Promise((r) => setTimeout(r, 10));

      const newRecord: MockFirestoreDoc = {
        uid,
        email,
        role: 'SUPER_ADMIN',
        createdAt: new Date().toISOString(),
      };

      tx.set(uid, newRecord);
      return newRecord;
    });

    return {
      requestId,
      status: 201,
      result: `SUCCESS: Super Admin created for UID ${record.uid}`,
    };
  } catch (err: any) {
    if (err.message === 'ALREADY_INITIALIZED') {
      return {
        requestId,
        status: 409,
        result: 'CONFLICT: Super Admin already initialized. Request rejected.',
      };
    }
    return {
      requestId,
      status: 500,
      result: `ERROR: ${err.message}`,
    };
  }
}

async function runConcurrencyTest() {
  console.log('=== STARTING SIMULTANEOUS BOOTSTRAP CONCURRENCY TEST ===\n');

  const db = new SimulatedFirestoreDatabase();
  const superAdminUid = 'google-uid-jijo-pj-2026-superadmin';
  const superAdminEmail = 'jijopjohn@gmail.com';

  console.log('Dispatching 5 simultaneous bootstrap requests via Promise.all()...\n');

  // Launch 5 concurrent requests at the exact same instant
  const requestPromises = [1, 2, 3, 4, 5].map((id) =>
    simulateBootstrapRequest(id, db, superAdminUid, superAdminEmail)
  );

  const results = await Promise.all(requestPromises);

  console.table(
    results.map((r) => ({
      'Request ID': `Request #${r.requestId}`,
      'HTTP Status': r.status,
      'Outcome': r.result,
    }))
  );

  const successes = results.filter((r) => r.status === 201);
  const conflicts = results.filter((r) => r.status === 409);
  const totalDbRecords = db.getSnapshotCount();

  console.log('\n--- CONCURRENCY TEST SUMMARY ---');
  console.log(`Total Requests Dispatched: 5`);
  console.log(`Successful Initializations (HTTP 201): ${successes.length} (Expected: exactly 1)`);
  console.log(`Rejected Conflicts (HTTP 409): ${conflicts.length} (Expected: exactly 4)`);
  console.log(`Final Database Super Admin Records: ${totalDbRecords} (Expected: exactly 1)`);

  const committedRecord = db.getRecord(superAdminUid);
  console.log('\nCommitted Super Admin Document:');
  console.log(JSON.stringify(committedRecord, null, 2));

  if (successes.length === 1 && conflicts.length === 4 && totalDbRecords === 1) {
    console.log('\n[PASS] Atomic transaction successfully prevented duplicate Super Admin creation.');
    console.log('=== CONCURRENCY VERIFICATION SUCCESSFUL ===');
  } else {
    console.error('\n[FAIL] Concurrency violation detected!');
    process.exit(1);
  }
}

runConcurrencyTest().catch((err) => {
  console.error(err);
  process.exit(1);
});
