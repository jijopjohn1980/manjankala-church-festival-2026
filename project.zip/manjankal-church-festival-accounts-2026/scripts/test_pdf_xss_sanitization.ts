import { escapeHtml, buildReportHtml } from '../src/utils/exportPdf';
import { createCleanInitialState } from '../src/utils/storage';

console.log('=== STARTING PDF XSS SANITIZATION & MALAYALAM INTEGRITY VERIFICATION ===\n');

// 1. Direct Unit Tests for escapeHtml
console.log('[TEST 1] Testing escapeHtml unit behavior:');

const testCases = [
  {
    name: 'Script tag payload',
    input: '<script>alert("XSS")</script>',
    expected: '&lt;script&gt;alert(&quot;XSS&quot;)&lt;/script&gt;',
  },
  {
    name: 'Img onerror payload',
    input: '<img src="x" onerror="alert(1)">',
    expected: '&lt;img src=&quot;x&quot; onerror=&quot;alert(1)&quot;&gt;',
  },
  {
    name: 'Single quote attribute breakout',
    input: "' onmouseover='alert(1)",
    expected: '&#39; onmouseover=&#39;alert(1)',
  },
  {
    name: 'Backtick template breakout',
    input: '` onclick=`alert(1)`',
    expected: '&#96; onclick=&#96;alert(1)&#96;',
  },
  {
    name: 'Ampersand escaping',
    input: 'നേർച്ച & കാണിക്ക',
    expected: 'നേർച്ച &amp; കാണിക്ക',
  },
  {
    name: 'Pure Malayalam Unicode string',
    input: 'വർഗീസ് മാത്യു',
    expected: 'വർഗീസ് മാത്യു',
  },
  {
    name: 'Null value',
    input: null,
    expected: '',
  },
  {
    name: 'Undefined value',
    input: undefined,
    expected: '',
  },
  {
    name: 'Number input',
    input: 12345,
    expected: '12345',
  },
];

for (const tc of testCases) {
  const result = escapeHtml(tc.input);
  if (result !== tc.expected) {
    throw new Error(
      `FAIL [escapeHtml]: ${tc.name}\nExpected: ${tc.expected}\nReceived: ${result}`
    );
  }
  console.log(`  ✓ Passed: ${tc.name}`);
}

// 2. Integration Test: Injected XSS Payloads in buildReportHtml
console.log('\n[TEST 2] Testing buildReportHtml with malicious transaction and heading payloads:');

const appState = createCleanInitialState();
const year = {
  ...appState.years[0],
  yearName: '<script>alert("year_xss")</script> 2026',
};

const xssPayloads = [
  '<script>alert("donor_xss")</script>',
  '<img src=x onerror=alert("img_xss")>',
  '<svg onload=alert("svg_xss")>',
  '"><iframe src=javascript:alert("frame_xss")></iframe>',
  "' onfocus='alert(\"focus_xss\")",
];

const data = {
  yearId: '2026',
  lastReceiptSeq: 1,
  lastVoucherSeq: 1,
  headings: [
    {
      id: 'h-xss-1',
      name: '<b onmouseover=alert("h_xss")>നേർച്ച XSS</b>',
      type: 'INCOME' as const,
      description: 'Test',
    },
    {
      id: 'h-xss-2',
      name: '<script>alert("exp_h_xss")</script>ചിലവ്',
      type: 'EXPENSE' as const,
      description: 'Test',
    },
  ],
  incomes: [
    {
      id: 'inc-xss-1',
      receiptNumber: '<img src=x onerror=alert("receipt_xss")>R-001',
      donorName: '<script>alert("donor_xss")</script>വർഗീസ്',
      headingId: 'h-xss-1',
      headingName: '<b onmouseover=alert("h_xss")>നേർച്ച XSS</b>',
      amount: 5000,
      date: '2026-11-23"><script>alert("date_xss")</script>',
      description: 'Normal Description',
      paymentMode: 'CASH' as const,
      createdAt: '2026-11-23T10:00:00Z',
    },
  ],
  expenses: [
    {
      id: 'exp-xss-1',
      voucherNumber: '<script>alert("voucher_xss")</script>V-001',
      paidTo: '<svg onload=alert("paid_xss")>റോയൽ',
      headingId: 'h-xss-2',
      headingName: '<script>alert("exp_h_xss")</script>ചിലവ്',
      amount: 3000,
      date: '2026-11-24',
      description: 'Normal Description',
      paymentMode: 'BANK' as const,
      createdAt: '2026-11-24T10:00:00Z',
    },
  ],
};

const reportTypes: Array<'COMPLETE' | 'DAILY' | 'MONTHLY' | 'ALL_DETAILS'> = [
  'COMPLETE',
  'DAILY',
  'MONTHLY',
  'ALL_DETAILS',
];

for (const repType of reportTypes) {
  const html = buildReportHtml({
    year,
    data,
    reportType: repType,
  });

  // Verify dangerous tags NEVER appear unescaped in raw HTML
  const dangerousPatterns = [
    /<script\b/i,
    /<\/script>/i,
    /<img\b[^>]*\bonerror\s*=/i,
    /<svg\b[^>]*\bonload\s*=/i,
    /<iframe\b/i,
    /<[a-z][a-z0-9]*\b[^>]*\bon[a-z]+\s*=/i,
  ];

  for (const pat of dangerousPatterns) {
    if (pat.test(html)) {
      throw new Error(`FAIL: buildReportHtml (${repType}) contains unescaped dangerous pattern: ${pat}`);
    }
  }

  // Verify escaped versions DO exist in the HTML
  if (repType === 'COMPLETE' || repType === 'ALL_DETAILS') {
    if (!html.includes('&lt;script&gt;alert(&quot;donor_xss&quot;)&lt;/script&gt;')) {
      throw new Error(`FAIL: Escaped donor XSS string missing from ${repType}`);
    }
    if (!html.includes('&lt;svg onload=alert(&quot;paid_xss&quot;)&gt;റോയൽ')) {
      throw new Error(`FAIL: Escaped paidTo XSS string missing from ${repType}`);
    }
    if (!html.includes('&lt;b onmouseover=alert(&quot;h_xss&quot;)&gt;നേർച്ച XSS&lt;/b&gt;')) {
      throw new Error(`FAIL: Escaped heading XSS string missing from ${repType}`);
    }
  }

  // Verify Malayalam characters are preserved intact
  if (!html.includes('മാർ ശെമവൂൻ ദെസ്തൂനി ഓർത്തഡോക്സ് സുറിയാനി പള്ളി, മഞ്ഞക്കാല')) {
    throw new Error(`FAIL: Church name Malayalam corrupted in ${repType}`);
  }
  if (repType === 'COMPLETE' || repType === 'ALL_DETAILS') {
    if (!html.includes('വർഗീസ്')) {
      throw new Error(`FAIL: Donor name Malayalam corrupted in ${repType}`);
    }
    if (!html.includes('റോയൽ')) {
      throw new Error(`FAIL: PaidTo Malayalam corrupted in ${repType}`);
    }
  }

  console.log(`  ✓ Verified 100% XSS immunity and Malayalam integrity for reportType: ${repType}`);
}

console.log('\n============================================================');
console.log('ALL PDF XSS SANITIZATION TESTS PASSED: 100%');
console.log('============================================================\n');
