import {
  validateWholeRupeeAmount,
  canonicalizeIncomePayload,
  computePayloadFingerprint,
  formatReceiptNumber,
  formatVoucherNumber
} from '../src/utils/payloadNormalization';

console.log('=== TESTING PAYLOAD NORMALIZATION & DECIMAL REJECTION ===');

// Test 1: Decimal rejection
try {
  validateWholeRupeeAmount(500.50);
  console.error('[FAIL] Decimal amount 500.50 was not rejected');
  process.exit(1);
} catch (e: any) {
  console.log('[PASS] Decimal amount 500.50 rejected:', e.message);
}

try {
  validateWholeRupeeAmount('150.25');
  console.error('[FAIL] String decimal 150.25 was not rejected');
  process.exit(1);
} catch (e: any) {
  console.log('[PASS] String decimal 150.25 rejected:', e.message);
}

// Test 2: Valid integer
const validAmount = validateWholeRupeeAmount(500);
if (validAmount === 500) {
  console.log('[PASS] Valid integer ₹500 accepted');
} else {
  console.error('[FAIL] Valid integer was altered');
  process.exit(1);
}

// Test 3: Receipt formatting
if (formatReceiptNumber(1) === 'R-2026-001' && formatReceiptNumber(999) === 'R-2026-999' && formatReceiptNumber(1000) === 'R-2026-1000') {
  console.log('[PASS] Receipt number boundary formatting verified');
} else {
  console.error('[FAIL] Receipt number formatting incorrect');
  process.exit(1);
}

// Test 4: Deterministic SHA-256
async function testHash() {
  const canonical = canonicalizeIncomePayload({
    amount: 1000,
    date: '2026-11-25',
    headingId: 'h-1',
    description: 'Test gift',
    paymentMode: 'CASH',
    donorName: 'John',
    collectedBy: 'Trustee'
  });
  const hash1 = await computePayloadFingerprint(canonical);
  const hash2 = await computePayloadFingerprint(canonical);
  if (hash1 === hash2 && hash1.length === 64) {
    console.log('[PASS] SHA-256 fingerprint is deterministic (64 hex):', hash1);
  } else {
    console.error('[FAIL] Hash generation is non-deterministic');
    process.exit(1);
  }
}

testHash().then(() => {
  console.log('=== ALL PAYLOAD NORMALIZATION TESTS PASSED ===');
});
