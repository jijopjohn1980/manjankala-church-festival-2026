/**
 * REAL FIRESTORE EMULATOR TEST SUITE
 * Manjankal Mar Shemavoon Desthuni Orthodox Syrian Church - 2026 Festival Accounts
 *
 * Runs against the actual Google Cloud Firestore Emulator running on port 8088.
 * Directly exercises firestore.rules compilation, token validation, and CEL rule evaluation.
 */

const EMULATOR_HOST = 'http://127.0.0.1:8088';
const PROJECT_ID = 'demo-church';
const BASE_URL = `${EMULATOR_HOST}/v1/projects/${PROJECT_ID}/databases/(default)/documents`;

function createMockJwt(claims: { sub: string; email: string; email_verified: boolean; [key: string]: any }): string {
  const header = Buffer.from(JSON.stringify({ alg: 'none', typ: 'JWT' })).toString('base64url');
  const payload = Buffer.from(JSON.stringify(claims)).toString('base64url');
  return `Bearer ${header}.${payload}.`;
}

// Helper for making REST requests to the emulator
async function emulatorRequest(
  method: string,
  docPath: string,
  authHeader?: string,
  body?: Record<string, any>
): Promise<{ status: number; data: any }> {
  const url = `${BASE_URL}/${docPath}`;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (authHeader) {
    headers['Authorization'] = authHeader;
  }

  const res = await fetch(url, {
    method,
    headers,
    ...(body ? { body: JSON.stringify(body) } : {}),
  });

  let data = null;
  try {
    data = await res.json();
  } catch {
    // Non-JSON response
  }

  return { status: res.status, data };
}

const UNAUTHORIZED_TOKEN = createMockJwt({
  sub: 'hacker-uid',
  email: 'hacker@gmail.com',
  email_verified: true,
});

const UNVERIFIED_ADMIN_TOKEN = createMockJwt({
  sub: 'spoof-uid',
  email: 'jijopjohn@gmail.com',
  email_verified: false,
});

const VALID_ADMIN_TOKEN = createMockJwt({
  sub: 'admin-uid',
  email: 'jijopjohn@gmail.com',
  email_verified: true,
});

async function runRealEmulatorTests() {
  console.log('================================================================');
  console.log('REAL FIRESTORE EMULATOR INTEGRATION TEST SUITE');
  console.log('Target: cloud-firestore-emulator-v1.22.0 on port 8088');
  console.log('================================================================');

  let passed = 0;
  let total = 0;

  function assert(name: string, condition: boolean, detail: string) {
    total++;
    if (condition) {
      passed++;
      console.log(`[PASS] Test ${total}: ${name}`);
    } else {
      console.error(`[FAIL] Test ${total}: ${name} -> ${detail}`);
    }
  }

  // 1. Unauthenticated Request -> Denied (HTTP 403)
  const t1 = await emulatorRequest('GET', 'festivals/2026/incomes');
  assert(
    'Unauthenticated access rejected with HTTP 403 PERMISSION_DENIED',
    t1.status === 403,
    `Got status ${t1.status}`
  );

  // 2. Unauthorized User (hacker@gmail.com) -> Denied (HTTP 403)
  const t2 = await emulatorRequest('GET', 'festivals/2026/incomes', UNAUTHORIZED_TOKEN);
  assert(
    'Unauthorized Google user (hacker@gmail.com) rejected with HTTP 403',
    t2.status === 403,
    `Got status ${t2.status} (Data: ${JSON.stringify(t2.data)})`
  );

  // 3. Unverified Admin (jijopjohn@gmail.com with email_verified: false) -> Denied (HTTP 403)
  const t3 = await emulatorRequest('GET', 'festivals/2026/incomes', UNVERIFIED_ADMIN_TOKEN);
  assert(
    'Unverified administrator account rejected with HTTP 403',
    t3.status === 403,
    `Got status ${t3.status} (Data: ${JSON.stringify(t3.data)})`
  );

  // 4. Authorized Verified Administrator -> Permitted (HTTP 200)
  const t4 = await emulatorRequest('GET', 'festivals/2026/incomes', VALID_ADMIN_TOKEN);
  assert(
    'Authorized verified administrator (jijopjohn@gmail.com) permitted (HTTP 200)',
    t4.status === 200,
    `Got status ${t4.status} (Data: ${JSON.stringify(t4.data)})`
  );

  // 5. Create Valid Heading -> Permitted (HTTP 200)
  const headingId = 'h-valid-inc-1';
  const validHeadingBody = {
    fields: {
      id: { stringValue: headingId },
      name: { stringValue: 'നേർച്ച' },
      type: { stringValue: 'INCOME' },
      createdAt: { stringValue: '2026-11-22T08:00:00Z' },
    },
  };
  const t5 = await emulatorRequest(
    'PATCH',
    `festivals/2026/headings/${headingId}`,
    VALID_ADMIN_TOKEN,
    validHeadingBody
  );
  assert(
    'Authorized admin creates valid Income Heading (HTTP 200)',
    t5.status === 200,
    `Got status ${t5.status} (Data: ${JSON.stringify(t5.data)})`
  );

  // 6. Create Invalid Heading Type -> Rejected (HTTP 403)
  const invalidHeadingBody = {
    fields: {
      id: { stringValue: 'h-inv-1' },
      name: { stringValue: 'അസാധു' },
      type: { stringValue: 'INVESTMENT' }, // INVALID TYPE
      createdAt: { stringValue: '2026-11-22T08:00:00Z' },
    },
  };
  const t6 = await emulatorRequest(
    'PATCH',
    'festivals/2026/headings/h-inv-1',
    VALID_ADMIN_TOKEN,
    invalidHeadingBody
  );
  assert(
    'Invalid heading type (INVESTMENT) rejected by firestore.rules (HTTP 403)',
    t6.status === 403,
    `Got status ${t6.status} (Data: ${JSON.stringify(t6.data)})`
  );

  // 7. Direct Financial Document Update -> Forbidden (HTTP 403)
  const t7 = await emulatorRequest(
    'PATCH',
    'festivals/2026/incomes/any-income-id',
    VALID_ADMIN_TOKEN,
    { fields: { amount: { integerValue: '5000' } } }
  );
  assert(
    'Direct update of financial document strictly forbidden (allow update: if false) (HTTP 403)',
    t7.status === 403,
    `Got status ${t7.status} (Data: ${JSON.stringify(t7.data)})`
  );

  // 8. Financial Document Deletion -> Forbidden (HTTP 403)
  const t8 = await emulatorRequest('DELETE', 'festivals/2026/incomes/any-income-id', VALID_ADMIN_TOKEN);
  assert(
    'Financial document deletion strictly forbidden (allow delete: if false) (HTTP 403)',
    t8.status === 403,
    `Got status ${t8.status} (Data: ${JSON.stringify(t8.data)})`
  );

  // 9. Root Festival Document Deletion -> Forbidden (HTTP 403)
  const t9 = await emulatorRequest('DELETE', 'festivals/2026', VALID_ADMIN_TOKEN);
  assert(
    'Root festival year deletion strictly forbidden (HTTP 403)',
    t9.status === 403,
    `Got status ${t9.status} (Data: ${JSON.stringify(t9.data)})`
  );

  // 10. Audit Log Direct Update -> Forbidden (HTTP 403)
  const t10 = await emulatorRequest(
    'PATCH',
    'festivals/2026/audit_logs/audit_123',
    VALID_ADMIN_TOKEN,
    { fields: { summaryMl: { stringValue: 'തിരുത്തൽ ശ്രമം' } } }
  );
  assert(
    'Audit log modification strictly forbidden (allow update: if false) (HTTP 403)',
    t10.status === 403,
    `Got status ${t10.status} (Data: ${JSON.stringify(t10.data)})`
  );

  console.log('================================================================');
  console.log(`REAL FIRESTORE EMULATOR TEST RESULTS: ${passed}/${total} PASSED`);
  console.log('================================================================');

  if (passed !== total) {
    process.exit(1);
  }
}

runRealEmulatorTests().catch((err) => {
  console.error('Fatal Emulator Test Suite Error:', err);
  process.exit(1);
});
