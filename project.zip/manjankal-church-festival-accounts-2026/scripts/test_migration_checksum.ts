/**
 * Test Migration Checksum & Integrity Verification Suite
 * Manjankal Mar Shemavoon Desthuni Orthodox Syrian Church - 2026 Festival Accounts
 *
 * Verifies:
 * 1. Historical records are cryptographically covered (not empty SHA-256).
 * 2. Deterministic serialization regardless of input insertion order.
 * 3. Strict sensitivity: altering any field, amount, date, or name changes the checksum.
 * 4. Decimal rejection and whole rupee validation in migration payloads.
 * 5. Detection of duplicate serial numbers across historical records.
 * 6. Detection of invalid receipt/voucher serial number formats.
 * 7. Detection of dates outside the 2026 festival period (2026-11-22 to 2026-12-10).
 * 8. Detection of missing required fields (headingName, description, paidTo).
 * 9. Mathematical verification of continuous sequence advancement from historical maxima.
 */

import {
  computeMigrationChecksum,
  validateAndDigestMigrationDataset,
  validateWholeRupeeAmount,
  canonicalizeIncomePayload,
  computePayloadFingerprint,
  formatReceiptNumber,
  formatVoucherNumber,
  MigrationIncomeRecord,
  MigrationExpenseRecord,
} from '../src/utils/payloadNormalization';

const EMPTY_SHA256 = 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855';

async function runMigrationIntegrityTests() {
  console.log('========================================================================');
  console.log('RUNNING TEST: MIGRATION DATASET INTEGRITY & CHECKSUM VERIFICATION');
  console.log('========================================================================');

  // Baseline 3 historical incomes (Total: ₹7,000, Max Seq: 7)
  const baselineIncomes: MigrationIncomeRecord[] = [
    {
      seqNumber: 1,
      receiptNumber: 'R-2026-001',
      amount: 2000,
      date: '2026-11-22',
      headingName: 'നേർച്ച',
      description: 'പ്രാരംഭ നേർച്ച സമർപ്പണം',
      donorName: 'വർഗ്ഗീസ് മാത്യു',
    },
    {
      seqNumber: 2,
      receiptNumber: 'R-2026-002',
      amount: 1500,
      date: '2026-11-23',
      headingName: 'നേർച്ച',
      description: 'ഭക്തജന നേർച്ച',
      donorName: 'തോമസ് കുരുവിള',
    },
    {
      seqNumber: 7, // Non-consecutive: 001, 002, 007
      receiptNumber: 'R-2026-007',
      amount: 3500,
      date: '2026-11-24',
      headingName: 'നേർച്ച',
      description: 'പ്രത്യേക വഴിപാട്',
      donorName: 'ജോസഫ് ഫിലിപ്പ്',
    },
  ];

  // Baseline 2 historical expenses (Total: ₹5,000, Max Seq: 5)
  const baselineExpenses: MigrationExpenseRecord[] = [
    {
      seqNumber: 1,
      voucherNumber: 'V-2026-001',
      amount: 2000,
      date: '2026-11-22',
      headingName: 'വൈദ്യുതി & ലൈറ്റ്',
      description: 'ഡെക്കറേഷൻ ലൈറ്റിംഗ് അഡ്വാൻസ്',
      paidTo: 'സന്തോഷ് കുമാർ',
    },
    {
      seqNumber: 5, // Non-consecutive: 001, 005
      voucherNumber: 'V-2026-005',
      amount: 3000,
      date: '2026-11-24',
      headingName: 'ഓഡിയോ & മൈക്ക്',
      description: 'സൗണ്ട് സിസ്റ്റം വാടക',
      paidTo: 'ബാബു സൗണ്ട്സ്',
    },
  ];

  // Verification 1: Checksum over baseline records
  const baselineChecksum = await computeMigrationChecksum(baselineIncomes, baselineExpenses);
  console.log(`[PASS] Baseline Checksum computed: ${baselineChecksum}`);

  if (baselineChecksum === EMPTY_SHA256) {
    console.error('[FAIL] Checksum is identical to empty SHA-256!');
    process.exit(1);
  }
  if (!/^[0-9a-f]{64}$/.test(baselineChecksum)) {
    console.error('[FAIL] Checksum is not a valid 64-char lowercase hex string!');
    process.exit(1);
  }
  console.log('[PASS] Checksum strictly covers historical records and does NOT equal empty SHA-256.');

  // Verification 2: Deterministic ordering check (reversed input order must produce IDENTICAL checksum)
  const reversedIncomes = [...baselineIncomes].reverse();
  const reversedExpenses = [...baselineExpenses].reverse();
  const reversedChecksum = await computeMigrationChecksum(reversedIncomes, reversedExpenses);

  if (reversedChecksum !== baselineChecksum) {
    console.error('[FAIL] Checksum is not deterministic across input array orderings!');
    process.exit(1);
  }
  console.log('[PASS] Deterministic canonical sorting verified (reversed input yields identical checksum).');

  // Verification 3: Full dataset validation on baseline
  const validationResult = await validateAndDigestMigrationDataset(baselineIncomes, baselineExpenses);
  if (!validationResult.valid) {
    console.error('[FAIL] Baseline dataset failed validation:', validationResult.errors);
    process.exit(1);
  }
  if (validationResult.totalIncomeAmount !== 7000 || validationResult.totalExpenseAmount !== 5000) {
    console.error('[FAIL] Dataset amounts do not match:', validationResult);
    process.exit(1);
  }
  if (validationResult.maxHistoricalReceiptSeq !== 7 || validationResult.maxHistoricalVoucherSeq !== 5) {
    console.error('[FAIL] Historical sequence bounds incorrect:', validationResult);
    process.exit(1);
  }
  console.log('[PASS] Full dataset validation verified: ₹7,000 incomes, ₹5,000 expenses, max receipt 7, max voucher 5.');

  // Verification 4: Sequence continuation from historical maximum
  const nextReceiptSeq = validationResult.maxHistoricalReceiptSeq + 1; // 8
  const nextVoucherSeq = validationResult.maxHistoricalVoucherSeq + 1; // 6
  const nextReceiptNum = formatReceiptNumber(nextReceiptSeq);
  const nextVoucherNum = formatVoucherNumber(nextVoucherSeq);

  if (nextReceiptNum !== 'R-2026-008' || nextVoucherNum !== 'V-2026-006') {
    console.error('[FAIL] Next serial allocation calculation failed:', { nextReceiptNum, nextVoucherNum });
    process.exit(1);
  }
  console.log(`[PASS] Sequence continuation verified: Next Receipt = ${nextReceiptNum}, Next Voucher = ${nextVoucherNum}.`);

  // Verification 5: Duplicate serial numbers rejection
  const dupSerialIncomes: MigrationIncomeRecord[] = [
    ...baselineIncomes,
    { ...baselineIncomes[0], description: 'Duplicate serial entry' }, // Duplicate seqNumber 1
  ];
  const dupResult = await validateAndDigestMigrationDataset(dupSerialIncomes, baselineExpenses);
  if (dupResult.valid || !dupResult.errors.some((e) => e.includes('DUPLICATE_SERIAL'))) {
    console.error('[FAIL] Duplicate serial was not detected!');
    process.exit(1);
  }
  console.log('[PASS] Duplicate serial numbers rejected in validation.');

  // Verification 6: Invalid serial format rejection (e.g., R-2025-001 instead of R-2026-001)
  const invalidFormatIncomes: MigrationIncomeRecord[] = [
    { ...baselineIncomes[0], receiptNumber: 'R-2025-001' },
    baselineIncomes[1],
    baselineIncomes[2],
  ];
  const formatResult = await validateAndDigestMigrationDataset(invalidFormatIncomes, baselineExpenses);
  if (formatResult.valid || !formatResult.errors.some((e) => e.includes('INVALID_SERIAL_FORMAT'))) {
    console.error('[FAIL] Invalid serial format was not detected!');
    process.exit(1);
  }
  console.log('[PASS] Cross-year / invalid serial format ("R-2025-001") strictly rejected.');

  // Verification 7: Date outside festival period rejection
  const invalidDateIncomes: MigrationIncomeRecord[] = [
    { ...baselineIncomes[0], date: '2026-11-20' }, // 2 days before festival start
    baselineIncomes[1],
    baselineIncomes[2],
  ];
  const dateResult = await validateAndDigestMigrationDataset(invalidDateIncomes, baselineExpenses);
  if (dateResult.valid || !dateResult.errors.some((e) => e.includes('INVALID_DATE'))) {
    console.error('[FAIL] Date outside festival period was not detected!');
    process.exit(1);
  }
  console.log('[PASS] Pre-festival date ("2026-11-20") strictly rejected.');

  // Verification 8: Missing required fields rejection (paidTo)
  const missingFieldExpenses: MigrationExpenseRecord[] = [
    { ...baselineExpenses[0], paidTo: '' },
    baselineExpenses[1],
  ];
  const missingResult = await validateAndDigestMigrationDataset(baselineIncomes, missingFieldExpenses);
  if (missingResult.valid || !missingResult.errors.some((e) => e.includes('MISSING_FIELD'))) {
    console.error('[FAIL] Missing payee field was not detected!');
    process.exit(1);
  }
  console.log('[PASS] Missing required payee name strictly rejected.');

  // Verification 9: Decimal amount rejection
  const decimalIncomes: any[] = [
    { ...baselineIncomes[0], amount: 2000.50 },
    baselineIncomes[1],
    baselineIncomes[2],
  ];
  const decimalResult = await validateAndDigestMigrationDataset(decimalIncomes, baselineExpenses);
  if (decimalResult.valid || !decimalResult.errors.some((e) => e.includes('DECIMAL_AMOUNT_REJECTED'))) {
    console.error('[FAIL] Decimal amount was not rejected!');
    process.exit(1);
  }
  console.log('[PASS] Decimal amount strictly rejected.');

  // Verification 10: Checksum sensitivity to every included field
  // Amount
  const tamperedAmount = await computeMigrationChecksum(
    [{ ...baselineIncomes[0], amount: 2001 }, baselineIncomes[1], baselineIncomes[2]],
    baselineExpenses
  );
  if (tamperedAmount === baselineChecksum) throw new Error('Failed amount sensitivity');

  // Description
  const tamperedDesc = await computeMigrationChecksum(
    [{ ...baselineIncomes[0], description: 'മാറ്റിയ വിവരണം' }, baselineIncomes[1], baselineIncomes[2]],
    baselineExpenses
  );
  if (tamperedDesc === baselineChecksum) throw new Error('Failed description sensitivity');

  // Donor
  const tamperedDonor = await computeMigrationChecksum(
    [{ ...baselineIncomes[0], donorName: 'അലക്സ് വർഗ്ഗീസ്' }, baselineIncomes[1], baselineIncomes[2]],
    baselineExpenses
  );
  if (tamperedDonor === baselineChecksum) throw new Error('Failed donorName sensitivity');

  // Payee
  const tamperedPayee = await computeMigrationChecksum(
    baselineIncomes,
    [{ ...baselineExpenses[0], paidTo: 'രാജൻ കുമാർ' }, baselineExpenses[1]]
  );
  if (tamperedPayee === baselineChecksum) throw new Error('Failed paidTo sensitivity');

  // Heading
  const tamperedHeading = await computeMigrationChecksum(
    baselineIncomes,
    [{ ...baselineExpenses[0], headingName: 'മൈക്ക് & ലൈറ്റ്' }, baselineExpenses[1]]
  );
  if (tamperedHeading === baselineChecksum) throw new Error('Failed headingName sensitivity');

  console.log('[PASS] Full cryptographic sensitivity verified: Altering amount, description, donor, payee, or heading changes checksum.');

  // Verification 11: Non-primitive type coercion and invalid string rejection in validateWholeRupeeAmount
  const invalidAmounts = [
    true,
    false,
    [500],
    { amount: 500 },
    '1e2',
    '100e-1',
    '100.50',
    100.50,
    0,
    -10,
    5000001,
    'abc',
    null,
    undefined,
  ];

  for (const inv of invalidAmounts) {
    try {
      validateWholeRupeeAmount(inv);
      console.error(`[FAIL] validateWholeRupeeAmount did not reject invalid input:`, inv);
      process.exit(1);
    } catch {
      // Expected rejection
    }
  }
  if (validateWholeRupeeAmount(100) !== 100 || validateWholeRupeeAmount('100') !== 100) {
    console.error('[FAIL] Valid integer amount not parsed properly.');
    process.exit(1);
  }
  console.log('[PASS] Non-primitive and malformed inputs to validateWholeRupeeAmount strictly rejected.');

  // Verification 12: Optional whitespace and empty string canonicalization
  const basePayload: any = {
    amount: 1000,
    date: '2026-11-25',
    headingId: 'h-1',
    paymentMode: 'CASH',
    description: 'നേർച്ച',
  };

  const hashFromNull = await computePayloadFingerprint(canonicalizeIncomePayload({ ...basePayload, donorName: null }));
  const hashFromUndefined = await computePayloadFingerprint(canonicalizeIncomePayload({ ...basePayload, donorName: undefined }));
  const hashFromEmptyStr = await computePayloadFingerprint(canonicalizeIncomePayload({ ...basePayload, donorName: '' }));
  const hashFromWhitespace = await computePayloadFingerprint(canonicalizeIncomePayload({ ...basePayload, donorName: '   ' }));

  if (hashFromNull !== hashFromUndefined || hashFromNull !== hashFromEmptyStr || hashFromNull !== hashFromWhitespace) {
    console.error('[FAIL] Inconsistent fingerprint for empty/null/whitespace optional string:', {
      hashFromNull,
      hashFromUndefined,
      hashFromEmptyStr,
      hashFromWhitespace,
    });
    process.exit(1);
  }
  console.log('[PASS] Deterministic optional string normalization verified (null, undefined, "", "   " all produce identical hash).');

  // Verification 13: Malformed non-array input to validateAndDigestMigrationDataset
  const nonArrayResult1 = await validateAndDigestMigrationDataset(null as any, []);
  const nonArrayResult2 = await validateAndDigestMigrationDataset([], 'invalid' as any);
  if (nonArrayResult1.valid || nonArrayResult2.valid) {
    console.error('[FAIL] Non-array dataset was not rejected!');
    process.exit(1);
  }
  console.log('[PASS] Non-array dataset input strictly rejected without crashing.');

  // Verification 14: Non-string and malformed fields in records
  const malformedHeadingIncomes: any[] = [
    { ...baselineIncomes[0], headingName: 12345 },
  ];
  const malformedResult = await validateAndDigestMigrationDataset(malformedHeadingIncomes, baselineExpenses);
  if (malformedResult.valid || !malformedResult.errors.some((e) => e.includes('MISSING_FIELD'))) {
    console.error('[FAIL] Malformed non-string heading was not detected!');
    process.exit(1);
  }
  console.log('[PASS] Malformed non-string record fields detected and handled gracefully.');

  // Verification 15: Valid empty dataset
  const emptyDatasetResult = await validateAndDigestMigrationDataset([], []);
  if (!emptyDatasetResult.valid || emptyDatasetResult.totalIncomes !== 0 || emptyDatasetResult.maxHistoricalReceiptSeq !== 0) {
    console.error('[FAIL] Valid empty dataset was not handled properly!');
    process.exit(1);
  }
  console.log('[PASS] Valid empty dataset correctly handled (0 counts, 0 bounds).');

  console.log('========================================================================');
  console.log('ALL MIGRATION INTEGRITY TESTS PASSED (EXIT CODE 0)');
  console.log('========================================================================');
}

runMigrationIntegrityTests().catch((err) => {
  console.error('Fatal test error:', err);
  process.exit(1);
});
