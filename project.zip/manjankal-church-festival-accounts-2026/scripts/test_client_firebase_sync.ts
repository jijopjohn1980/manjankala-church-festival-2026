/**
 * Comprehensive Unit & Integration Test Suite for Firebase Client Integration
 * Manjankal Mar Shemavoon Desthuni Orthodox Syrian Church - 2026 Festival Accounts
 *
 * Verifies:
 * 1. Environment Variable Parsing (6 VITE_FIREBASE_* variables)
 * 2. Configuration Validation Guard (isFirebaseClientConfigured)
 * 3. RFC 4122 v4 UUID Generation (for atomic operations)
 * 4. Transaction Payload Canonicalization & SHA-256 Fingerprint Computation
 * 5. Sequence and Allocated Identifier Formatting
 * 6. Graceful Offline Fallback & Unconfigured Handling
 * 7. Verification that Super Admin identity is enforced (jijopjohn@gmail.com)
 */

import assert from 'node:assert';

// 1. Test when unconfigured
process.env.VITE_FIREBASE_API_KEY = '';
process.env.VITE_FIREBASE_PROJECT_ID = '';

async function runTests() {
  console.log('========================================================================');
  console.log('TEST SUITE: FIREBASE CLIENT INTEGRATION & CLIENT-SIDE SYNC');
  console.log('Church: Manjankal Mar Shemavoon Desthuni Orthodox Syrian Church');
  console.log('Super Admin: jijopjohn@gmail.com');
  console.log('========================================================================\n');

  // Test 1: Empty / Unconfigured Environment
  console.log('--- Test 1: Unconfigured Environment Guard ---');
  const firebaseModule = await import('../src/services/firebase');
  assert.strictEqual(
    firebaseModule.isFirebaseClientConfigured(),
    false,
    'Expected isFirebaseClientConfigured() to be false when API key and project ID are empty'
  );
  console.log('✓ Correctly identified unconfigured state when environment variables are blank');

  // Test 2: Unconfigured commitIncomeToFirestore fallback
  const syncModule = await import('../src/services/firestoreSync');
  const unconfiguredIncomeRes = await syncModule.commitIncomeToFirestore('2026', {
    date: '2026-11-22',
    headingId: 'head-1',
    headingName: 'നേർച്ച',
    amount: 1000,
    paymentMode: 'CASH',
    description: 'നേർച്ച വരവ്',
  });
  assert.strictEqual(unconfiguredIncomeRes.success, false);
  assert(
    unconfiguredIncomeRes.error?.includes('Firebase is not configured'),
    'Expected clean fallback error message when Firebase is not configured'
  );
  console.log('✓ commitIncomeToFirestore safely reports unconfigured state without crashing');

  // Test 3: Unconfigured commitExpenseToFirestore fallback
  const unconfiguredExpenseRes = await syncModule.commitExpenseToFirestore('2026', {
    date: '2026-11-22',
    headingId: 'head-2',
    headingName: 'സദ്യ',
    amount: 500,
    paymentMode: 'CASH',
    description: 'പച്ചക്കറി',
    paidTo: 'ജോൺ',
  });
  assert.strictEqual(unconfiguredExpenseRes.success, false);
  assert(
    unconfiguredExpenseRes.error?.includes('Firebase is not configured'),
    'Expected clean fallback error message when Firebase is not configured'
  );
  console.log('✓ commitExpenseToFirestore safely reports unconfigured state without crashing');

  // Test 4: Unconfigured subscribeToYearAccounting returns safe no-op unsubscribe function
  const unsubNoop = syncModule.subscribeToYearAccounting('2026', () => {});
  assert.strictEqual(typeof unsubNoop, 'function');
  unsubNoop(); // Must not throw
  console.log('✓ subscribeToYearAccounting returns safe no-op unsubscribe function when unconfigured');

  // Test 5: Verify RFC 4122 v4 UUID generator
  console.log('\n--- Test 2: RFC 4122 v4 UUID Generation ---');
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  for (let i = 0; i < 10; i++) {
    const uuid = syncModule.generateV4Uuid();
    assert(
      uuidRegex.test(uuid),
      `Generated UUID "${uuid}" does not strictly match RFC 4122 v4 specification`
    );
  }
  console.log('✓ Successfully validated 10 distinct RFC 4122 v4 UUIDs for atomic operations');

  // Test 6: Verify Payload Canonicalization & SHA-256 Fingerprinting
  console.log('\n--- Test 3: Canonicalization & SHA-256 Fingerprinting ---');
  const {
    canonicalizeIncomePayload,
    canonicalizeExpensePayload,
    computePayloadFingerprint,
    formatReceiptNumber,
    formatVoucherNumber,
  } = await import('../src/utils/payloadNormalization');

  const incomePayloadA = {
    date: '2026-11-22',
    headingId: 'head-nercha',
    headingName: 'നേർച്ച',
    amount: 5000,
    paymentMode: 'CASH' as const,
    description: 'പ്രത്യേക വഴിപാട്',
    donorName: 'ജോസഫ് വർക്കി',
    donorAddress: 'മഞ്ഞങ്കൽ',
    referenceNumber: '',
    collectedBy: 'ട്രഷറർ',
  };

  const incomePayloadB = {
    // Permuted property order
    collectedBy: 'ട്രഷറർ',
    description: 'പ്രത്യേക വഴിപാട്',
    amount: 5000,
    headingName: 'നേർച്ച',
    headingId: 'head-nercha',
    donorAddress: 'മഞ്ഞങ്കൽ',
    donorName: 'ജോസഫ് വർക്കി',
    paymentMode: 'CASH' as const,
    date: '2026-11-22',
    referenceNumber: '',
  };

  const canonicalA = canonicalizeIncomePayload(incomePayloadA);
  const canonicalB = canonicalizeIncomePayload(incomePayloadB);
  assert.strictEqual(canonicalA, canonicalB, 'Canonicalized string must be identical regardless of key order');

  const hashA = await computePayloadFingerprint(canonicalA);
  const hashB = await computePayloadFingerprint(canonicalB);
  assert.strictEqual(hashA, hashB, 'SHA-256 fingerprint must match for permuted key payloads');
  assert.strictEqual(hashA.length, 64, 'SHA-256 hash must be 64 hexadecimal characters');
  console.log('✓ Income payload canonicalization and SHA-256 fingerprinting verified (Hash: ' + hashA.substring(0, 16) + '...)');

  // Test 7: Expense Payload Canonicalization
  const expensePayload = {
    date: '2026-11-23',
    headingId: 'head-sadya',
    headingName: 'സദ്യ',
    amount: 12500,
    paymentMode: 'BANK' as const,
    description: 'അരിയും പലവ്യഞ്ജനങ്ങളും',
    paidTo: 'മഞ്ഞങ്കൽ സ്റ്റോർസ്',
    voucherCategory: 'ഭക്ഷണം',
    referenceNumber: 'TXN12345678',
    authorizedBy: 'കൺവീനർ',
  };
  const canonicalExp = canonicalizeExpensePayload(expensePayload);
  const hashExp = await computePayloadFingerprint(canonicalExp);
  assert.strictEqual(hashExp.length, 64);
  console.log('✓ Expense payload canonicalization and SHA-256 fingerprinting verified (Hash: ' + hashExp.substring(0, 16) + '...)');

  // Test 8: Sequence Formatting Integrity
  console.log('\n--- Test 4: Receipt and Voucher Number Formatting ---');
  assert.strictEqual(formatReceiptNumber(1, '2026'), 'R-2026-001');
  assert.strictEqual(formatReceiptNumber(42, '2026'), 'R-2026-042');
  assert.strictEqual(formatReceiptNumber(999, '2026'), 'R-2026-999');
  assert.strictEqual(formatReceiptNumber(1000, '2026'), 'R-2026-1000');

  assert.strictEqual(formatVoucherNumber(1, '2026'), 'V-2026-001');
  assert.strictEqual(formatVoucherNumber(85, '2026'), 'V-2026-085');
  assert.strictEqual(formatVoucherNumber(1250, '2026'), 'V-2026-1250');
  console.log('✓ Zero-padded sequential numbering confirmed for receipts (R-2026-XXX) and vouchers (V-2026-XXX)');

  // Test 9: Super Admin Authorization Constant
  console.log('\n--- Test 5: Super Admin Authorization Hardening ---');
  const { SUPER_ADMIN_EMAIL } = await import('../src/utils/auth');
  assert.strictEqual(SUPER_ADMIN_EMAIL, 'jijopjohn@gmail.com');
  console.log('✓ SUPER_ADMIN_EMAIL strictly locked to jijopjohn@gmail.com');

  console.log('\n========================================================================');
  console.log('ALL CLIENT-SIDE FIREBASE INTEGRATION TESTS PASSED (100%)');
  console.log('========================================================================');
}

runTests().catch((err) => {
  console.error('\n[TEST FAILURE]:', err);
  process.exit(1);
});
