import assert from 'node:assert';
import { AppState, YearAccountingData, FestivalYear, AuditLog } from '../src/types/festival';
import { createCleanInitialState, isValidAppStateSchema, saveAppState, loadAppState, STORAGE_KEY } from '../src/utils/storage';
import { authenticateSuperAdmin, changeSuperAdminPin, getSecurityStatus, SUPER_ADMIN_EMAIL } from '../src/utils/auth';

console.log('=== STARTING MANDATORY PIN & AUDIT DURABILITY VERIFICATION ===\n');

// Mock localStorage in Node.js environment
const memoryStore: Record<string, string> = {};
const mockLocalStorage = {
  getItem: (key: string) => memoryStore[key] || null,
  setItem: (key: string, val: string) => { memoryStore[key] = val; },
  removeItem: (key: string) => { delete memoryStore[key]; },
  clear: () => { Object.keys(memoryStore).forEach(k => delete memoryStore[k]); }
};
(globalThis as any).localStorage = mockLocalStorage;
(globalThis as any).sessionStorage = mockLocalStorage;

// -------------------------------------------------------------
// ITEM 1: Mandatory PIN Change Enforcement & Bypass Protection
// -------------------------------------------------------------
console.log('[TEST 1] Mandatory PIN Change Enforcement:');

// Initial state before custom PIN is created
const initialStatus = getSecurityStatus();
console.log('  Initial security status hasCustomPin:', initialStatus.hasCustomPin);
assert.strictEqual(initialStatus.hasCustomPin, false, 'Initial state must indicate default PIN is active');

// Simulation of App.tsx checkPinRequirement guard
let attemptedIncomeAdd = false;
function attemptAddIncome(incomeData: any) {
  const status = getSecurityStatus();
  if (!status.hasCustomPin) {
    // BLOCKED: Must change PIN before any accounting records can be touched
    return { blocked: true, reason: 'PIN_CHANGE_REQUIRED' };
  }
  attemptedIncomeAdd = true;
  return { blocked: false, success: true };
}

// 1a. Attempt to add record while default PIN is active
const result1 = attemptAddIncome({ amount: 500, donorName: 'John' });
assert.strictEqual(result1.blocked, true, 'Must block income creation when default PIN is active');
assert.strictEqual(attemptedIncomeAdd, false, 'No income record should be added');
console.log('  ✓ Addition blocked while default PIN (221126) is active');

// 1b. Test refresh / reopening simulation (localStorage preserved)
console.log('  Testing refresh/reopen simulation...');
const statusAfterReload = getSecurityStatus();
assert.strictEqual(statusAfterReload.hasCustomPin, false, 'Reopening or refreshing must NOT bypass PIN requirement');
const resultReload = attemptAddIncome({ amount: 1000, donorName: 'Philip' });
assert.strictEqual(resultReload.blocked, true, 'Must still block after refresh/reopen');
console.log('  ✓ Refresh/reopen bypass protection verified: still blocked');

// 1c. Successfully change the PIN to a custom PIN
console.log('  Changing PIN via changeSuperAdminPin...');
// Authenticate first
await authenticateSuperAdmin(SUPER_ADMIN_EMAIL, '221126');
const changeResult = await changeSuperAdminPin('221126', '885522');
assert.strictEqual(changeResult.success, true, 'PIN change must succeed with valid current PIN');

// 1d. Verify that hasCustomPin is now true
const statusAfterCustomPin = getSecurityStatus();
assert.strictEqual(statusAfterCustomPin.hasCustomPin, true, 'hasCustomPin must be true after changing PIN');
console.log('  ✓ hasCustomPin is now TRUE after valid custom PIN set');

// 1e. Now income addition is allowed
const result2 = attemptAddIncome({ amount: 500, donorName: 'John' });
assert.strictEqual(result2.blocked, false, 'Must allow income creation once custom PIN is set');
assert.strictEqual(result2.success, true);
assert.strictEqual(attemptedIncomeAdd, true);
console.log('  ✓ Accounting mutations permitted once custom PIN is established');


// -------------------------------------------------------------
// ITEM 2: Audit Log Durability & Deduplication on Retry
// -------------------------------------------------------------
console.log('\n[TEST 2] Audit Log Durability & Queuing Integrity:');

const testState: AppState = createCleanInitialState();
const audit1: AuditLog = {
  id: 'log-1730000000-abc12',
  timestamp: new Date().toISOString(),
  userEmail: SUPER_ADMIN_EMAIL,
  action: 'ADD_INCOME',
  summaryMl: 'വരവ് രസീത് ചേർത്തു: R-2026-001 - തോമസ് (₹5,000)',
  amount: 5000,
  details: { receiptNumber: 'R-2026-001' },
};
const audit2: AuditLog = {
  id: 'log-1730000001-def34',
  timestamp: new Date().toISOString(),
  userEmail: SUPER_ADMIN_EMAIL,
  action: 'ADD_EXPENSE',
  summaryMl: 'ചിലവ് വൗച്ചർ ചേർത്തു: V-2026-001 - ലൈറ്റ് & സൗണ്ട്സ് (₹12,000)',
  amount: 12000,
  details: { voucherNumber: 'V-2026-001' },
};

testState.auditLogs = [audit1, audit2];

// 2a. Save state to localStorage with exact read-back verification
const saveRes = saveAppState(testState);
assert.strictEqual(saveRes.success, true, 'saveAppState must succeed');

// 2b. Load state from storage and verify exact persistence
const loadedState = loadAppState();
assert.strictEqual(loadedState.auditLogs?.length, 2, 'Must persist all audit records in storage');
assert.strictEqual(loadedState.auditLogs?.[0].id, 'log-1730000000-abc12');
assert.strictEqual(loadedState.auditLogs?.[1].id, 'log-1730000001-def34');
console.log('  ✓ Audit records durability confirmed through saveAppState & exact content verification');

// 2c. Test queuing & deduplication logic for future Firebase uploads
console.log('  Testing upload retry deduplication using deterministic log.id:');
const cloudDatabaseMock: Record<string, AuditLog> = {};

function uploadAuditLogToCloud(log: AuditLog): { success: boolean } {
  // Idempotent set operation: doc(log.id).set(log)
  cloudDatabaseMock[log.id] = { ...log };
  return { success: true };
}

// First upload attempt
uploadAuditLogToCloud(audit1);
assert.strictEqual(Object.keys(cloudDatabaseMock).length, 1);

// Retry upload attempt (simulating network drop recovery)
uploadAuditLogToCloud(audit1);
assert.strictEqual(Object.keys(cloudDatabaseMock).length, 1, 'Retry must NOT create duplicate audit log');

uploadAuditLogToCloud(audit2);
assert.strictEqual(Object.keys(cloudDatabaseMock).length, 2);
console.log('  ✓ Deterministic log.id prevents duplicate audit records on upload retries');

console.log('\n============================================================');
console.log('ALL MANDATORY PIN & AUDIT DURABILITY TESTS PASSED: 100%');
console.log('============================================================');
