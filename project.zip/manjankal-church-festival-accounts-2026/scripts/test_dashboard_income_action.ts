import { readFileSync } from 'fs';

console.log('=== VERIFYING DASHBOARD ADD INCOME TRANSACTION ACTION ===\n');

// 1. Verify SummaryCards.tsx has the separate and clearly labelled buttons
const summaryCardsContent = readFileSync('src/components/SummaryCards.tsx', 'utf-8');

console.log('[TEST 1] Checking SummaryCards.tsx:');
const hasAddIncomeTxButton = summaryCardsContent.includes('+ Add Income Transaction / + പുതിയ വരവ് രേഖപ്പെടുത്തുക');
const hasHeadingButton = summaryCardsContent.includes('+ വരവ് ശീർഷകം');
const hasFloatingButton = summaryCardsContent.includes('fixed bottom-6 right-6');
const hasOnOpenAddIncomeProp = summaryCardsContent.includes('onOpenAddIncome: () => void');

if (!hasAddIncomeTxButton) {
  throw new Error('FAIL: SummaryCards.tsx missing "+ Add Income Transaction / + പുതിയ വരവ് രേഖപ്പെടുത്തുക" button label');
}
console.log('  ✓ "+ Add Income Transaction / + പുതിയ വരവ് രേഖപ്പെടുത്തുക" button label present');

if (!hasHeadingButton) {
  throw new Error('FAIL: SummaryCards.tsx missing existing "+ വരവ് ശീർഷകം" button');
}
console.log('  ✓ Existing Add Income Heading button "+ വരവ് ശീർഷകം" kept intact and unchanged');

if (!hasFloatingButton) {
  throw new Error('FAIL: Floating Action Button missing on Dashboard');
}
console.log('  ✓ Floating Action Button present on Dashboard');

if (!hasOnOpenAddIncomeProp) {
  throw new Error('FAIL: onOpenAddIncome prop missing in SummaryCardsProps');
}
console.log('  ✓ onOpenAddIncome prop properly passed and wired in SummaryCardsProps');

// 2. Verify App.tsx wiring
console.log('\n[TEST 2] Checking App.tsx wiring:');
const appContent = readFileSync('src/App.tsx', 'utf-8');
const hasHandleOpenAddIncome = appContent.includes('handleOpenAddIncomeFromDashboard');
const hasAutoOpenIncomeState = appContent.includes('autoOpenIncomeModal');
const hasAutoOpenPassedToIncome = appContent.includes('autoOpenAdd={autoOpenIncomeModal}');

if (!hasHandleOpenAddIncome || !hasAutoOpenIncomeState || !hasAutoOpenPassedToIncome) {
  throw new Error('FAIL: App.tsx missing wiring for handleOpenAddIncomeFromDashboard or autoOpenAdd');
}
console.log('  ✓ App.tsx correctly manages autoOpenIncomeModal and wires to IncomeManager');

// 3. Verify IncomeManager.tsx opens form with Donor Name field
console.log('\n[TEST 3] Checking IncomeManager.tsx form:');
const incomeManagerContent = readFileSync('src/components/IncomeManager.tsx', 'utf-8');
const hasAutoOpenEffect = incomeManagerContent.includes('autoOpenAdd') && incomeManagerContent.includes('handleOpenAdd()');
const hasDonorNameField = incomeManagerContent.includes('Name of Donor / Contributor');
const hasDonorPlaceholder = incomeManagerContent.includes('Enter the name of the person who made the donation');

if (!hasAutoOpenEffect) {
  throw new Error('FAIL: IncomeManager.tsx missing autoOpenAdd effect');
}
console.log('  ✓ IncomeManager.tsx responds to autoOpenAdd by opening the form');

if (!hasDonorNameField || !hasDonorPlaceholder) {
  throw new Error('FAIL: IncomeManager.tsx missing Donor Name field or placeholder');
}
console.log('  ✓ Income form contains "Name of Donor / Contributor" with exact placeholder');

// 4. Verify Expense form has NOT been given donorName
console.log('\n[TEST 4] Verify Expense form unaffected:');
const expenseContent = readFileSync('src/components/ExpenseManager.tsx', 'utf-8');
if (expenseContent.includes('donorName')) {
  throw new Error('FAIL: ExpenseManager unexpectedly contains donorName');
}
console.log('  ✓ ExpenseManager remains completely unaffected without donorName');

console.log('\n============================================================');
console.log('ALL DASHBOARD INCOME ACTION VERIFICATION TESTS PASSED: 100%');
console.log('============================================================');
