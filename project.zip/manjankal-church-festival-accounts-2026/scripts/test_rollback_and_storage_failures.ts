/**
 * Test Suite: Rollback Schema Validation, Archive Safeguard & Exact Content Storage Verification
 * 
 * Verifies:
 * 1. handleRollbackToSnapshot rejects corrupted JSON, missing parsed.state, and schema violations.
 * 2. handleRollbackToSnapshot CANCELS if archiving current appState fails.
 * 3. handleRollbackToSnapshot preserves primary safety snapshot without overwrite.
 * 4. saveAppState catches QuotaExceededError and never reports false success.
 * 5. Exact content read-back verification (readBack !== serialized) traps character-level mismatch even with identical length.
 */

import { AppState } from '../src/types/festival';
import { createCleanInitialState, isValidAppStateSchema, saveAppState, STORAGE_KEY } from '../src/utils/storage';

class MockFailingStorage {
  private store: Map<string, string> = new Map();
  public quotaExceeded: boolean = false;
  public truncateWrites: boolean = false;
  public tamperWritesSameLength: boolean = false;
  public failArchiveOnly: boolean = false;

  setItem(key: string, value: string): void {
    if (this.failArchiveOnly && key.startsWith('church_festival_archive_before_rollback')) {
      const err: any = new Error('Quota exceeded while archiving current state.');
      err.name = 'QuotaExceededError';
      throw err;
    }
    if (this.quotaExceeded) {
      const err: any = new Error('The quota has been exceeded.');
      err.name = 'QuotaExceededError';
      err.code = 22;
      throw err;
    }
    if (this.truncateWrites) {
      // Simulate truncated write
      this.store.set(key, value.substring(0, Math.floor(value.length / 2)));
      return;
    }
    if (this.tamperWritesSameLength) {
      // Replace last character with 'X' keeping length identical
      const tampered = value.slice(0, -1) + 'X';
      this.store.set(key, tampered);
      return;
    }
    this.store.set(key, value);
  }

  getItem(key: string): string | null {
    return this.store.get(key) || null;
  }

  removeItem(key: string): void {
    this.store.delete(key);
  }

  clear(): void {
    this.store.clear();
  }
}

function runTests() {
  console.log('=== STARTING ROLLBACK & EXACT CONTENT STORAGE FAILURE TESTS ===\n');

  // TEST 1: Schema Validation on Malformed Snapshots
  console.log('[TEST 1] Testing Schema Validator on various malformed payloads...');
  
  const validState = createCleanInitialState();
  if (!isValidAppStateSchema(validState)) {
    console.error('[FAIL] Clean initial state was rejected by schema validator!');
    process.exit(1);
  }

  // Malformed 1: Missing years
  const bad1 = { activeYearId: '2026', dataByYear: {} };
  // Malformed 2: Missing activeYearId
  const bad2 = { years: validState.years, dataByYear: validState.dataByYear };
  // Malformed 3: Corrupted amounts (string instead of number)
  const bad3 = JSON.parse(JSON.stringify(validState));
  bad3.dataByYear['2026'].incomes.push({ id: 'inc-bad', amount: 'NaN', receiptNumber: 'R1' });
  // Malformed 4: Empty object or null
  const bad4 = null;

  if (
    !isValidAppStateSchema(bad1) &&
    !isValidAppStateSchema(bad2) &&
    !isValidAppStateSchema(bad3) &&
    !isValidAppStateSchema(bad4)
  ) {
    console.log('[PASS] Test 1: Schema validator successfully rejected all malformed payloads.');
  } else {
    console.error('[FAIL] Test 1: Schema validator allowed a malformed payload!');
    process.exit(1);
  }

  // TEST 2: Rollback Fail-Safe & Archive Failure Cancellation
  console.log('\n[TEST 2] Testing rollback failure cases (missing state, invalid JSON, schema failure, archive failure)...');
  
  const mockStorage = new MockFailingStorage();
  const currentUnchangedState = validState;

  function simulateRollback(storage: MockFailingStorage, current: AppState): { success: boolean; state: AppState; error?: string } {
    const raw = storage.getItem('church_festival_pre_restore_safety_snapshot');
    if (!raw) return { success: false, state: current, error: 'Snapshot not found' };

    let parsed: any;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return { success: false, state: current, error: 'Invalid JSON' };
    }

    if (!parsed || typeof parsed !== 'object' || !parsed.state) {
      return { success: false, state: current, error: 'Missing parsed.state' };
    }

    if (!isValidAppStateSchema(parsed.state)) {
      return { success: false, state: current, error: 'Schema validation failed' };
    }

    // MANDATORY FAIL-SAFE: Archive current before rollback; CANCEL if archive fails
    try {
      const archivePayload = JSON.stringify({ state: current });
      storage.setItem('church_festival_archive_before_rollback', archivePayload);
      const readBack = storage.getItem('church_festival_archive_before_rollback');
      if (!readBack || readBack !== archivePayload) {
        throw new Error('Archive verification mismatch');
      }
    } catch (archiveErr: any) {
      return {
        success: false,
        state: current, // Current state untouched
        error: `Archive failure cancelled rollback: ${archiveErr.message}`,
      };
    }

    // Only restore after verified archive
    return { success: true, state: parsed.state };
  }

  // Case A: Missing snapshot
  const resA = simulateRollback(mockStorage, currentUnchangedState);
  if (!resA.success && resA.error === 'Snapshot not found' && resA.state === currentUnchangedState) {
    console.log('Case A (Missing snapshot -> Aborted): Passed');
  }

  // Case B: Corrupted JSON
  mockStorage.setItem('church_festival_pre_restore_safety_snapshot', '{ malformed json !!');
  const resB = simulateRollback(mockStorage, currentUnchangedState);
  if (!resB.success && resB.error === 'Invalid JSON' && resB.state === currentUnchangedState) {
    console.log('Case B (Corrupted JSON -> Aborted): Passed');
  }

  // Case C: Missing parsed.state
  mockStorage.setItem('church_festival_pre_restore_safety_snapshot', JSON.stringify({ yearCount: 1 }));
  const resC = simulateRollback(mockStorage, currentUnchangedState);
  if (!resC.success && resC.error === 'Missing parsed.state' && resC.state === currentUnchangedState) {
    console.log('Case C (Missing parsed.state -> Aborted): Passed');
  }

  // Case D: Schema failure in state
  mockStorage.setItem('church_festival_pre_restore_safety_snapshot', JSON.stringify({ state: bad1 }));
  const resD = simulateRollback(mockStorage, currentUnchangedState);
  if (!resD.success && resD.error === 'Schema validation failed' && resD.state === currentUnchangedState) {
    console.log('Case D (Schema validation failure -> Aborted): Passed');
  }

  // Case E: Archive Failure -> MUST CANCEL ROLLBACK COMPLETELY
  const candidateState = createCleanInitialState();
  candidateState.dataByYear['2026'].lastReceiptSeq = 99;
  mockStorage.setItem(
    'church_festival_pre_restore_safety_snapshot',
    JSON.stringify({ savedAt: new Date().toISOString(), state: candidateState })
  );
  mockStorage.failArchiveOnly = true;

  const resE = simulateRollback(mockStorage, currentUnchangedState);
  if (
    !resE.success &&
    resE.error &&
    resE.error.includes('Archive failure cancelled rollback') &&
    resE.state === currentUnchangedState // Current state is strictly preserved
  ) {
    console.log('Case E (Archive failure -> Rollback cancelled & current state preserved): Passed');
  } else {
    console.error('[FAIL] Case E: Rollback should have been cancelled when archive failed!', resE);
    process.exit(1);
  }

  // Case F: Normal Rollback Success & Preservation
  mockStorage.failArchiveOnly = false;
  const resF = simulateRollback(mockStorage, currentUnchangedState);
  const snapshotAfterRollback = mockStorage.getItem('church_festival_pre_restore_safety_snapshot');
  const archiveAfterRollback = mockStorage.getItem('church_festival_archive_before_rollback');

  if (
    resF.success &&
    resF.state.dataByYear['2026'].lastReceiptSeq === 99 &&
    snapshotAfterRollback !== null &&
    archiveAfterRollback !== null
  ) {
    console.log('Case F (Valid rollback & safety snapshot preserved): Passed');
    console.log('[PASS] Test 2: All rollback validation and archive cancellation tests passed.');
  } else {
    console.error('[FAIL] Test 2 Case F failed!');
    process.exit(1);
  }

  // TEST 3: Exact Content Read-Back Verification (readBack !== serialized)
  console.log('\n[TEST 3] Testing exact content read-back verification (readBack !== serialized)...');

  (global as any).localStorage = mockStorage;

  // 3a. Normal save
  mockStorage.quotaExceeded = false;
  mockStorage.truncateWrites = false;
  mockStorage.tamperWritesSameLength = false;
  const normalSave = saveAppState(validState);
  if (normalSave.success) {
    console.log('Normal save: Succeeded with exact content match');
  }

  // 3b. Quota Exceeded write
  mockStorage.quotaExceeded = true;
  const quotaSave = saveAppState(validState);
  if (!quotaSave.success && quotaSave.error && quotaSave.error.includes('Quota Exceeded')) {
    console.log(`QuotaExceeded trapped: "${quotaSave.error}"`);
    console.log('[PASS] Test 3a: QuotaExceededError successfully caught.');
  } else {
    console.error('[FAIL] QuotaExceededError was not caught!', quotaSave);
    process.exit(1);
  }

  // 3c. Exact Content Tampering Test (Identical length, but 1 byte corrupted)
  mockStorage.quotaExceeded = false;
  mockStorage.tamperWritesSameLength = true;
  const tamperedSave = saveAppState(validState);
  if (
    !tamperedSave.success &&
    tamperedSave.error &&
    tamperedSave.error.includes('does not exactly match serialized state')
  ) {
    console.log(`Tampered content trapped: "${tamperedSave.error}"`);
    console.log('[PASS] Test 3b: Exact content comparison (readBack !== serialized) caught single-character corruption.');
  } else {
    console.error('[FAIL] Exact content check failed to detect single-character corruption!', tamperedSave);
    process.exit(1);
  }

  console.log('\n=== ALL TESTS PASSED: 100% SUCCESS ===');
}

runTests();
