/**
 * Automated Verification: Source Code ZIP Archive Integrity
 * Manjankal Mar Shemavoon Desthuni Orthodox Syrian Church - 2026 Festival Accounts
 */

import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

console.log("========================================================================");
console.log("AUDIT: SOURCE CODE ZIP ARCHIVE INTEGRITY & EXTRACTION TEST");
console.log("========================================================================");

const ZIP_PATH = path.resolve('public/manjankal-church-festival-accounts-2026.zip');
const EXTRACT_DIR = '/tmp/manjankal_zip_test_extract';

// 1. VERIFY ARCHIVE EXISTENCE & SIZE
if (!fs.existsSync(ZIP_PATH)) {
  throw new Error(`ZIP archive not found at ${ZIP_PATH}`);
}
const stat = fs.statSync(ZIP_PATH);
console.log(`[PASS] ZIP archive found: ${ZIP_PATH}`);
console.log(`       Size: ${(stat.size / 1024 / 1024).toFixed(2)} MB (${stat.size} bytes)`);

if (stat.size < 1000000) {
  throw new Error("ZIP archive unexpectedly small (< 1 MB)!");
}

// 2. EXTRACT ARCHIVE INTO CLEAN TEMPORARY DIRECTORY USING PYTHON ZIPFILE
console.log("\n--- Step 2: Unpacking archive to isolated temporary sandbox ---");
if (fs.existsSync(EXTRACT_DIR)) {
  fs.rmSync(EXTRACT_DIR, { recursive: true, force: true });
}
fs.mkdirSync(EXTRACT_DIR, { recursive: true });

execSync(`python3 -c "
import zipfile
with zipfile.ZipFile('${ZIP_PATH}', 'r') as z:
    z.extractall('${EXTRACT_DIR}')
"`);

const rootFolder = path.join(EXTRACT_DIR, 'manjankal-church-festival-accounts-2026');
if (!fs.existsSync(rootFolder)) {
  throw new Error(`Expected root folder not found: ${rootFolder}`);
}
console.log(`[PASS] Extracted successfully to: ${rootFolder}`);

// 3. AUDIT REQUIRED SOURCE FILES
console.log("\n--- Step 3: Auditing Mandatory Source Files in Extracted Code ---");
const requiredFiles = [
  'package.json',
  'package-lock.json',
  'tsconfig.json',
  'vite.config.ts',
  'netlify.toml',
  'firebase.json',
  'firebase-blueprint.json',
  'firestore.rules',
  'server.ts',
  'capacitor.config.json',
  'capacitor.config.ts',
  '.github/workflows/build-android.yml',
  'index.html',
  'metadata.json',
  'README.md',
  '.env.example',
  'src/App.tsx',
  'src/main.tsx',
  'src/index.css',
  'src/types/festival.ts',
  'src/utils/storage.ts',
  'src/utils/auth.ts',
  'src/utils/payloadNormalization.ts',
  'src/utils/numberToMalayalamWords.ts',
  'src/utils/exportPdf.ts',
  'src/utils/exportExcel.ts',
  'src/components/Header.tsx',
  'src/components/IncomeManager.tsx',
  'src/components/ExpenseManager.tsx',
  'src/components/HeadingsManager.tsx',
  'src/components/ReportsView.tsx',
  'src/components/SummaryCards.tsx',
  'src/components/AuditLogView.tsx',
  'src/components/BackupRestoreModal.tsx',
  'src/components/SecurityAuditModal.tsx',
  'src/components/PWAInstallButton.tsx',
  'src/hooks/usePWAInstall.ts',
  'public/manifest.json',
  'public/sw.js',
  'public/pwa-192x192.png',
  'public/pwa-512x512.png',
  'public/pwa-maskable-512x512.png',
  'public/apple-touch-icon.png',
  'public/favicon.png',
  'public/_redirects',
  'public/assets/aistudio/Untitled-1_copy_557a904e.jpg',
  'public/assets/aistudio/arch_dedc7e87.jpg',
  'scripts/test_rules_matrix.ts',
  'scripts/test_migration_checksum.ts',
  'scripts/test_pwa_compliance.ts',
];

for (const relPath of requiredFiles) {
  const full = path.join(rootFolder, relPath);
  if (!fs.existsSync(full)) {
    throw new Error(`MISSING REQUIRED FILE: ${relPath}`);
  }
}
console.log(`[PASS] All ${requiredFiles.length} mandatory source files verified present.`);

// 4. AUDIT STRICT EXCLUSION OF SENSITIVE & ARTIFACT FILES
console.log("\n--- Step 4: Auditing Security Invariants (No secrets, node_modules, or git) ---");

function walkDir(dir: string, fileList: string[] = []): string[] {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      walkDir(full, fileList);
    } else {
      fileList.push(full);
    }
  }
  return fileList;
}

const allExtractedFiles = walkDir(rootFolder);
console.log(`  Total extracted files: ${allExtractedFiles.length}`);

for (const filePath of allExtractedFiles) {
  const rel = path.relative(rootFolder, filePath);

  // Check 1: No node_modules
  if (rel.includes('node_modules')) {
    throw new Error(`SECURITY FAILURE: node_modules detected in archive: ${rel}`);
  }

  // Check 2: No .git (allow .github explicitly)
  if (rel === '.git' || rel.startsWith('.git/') || rel.startsWith('.git\\') || rel.includes('/.git/')) {
    throw new Error(`SECURITY FAILURE: .git directory detected in archive: ${rel}`);
  }

  // Check 3: No live .env or secrets
  const base = path.basename(rel);
  if (base.startsWith('.env') && base !== '.env.example') {
    throw new Error(`SECURITY FAILURE: Environment secret file detected in archive: ${rel}`);
  }

  // Check 4: No log files
  if (base.endsWith('.log')) {
    throw new Error(`CLEANLINESS FAILURE: Log file detected in archive: ${rel}`);
  }

  // Check 5: No nested .zip files
  if (base.endsWith('.zip')) {
    throw new Error(`RECURSION FAILURE: Nested ZIP file detected inside archive: ${rel}`);
  }
}

console.log("[PASS] Zero sensitive secrets, node_modules, git directories, or log files found.");

// 5. TEST EXTRACTED PACKAGE.JSON & CONFIG PARSING
console.log("\n--- Step 5: Testing Extracted package.json & Configuration Parsing ---");
const extractedPkg = JSON.parse(fs.readFileSync(path.join(rootFolder, 'package.json'), 'utf-8'));
const extractedCap = JSON.parse(fs.readFileSync(path.join(rootFolder, 'capacitor.config.json'), 'utf-8'));
const extractedManifest = JSON.parse(fs.readFileSync(path.join(rootFolder, 'public/manifest.json'), 'utf-8'));

if (!extractedPkg.dependencies?.react) throw new Error("Extracted package.json missing react!");
if (!extractedPkg.dependencies?.firebase) throw new Error("Extracted package.json missing firebase!");
if (extractedCap.appId !== 'org.manjankal.church.accounts2026') throw new Error("Extracted capacitor config invalid!");
if (extractedManifest.short_name !== 'പെരുന്നാൾ') throw new Error("Extracted manifest invalid!");

console.log(`  React version in extracted package.json: ${extractedPkg.dependencies.react}`);
console.log(`  Firebase version in extracted package.json: ${extractedPkg.dependencies.firebase}`);
console.log(`  Capacitor App ID in extracted config: ${extractedCap.appId}`);
console.log(`  PWA App Name in extracted manifest: ${extractedManifest.name}`);
console.log("[PASS] Extracted project configuration is completely valid and ready for npm install.");

// Clean up sandbox
fs.rmSync(EXTRACT_DIR, { recursive: true, force: true });
console.log("\n========================================================================");
console.log(">>> SOURCE CODE ZIP ARCHIVE INTEGRITY AUDIT PASSED 100% <<<");
console.log("========================================================================");
