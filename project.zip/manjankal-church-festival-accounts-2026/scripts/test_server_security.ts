/**
 * Security Assertion Suite for server.ts requireSuperAdminAuth & Bootstrap
 * 
 * Verifies that:
 * 1. Forged headers (x-admin-email) are rejected (HTTP 401).
 * 2. Invalid/tampered Bearer tokens are rejected (HTTP 401).
 * 3. Wrong project tokens are rejected (HTTP 401).
 * 4. Missing tokens are rejected (HTTP 401).
 * 5. Bootstrap endpoint rejects unauthorized/forged attempts (HTTP 401/403).
 * 6. Audit endpoints fail closed on missing database record or database error (HTTP 403).
 */

async function runSecurityTests() {
  const BASE_URL = 'http://localhost:3000';
  let passedCount = 0;
  let totalCount = 0;

  async function assertCase(
    name: string,
    url: string,
    options: RequestInit,
    expectedStatus: number,
    expectedErrorCode: string
  ) {
    totalCount++;
    try {
      const res = await fetch(url, options);
      const data = await res.json().catch(() => ({}));
      const statusMatch = res.status === expectedStatus;
      const errorMatch = data.error === expectedErrorCode;

      if (statusMatch && errorMatch) {
        passedCount++;
        console.log(`[PASS] ${name} -> HTTP ${res.status} [${data.error}]`);
      } else {
        console.error(
          `[FAIL] ${name} -> Expected ${expectedStatus} [${expectedErrorCode}], got HTTP ${res.status} [${data.error}]`
        );
      }
    } catch (err: any) {
      console.error(`[ERROR] ${name} -> ${err.message}`);
    }
  }

  console.log('=== STARTING BACKEND SECURITY ATTACK TESTS ===\n');

  // Test 1: Forged x-admin-email header (No Bearer token)
  await assertCase(
    'Attack 1: Forged x-admin-email header without Bearer token',
    `${BASE_URL}/api/audit`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-admin-email': 'jijopjohn@gmail.com',
      },
      body: JSON.stringify({ action: 'ATTACK', summaryMl: 'Spoofed header' }),
    },
    401,
    'UNAUTHORIZED'
  );

  // Test 2: Forged Bearer token with fake signature
  await assertCase(
    'Attack 2: Forged Bearer token with arbitrary unsigned payload',
    `${BASE_URL}/api/audit`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer eyJhbGciOiJub25lIn0.eyJlbWFpbCI6Imppam9wam9obkBnbWFpbC5jb20ifQ.',
      },
      body: JSON.stringify({ action: 'ATTACK', summaryMl: 'Unsigned JWT' }),
    },
    401,
    'INVALID_TOKEN'
  );

  // Test 3: Missing Authorization header entirely
  await assertCase(
    'Attack 3: Missing Authorization header entirely on GET /api/audit',
    `${BASE_URL}/api/audit`,
    {
      method: 'GET',
    },
    401,
    'UNAUTHORIZED'
  );

  // Test 4: Empty Bearer token
  await assertCase(
    'Attack 4: Empty Bearer token (Authorization: Bearer )',
    `${BASE_URL}/api/audit`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ',
      },
      body: JSON.stringify({ action: 'ATTACK', summaryMl: 'Empty token' }),
    },
    401,
    'UNAUTHORIZED'
  );

  // Test 5: Forged Bearer token on Bootstrap endpoint
  await assertCase(
    'Attack 5: Forged Bearer token attempting Super Admin bootstrap',
    `${BASE_URL}/api/auth/bootstrap`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer forged_bootstrap_token_999',
      },
    },
    401,
    'BOOTSTRAP_TOKEN_FAILED'
  );

  // Test 6: Missing Bearer token on Bootstrap endpoint
  await assertCase(
    'Attack 6: Missing Bearer token on Bootstrap endpoint',
    `${BASE_URL}/api/auth/bootstrap`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-admin-email': 'jijopjohn@gmail.com',
      },
    },
    401,
    'UNAUTHORIZED'
  );

  console.log(`\n=== RESULTS: ${passedCount}/${totalCount} SECURITY TESTS PASSED ===`);
  if (passedCount !== totalCount) {
    process.exit(1);
  }
}

runSecurityTests();
