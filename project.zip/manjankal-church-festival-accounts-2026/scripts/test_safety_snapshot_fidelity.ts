/**
 * Safety Snapshot Verification & Restore Cancellation Test
 * 
 * Verifies that:
 * 1. Pre-restore safety snapshot serialization & read-back verification succeeds.
 * 2. If storage verification fails or payload is incomplete, restore is CANCELLED completely.
 * 3. Compares record counts between Current State and Backup Payload.
 * 4. Verifies emergency rollback recovers the exact pre-restore state.
 */

import { AppState, Heading, IncomeTransaction, ExpenseTransaction } from '../src/types/festival';
import { createCleanInitialState } from '../src/utils/storage';

class MockBrowserLocalStorage {
  private store: Map<string, string> = new Map();
  public failWrites: boolean = false;
  public corruptReads: boolean = false;

  setItem(key: string, value: string): void {
    if (this.failWrites) {
      throw new Error('QuotaExceededError: The quota has been exceeded.');
    }
    this.store.set(key, value);
  }

  getItem(key: string): string | null {
    if (this.corruptReads) {
      return '{"corrupted": true}';
    }
    return this.store.get(key) || null;
  }

  removeItem(key: string): void {
    this.store.delete(key);
  }

  clear(): void {
    this.store.clear();
  }
}

function runSafetySnapshotTests() {
  console.log('=== STARTING MANDATORY PRE-RESTORE SAFETY SNAPSHOT TESTS ===\n');

  const mockStorage = new MockBrowserLocalStorage();

  // 1. Current State with 2026 data
  const currentState: AppState = createCleanInitialState();
  const heading1: Heading = {
    id: 'inc-head-2026-001',
    name: 'നേർച്ച പെട്ടി വരവ്',
    type: 'INCOME',
  };
  currentState.dataByYear['2026'].headings = [heading1];
  const income1: IncomeTransaction = {
    id: 'inc-001',
    receiptNumber: 'R-2026-001',
    date: '2026-11-22',
    donorName: 'വർഗീസ് ജോസഫ്',
    headingId: heading1.id,
    headingName: heading1.name,
    amount: 15000,
    paymentMode: 'CASH',
    description: 'നേർച്ച',
    createdAt: '2026-11-22T04:30:00.000Z',
  };
  currentState.dataByYear['2026'].incomes = [income1];

  // 2. Older Backup State to Restore
  const backupToRestore: AppState = createCleanInitialState();
  const oldHeading: Heading = {
    id: 'inc-head-old',
    name: 'പഴയ വരവ്',
    type: 'INCOME',
  };
  backupToRestore.dataByYear['2026'].headings = [oldHeading];
  const oldIncome: IncomeTransaction = {
    id: 'inc-old-01',
    receiptNumber: 'R-2026-OLD',
    date: '2026-11-20',
    donorName: 'പഴയ ദാതാവ്',
    headingId: oldHeading.id,
    headingName: oldHeading.name,
    amount: 5000,
    paymentMode: 'CASH',
    description: 'പഴയ രസീത്',
    createdAt: '2026-11-20T04:30:00.000Z',
  };
  backupToRestore.dataByYear['2026'].incomes = [oldIncome];

  // Helper simulating the exact restore logic in BackupRestoreModal.tsx
  function attemptRestore(
    storage: MockBrowserLocalStorage,
    current: AppState,
    backup: AppState
  ): { success: boolean; activeState: AppState; message: string; cancelled: boolean } {
    let active = current;
    let snapshotConfirmed = false;
    let snapshotErrorDetail: string | null = null;
    const snapshotKey = 'church_festival_pre_restore_safety_snapshot';

    try {
      const snapshotMetadata = {
        savedAt: new Date().toISOString(),
        yearCount: current.years.length,
        receiptsCount: Object.values(current.dataByYear).reduce((s, y) => s + y.incomes.length, 0),
        vouchersCount: Object.values(current.dataByYear).reduce((s, y) => s + y.expenses.length, 0),
        state: current,
      };
      const snapshotPayload = JSON.stringify(snapshotMetadata);

      // Write to storage
      storage.setItem(snapshotKey, snapshotPayload);

      // MANDATORY READ-BACK VERIFICATION
      const verifyReadBack = storage.getItem(snapshotKey);
      if (!verifyReadBack) {
        throw new Error('Read-back returned empty.');
      }

      const parsedVerification = JSON.parse(verifyReadBack);
      if (
        !parsedVerification.state ||
        !Array.isArray(parsedVerification.state.years) ||
        parsedVerification.yearCount !== current.years.length ||
        parsedVerification.receiptsCount !== snapshotMetadata.receiptsCount
      ) {
        throw new Error('Snapshot payload verification mismatch.');
      }

      snapshotConfirmed = true;
    } catch (err: any) {
      snapshotConfirmed = false;
      snapshotErrorDetail = err.message || 'Snapshot failed';
    }

    // CRITICAL: CANCEL IF SNAPSHOT FAILS
    if (!snapshotConfirmed) {
      return {
        success: false,
        activeState: active, // Current state untouched
        message: `Restore Aborted: Mandatory safety snapshot failed (${snapshotErrorDetail}). Current data preserved.`,
        cancelled: true,
      };
    }

    // Apply restore ONLY after verified snapshot
    active = backup;
    return {
      success: true,
      activeState: active,
      message: 'Restore successful. Prior data preserved in safety snapshot.',
      cancelled: false,
    };
  }

  // TEST 1: Normal Restore with Verified Safety Snapshot
  console.log('[TEST 1] Testing normal restore with verified safety snapshot...');
  const res1 = attemptRestore(mockStorage, currentState, backupToRestore);
  console.log(`Outcome: success=${res1.success}, cancelled=${res1.cancelled}`);
  console.log(`Message: ${res1.message}`);
  if (res1.success && !res1.cancelled && res1.activeState === backupToRestore) {
    console.log('[PASS] Test 1: Restore completed only after verified safety snapshot.');
  } else {
    console.error('[FAIL] Test 1 failed.');
    process.exit(1);
  }

  // TEST 2: Storage Write Failure (Quota / Browser error) -> MUST CANCEL RESTORE
  console.log('\n[TEST 2] Testing restore cancellation on snapshot write failure...');
  mockStorage.failWrites = true;
  const res2 = attemptRestore(mockStorage, currentState, backupToRestore);
  console.log(`Outcome: success=${res2.success}, cancelled=${res2.cancelled}`);
  console.log(`Message: ${res2.message}`);
  if (!res2.success && res2.cancelled && res2.activeState === currentState) {
    console.log('[PASS] Test 2: Restore CANCELLED completely on snapshot write failure. Current records untouched.');
  } else {
    console.error('[FAIL] Test 2: Restore should have been cancelled!');
    process.exit(1);
  }

  // TEST 3: Read-back Verification Failure (Corrupted payload) -> MUST CANCEL RESTORE
  console.log('\n[TEST 3] Testing restore cancellation on read-back verification failure...');
  mockStorage.failWrites = false;
  mockStorage.corruptReads = true;
  const res3 = attemptRestore(mockStorage, currentState, backupToRestore);
  console.log(`Outcome: success=${res3.success}, cancelled=${res3.cancelled}`);
  console.log(`Message: ${res3.message}`);
  if (!res3.success && res3.cancelled && res3.activeState === currentState) {
    console.log('[PASS] Test 3: Restore CANCELLED completely on read-back corruption. Current records untouched.');
  } else {
    console.error('[FAIL] Test 3: Corrupted snapshot was not detected!');
    process.exit(1);
  }

  // TEST 4: Emergency Rollback from Safety Snapshot
  console.log('\n[TEST 4] Testing emergency rollback from safety snapshot...');
  mockStorage.corruptReads = false;
  // Re-run successful restore to populate snapshot
  const res4 = attemptRestore(mockStorage, currentState, backupToRestore);
  const snapshotRaw = mockStorage.getItem('church_festival_pre_restore_safety_snapshot');
  const parsedSnapshot = JSON.parse(snapshotRaw!);
  const rolledBackState: AppState = parsedSnapshot.state;

  const currentReceiptNo = currentState.dataByYear['2026'].incomes[0].receiptNumber;
  const rolledBackReceiptNo = rolledBackState.dataByYear['2026'].incomes[0].receiptNumber;

  if (currentReceiptNo === rolledBackReceiptNo) {
    console.log(`[PASS] Test 4: Rollback accurately recovered pre-restore receipt "${rolledBackReceiptNo}".`);
  } else {
    console.error('[FAIL] Test 4: Rollback mismatch.');
    process.exit(1);
  }

  console.log('\n=== ALL 4 SAFETY SNAPSHOT & RESTORE CANCELLATION TESTS PASSED ===');
}

runSafetySnapshotTests();
