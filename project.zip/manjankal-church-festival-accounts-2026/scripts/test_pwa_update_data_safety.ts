/**
 * PWA Update Data Safety & Offline Reconnection Simulation Test
 * Manjankal Mar Shemavoon Desthuni Orthodox Syrian Church - 2026 Festival Accounts
 */

import {
  STORAGE_KEY,
  createCleanInitialState,
  isValidAppStateSchema
} from '../src/utils/storage';
import { formatReceiptNumber, formatVoucherNumber } from '../src/utils/payloadNormalization';

console.log("========================================================================");
console.log("TEST: PWA APP-UPDATE DATA FIDELITY & OFFLINE PERSISTENCE");
console.log("========================================================================");

// Mock browser LocalStorage
const mockLocalStorage: Record<string, string> = {};
const storageAdapter = {
  getItem: (key: string) => mockLocalStorage[key] || null,
  setItem: (key: string, val: string) => { mockLocalStorage[key] = val; },
  removeItem: (key: string) => { delete mockLocalStorage[key]; }
};

// 1. POPULATE INITIAL ACTIVE FESTIVAL ACCOUNTING DATA
console.log("\n--- Step 1: Seeding Active 2026 Accounting Records into LocalStorage ---");
const state = createCleanInitialState();
const y2026Data = state.dataByYear['2026'];

// Add 3 income receipts and 2 expense vouchers
y2026Data.headings.push(
  { id: 'h-1', name: 'ആദ്യഫല ലേലം', type: 'INCOME', isDefault: false },
  { id: 'h-2', name: 'പന്തൽ & ഡെക്കറേഷൻ', type: 'EXPENSE', isDefault: false }
);

y2026Data.incomes.push(
  {
    id: 'inc-01',
    receiptNumber: formatReceiptNumber(1),
    date: '2026-11-25',
    headingId: 'h-1',
    headingName: 'ആദ്യഫല ലേലം',
    amount: 15000,
    paymentMode: 'CASH',
    description: 'ആദ്യഫല ലേല വരവ്',
    donorName: 'ഗീവർഗീസ് മാത്യു',
    createdAt: '2026-11-25T10:00:00Z',
  },
  {
    id: 'inc-02',
    receiptNumber: formatReceiptNumber(2),
    date: '2026-11-25',
    headingId: 'h-1',
    headingName: 'ആദ്യഫല ലേലം',
    amount: 25000,
    paymentMode: 'CASH',
    description: 'നേർച്ച സമർപ്പണം',
    donorName: 'തോമസ് കുരുവിള',
    createdAt: '2026-11-25T11:00:00Z',
  }
);
y2026Data.lastReceiptSeq = 2;

y2026Data.expenses.push({
  id: 'exp-01',
  voucherNumber: formatVoucherNumber(1),
  date: '2026-11-26',
  headingId: 'h-2',
  headingName: 'പന്തൽ & ഡെക്കറേഷൻ',
  amount: 12000,
  paymentMode: 'CASH',
  description: 'പന്തൽ നിർമ്മാണ അഡ്വാൻസ്',
  paidTo: 'റോയൽ ഡെക്കറേറ്റേഴ്സ്',
  createdAt: '2026-11-26T14:00:00Z',
});
y2026Data.lastVoucherSeq = 1;

storageAdapter.setItem(STORAGE_KEY, JSON.stringify(state));
const preUpdateSnapshot = storageAdapter.getItem(STORAGE_KEY)!;

console.log(`[PASS] Initial state saved under key: ${STORAGE_KEY}`);
console.log(`  Receipt count: ${y2026Data.incomes.length}, Total Income: ₹40,000`);
console.log(`  Voucher count: ${y2026Data.expenses.length}, Total Expense: ₹12,000`);

// 2. SIMULATE SERVICE WORKER UPDATE (APP-SHELL V1 -> V2)
console.log("\n--- Step 2: Simulating PWA App-Shell Cache Update (V1 -> V2) ---");

// Mock CacheStorage API update simulation
const mockCaches = new Map<string, string[]>();
mockCaches.set('manjakala-church-shell-v1', ['/index.html', '/assets/index-v1.js', '/assets/index-v1.css']);

// New Service Worker installs and activates V2, purging V1
mockCaches.delete('manjakala-church-shell-v1');
mockCaches.set('manjakala-church-shell-v2', ['/index.html', '/assets/index-v2.js', '/assets/index-v2.css']);

console.log("  Cache Storage updated: purged v1, populated v2.");

// 3. VERIFY LOCALSTORAGE REMAINS COMPLETELY UNTOUCHED POST-UPDATE
console.log("\n--- Step 3: Verifying Accounting Data Post-Service Worker Update ---");
const postUpdateDataRaw = storageAdapter.getItem(STORAGE_KEY);
if (!postUpdateDataRaw) {
  throw new Error("CRITICAL FAILURE: LocalStorage was cleared during app update!");
}
if (postUpdateDataRaw !== preUpdateSnapshot) {
  throw new Error("CRITICAL FAILURE: LocalStorage data altered during app update!");
}

const parsedPostUpdate = JSON.parse(postUpdateDataRaw);
if (!isValidAppStateSchema(parsedPostUpdate)) {
  throw new Error("CRITICAL FAILURE: Schema validation failed after app update!");
}

const post2026 = parsedPostUpdate.dataByYear['2026'];
if (post2026.incomes.length !== 2 || post2026.expenses.length !== 1) {
  throw new Error("Discrepancy in transaction counts post-update!");
}
if (post2026.lastReceiptSeq !== 2 || post2026.lastVoucherSeq !== 1) {
  throw new Error("Discrepancy in sequence counters post-update!");
}
console.log("[PASS] 100% of church accounting data preserved identically across PWA updates.");

// 4. SIMULATE OFFLINE TRANSACTION CREATION AND SEQUENCE NUMBERING
console.log("\n--- Step 4: Simulating Offline Transaction Entry While Network Disconnected ---");
const nextReceiptSeq = post2026.lastReceiptSeq + 1;
const newReceiptNumber = formatReceiptNumber(nextReceiptSeq);

post2026.incomes.push({
  id: 'inc-03',
  receiptNumber: newReceiptNumber,
  date: '2026-11-27',
  headingId: 'h-1',
  headingName: 'ആദ്യഫല ലേലം',
  amount: 8000,
  paymentMode: 'CASH',
  description: 'ഓഫ്‌ലൈൻ നേർച്ച രസീത്',
  donorName: 'കുര്യൻ വർഗീസ്',
  createdAt: '2026-11-27T09:00:00Z',
});
post2026.lastReceiptSeq = nextReceiptSeq;

storageAdapter.setItem(STORAGE_KEY, JSON.stringify(parsedPostUpdate));
const updatedOfflineState = JSON.parse(storageAdapter.getItem(STORAGE_KEY)!);

if (updatedOfflineState.dataByYear['2026'].lastReceiptSeq !== 3) {
  throw new Error("Offline sequence counter failed to increment!");
}
if (updatedOfflineState.dataByYear['2026'].incomes[2].receiptNumber !== 'R-2026-003') {
  throw new Error(`Expected R-2026-003, got ${updatedOfflineState.dataByYear['2026'].incomes[2].receiptNumber}`);
}
console.log(`[PASS] Offline income record added: ${newReceiptNumber} (₹8,000). Total Incomes: 3.`);

// 5. SUMMARY
console.log("\n========================================================================");
console.log(">>> ALL PWA UPDATE SAFETY & OFFLINE PERSISTENCE TESTS PASSED <<<");
console.log("========================================================================");
