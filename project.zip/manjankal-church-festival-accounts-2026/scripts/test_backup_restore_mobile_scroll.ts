import { readFileSync } from 'fs';

console.log('=== VERIFYING BACKUP & RESTORE MOBILE SCROLLING & BUTTON ACCESSIBILITY ===\n');

const modalSrc = readFileSync('src/components/BackupRestoreModal.tsx', 'utf-8');

// 1. Check backdrop scrollability
console.log('[TEST 1] Backdrop scrolling container:');
if (!modalSrc.includes('fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto overscroll-contain')) {
  throw new Error('FAIL: Outer backdrop missing overflow-y-auto or overscroll-contain for mobile viewports');
}
console.log('  ✓ Backdrop properly configured with overflow-y-auto and overscroll-contain');

// 2. Check modal card max-height and flex-col layout
console.log('\n[TEST 2] Modal card height and flex constraints:');
if (!modalSrc.includes('max-h-[calc(100dvh-1.5rem)]') || !modalSrc.includes('flex flex-col overflow-hidden')) {
  throw new Error('FAIL: Modal card missing max-height or flex-col overflow-hidden');
}
console.log('  ✓ Modal card constrained to viewport height (max-h-[calc(100dvh-1.5rem)]) with flex-col');

// 3. Check scrollable form content body
console.log('\n[TEST 3] Scrollable form body:');
if (!modalSrc.includes('flex flex-col flex-1 min-h-0 overflow-hidden')) {
  throw new Error('FAIL: Form missing flex-col flex-1 min-h-0 overflow-hidden container');
}
if (!modalSrc.includes('flex-1 overflow-y-auto overscroll-contain space-y-4 pr-1 -mr-1 py-1')) {
  throw new Error('FAIL: Form content body missing overflow-y-auto overscroll-contain');
}
console.log('  ✓ Form content body has independent vertical scroll with overscroll-contain');

// 4. Check comparison table touch behavior
console.log('\n[TEST 4] Comparison table touch scrolling:');
if (!modalSrc.includes('overflow-x-auto touch-pan-x')) {
  throw new Error('FAIL: Comparison table container missing touch-pan-x');
}
console.log('  ✓ Comparison table configured with touch-pan-x (preserves vertical page scroll on touch)');

// 5. Check sticky bottom action buttons footer
console.log('\n[TEST 5] Sticky action buttons footer:');
if (!modalSrc.includes('sticky bottom-0 bg-white/95 backdrop-blur-xs pt-3 pb-1 border-t border-slate-100 mt-2 flex justify-end gap-2 shrink-0 z-10')) {
  throw new Error('FAIL: Restore and Cancel buttons missing sticky bottom-0 footer');
}
if (!modalSrc.includes('റദ്ദാക്കുക') || !modalSrc.includes('സ്ഥിരീകരിച്ച് റീസ്റ്റോർ ചെയ്യുക')) {
  throw new Error('FAIL: Missing Cancel or Restore button labels');
}
console.log('  ✓ Restore and Cancel buttons anchored in sticky bottom-0 footer (always visible on mobile)');

// 6. Check safety snapshot and rollback protections are intact
console.log('\n[TEST 6] Safety snapshot & rollback protections:');
const requiredProtections = [
  'church_festival_pre_restore_safety_snapshot',
  'church_festival_emergency_rollback_slot',
  'Storage read-back verification failed',
  'Snapshot payload corrupted or incomplete',
  'SAFETY_SNAPSHOT_Before_Restore_',
  'handleRollbackToSnapshot',
  'isValidAppStateSchema',
];
for (const p of requiredProtections) {
  if (!modalSrc.includes(p)) {
    throw new Error(`FAIL: Missing safety protection keyword: ${p}`);
  }
}
console.log('  ✓ All mandatory pre-restore safety snapshot and rollback protections 100% intact');

console.log('\n============================================================');
console.log('ALL BACKUP & RESTORE MOBILE SCROLLING TESTS PASSED: 100%');
console.log('============================================================\n');
