/**
 * PHASE 1.12 — Real Firestore Emulator Transaction and Concurrency Acceptance Suite
 * Manjankal Mar Shemavoon Desthuni Orthodox Syrian Church - 2026 Festival Accounts
 *
 * Verifies all four-way atomic bindings, concurrency serialization, idempotency retries,
 * legacy migration, and zero-partial-write rollbacks against the official Firestore Emulator.
 */

import { initializeApp } from 'firebase/app';
import { getAuth, connectAuthEmulator, signInWithCustomToken } from 'firebase/auth';
import {
  getFirestore,
  connectFirestoreEmulator,
  runTransaction,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
} from 'firebase/firestore';
import { initializeApp as initAdmin, getApps as getAdminApps } from 'firebase-admin/app';
import { getAuth as getAdminAuth } from 'firebase-admin/auth';
import { createHash } from 'crypto';
import { computeMigrationChecksum } from '../src/utils/payloadNormalization';

if (getAdminApps().length === 0) {
  initAdmin({ projectId: 'demo-church' });
}

function computePayloadHash(payload: any): string {
  const normalized = JSON.stringify(payload, Object.keys(payload).sort());
  return createHash('sha256').update(normalized).digest('hex');
}

function formatReceiptNumber(seq: number): string {
  if (seq < 1000) {
    return `R-2026-${String(seq).padStart(3, '0')}`;
  }
  return `R-2026-${seq}`;
}

function formatVoucherNumber(seq: number): string {
  if (seq < 1000) {
    return `V-2026-${String(seq).padStart(3, '0')}`;
  }
  return `V-2026-${seq}`;
}

interface TestReport {
  testName: string;
  passed: boolean;
  details: string;
}

const report: TestReport[] = [];

async function main() {
  console.log('========================================================================');
  console.log('PHASE 1.12: REAL FIRESTORE TRANSACTION & CONCURRENCY ACCEPTANCE TEST');
  console.log('Project: Manjankal Mar Shemavoon Desthuni Orthodox Syrian Church - 2026');
  console.log('Target Administrator: jijopjohn@gmail.com');
  console.log('Emulator Ports: Auth=9099, Firestore=8088, Project=demo-church');
  console.log('========================================================================\n');

  // 1. Prepare Admin & Unauth Tokens
  const adminAuth = getAdminAuth();
  try {
    await adminAuth.createUser({
      uid: 'super-admin-uid',
      email: 'jijopjohn@gmail.com',
      emailVerified: true,
    });
  } catch {
    // Already created
  }
  try {
    await adminAuth.createUser({
      uid: 'unauthorized-uid',
      email: 'intruder@otherchurch.com',
      emailVerified: true,
    });
  } catch {
    // Already created
  }

  const adminToken = await adminAuth.createCustomToken('super-admin-uid', {
    email: 'jijopjohn@gmail.com',
    email_verified: true,
  });

  const unauthorizedToken = await adminAuth.createCustomToken('unauthorized-uid', {
    email: 'intruder@otherchurch.com',
    email_verified: true,
  });

  // Client Web SDK Apps
  const adminApp = initializeApp({ apiKey: 'fake-api-key', projectId: 'demo-church' }, 'admin-app');
  const adminClientAuth = getAuth(adminApp);
  connectAuthEmulator(adminClientAuth, 'http://127.0.0.1:9099', { disableWarnings: true });
  const adminDb = getFirestore(adminApp);
  connectFirestoreEmulator(adminDb, '127.0.0.1', 8088);
  await signInWithCustomToken(adminClientAuth, adminToken);

  const intruderApp = initializeApp({ apiKey: 'fake-api-key', projectId: 'demo-church' }, 'intruder-app');
  const intruderClientAuth = getAuth(intruderApp);
  connectAuthEmulator(intruderClientAuth, 'http://127.0.0.1:9099', { disableWarnings: true });
  const intruderDb = getFirestore(intruderApp);
  connectFirestoreEmulator(intruderDb, '127.0.0.1', 8088);
  await signInWithCustomToken(intruderClientAuth, unauthorizedToken);

  console.log('Step 1: Auth & Client SDK Initialized successfully.\n');

  // ---------------------------------------------------------------------------
  // Setup Test Headings
  // ---------------------------------------------------------------------------
  console.log('--- Step 2: Seeding Test Headings ---');
  const incHeadingRef = doc(adminDb, 'festivals/2026/headings/h-income-1');
  await setDoc(incHeadingRef, {
    id: 'h-income-1',
    name: 'നേർച്ച',
    type: 'INCOME',
    createdAt: '2026-11-22T08:00:00Z',
  });

  const expHeadingRef = doc(adminDb, 'festivals/2026/headings/h-expense-1');
  await setDoc(expHeadingRef, {
    id: 'h-expense-1',
    name: 'വൈദ്യുതി & ലൈറ്റ്',
    type: 'EXPENSE',
    createdAt: '2026-11-22T08:00:00Z',
  });
  console.log('[PASS] Created income and expense headings.\n');

  // Initialize Sequence Counter
  const seqRef = doc(adminDb, 'festivals/2026/sequences/accounting');
  await setDoc(seqRef, {
    yearId: '2026',
    lastReceiptSeq: 0,
    lastVoucherSeq: 0,
    lastOperationId: '00000000-0000-4000-8000-000000000000',
    status: 'INITIALIZED_EMPTY',
    createdAt: '2026-11-22T08:00:00Z',
  });
  console.log('[PASS] Initialized clean sequence counter (receipt=0, voucher=0).\n');

  // ---------------------------------------------------------------------------
  // TEST 1: Real Client SDK Income Transaction (Four-way atomic binding)
  // ---------------------------------------------------------------------------
  console.log('--- TEST 1: Real Income Transaction Execution ---');
  const opId1 = '11111111-1111-4111-8111-111111111111';
  const incId1 = '22222222-2222-4222-8222-222222222222';
  const auditId1 = `audit_${opId1}`;
  const nowIso1 = '2026-11-25T10:00:00Z';

  const incomePayload = {
    amount: 2500,
    date: '2026-11-25',
    description: 'ഫെസ്റ്റിവൽ നേർച്ച സമർപ്പണം',
    headingId: 'h-income-1',
    headingName: 'നേർച്ച',
    paymentMode: 'CASH',
  };
  const hash1 = computePayloadHash(incomePayload);

  const txResult1 = await runTransaction(adminDb, async (tx) => {
    const opSnap = await tx.get(doc(adminDb, `festivals/2026/operations/${opId1}`));
    if (opSnap.exists()) {
      return { status: 'ALREADY_COMMITTED', allocatedNumber: opSnap.data().allocatedNumber };
    }

    const seqSnap = await tx.get(seqRef);
    if (!seqSnap.exists()) throw new Error('SEQ_NOT_FOUND');
    const seqData = seqSnap.data();

    const headSnap = await tx.get(incHeadingRef);
    if (!headSnap.exists()) throw new Error('HEAD_NOT_FOUND');

    const nextSeq = seqData.lastReceiptSeq + 1;
    const receiptNumber = formatReceiptNumber(nextSeq);

    tx.update(seqRef, {
      lastReceiptSeq: nextSeq,
      lastOperationId: opId1,
      updatedAt: nowIso1,
    });

    tx.set(doc(adminDb, `festivals/2026/operations/${opId1}`), {
      operationId: opId1,
      type: 'INCOME',
      entityId: incId1,
      seqNumber: nextSeq,
      allocatedNumber: receiptNumber,
      payloadHash: hash1,
      userEmail: 'jijopjohn@gmail.com',
      createdAt: nowIso1,
    });

    tx.set(doc(adminDb, `festivals/2026/incomes/${incId1}`), {
      id: incId1,
      receiptNumber,
      seqNumber: nextSeq,
      operationId: opId1,
      payloadHash: hash1,
      date: incomePayload.date,
      headingId: incomePayload.headingId,
      headingName: incomePayload.headingName,
      amount: incomePayload.amount,
      paymentMode: incomePayload.paymentMode,
      description: incomePayload.description,
      createdAt: nowIso1,
    });

    tx.set(doc(adminDb, `festivals/2026/audit_logs/${auditId1}`), {
      id: auditId1,
      operationId: opId1,
      entityId: incId1,
      entityType: 'INCOME',
      action: 'ADD_INCOME',
      summaryMl: `രസീത് ${receiptNumber} ചേർത്തു`,
      amount: incomePayload.amount,
      userEmail: 'jijopjohn@gmail.com',
      timestamp: nowIso1,
    });

    return { status: 'COMMITTED_NEW', allocatedNumber: receiptNumber };
  });

  const incSnap1 = await getDoc(doc(adminDb, `festivals/2026/incomes/${incId1}`));
  const seqSnap1 = await getDoc(seqRef);
  const opSnap1 = await getDoc(doc(adminDb, `festivals/2026/operations/${opId1}`));
  const auditSnap1 = await getDoc(doc(adminDb, `festivals/2026/audit_logs/${auditId1}`));

  if (
    txResult1.status === 'COMMITTED_NEW' &&
    txResult1.allocatedNumber === 'R-2026-001' &&
    incSnap1.exists() &&
    seqSnap1.data()?.lastReceiptSeq === 1 &&
    opSnap1.data()?.allocatedNumber === 'R-2026-001' &&
    auditSnap1.exists()
  ) {
    report.push({
      testName: 'TEST 1: Real Income Transaction (Four-way binding)',
      passed: true,
      details: 'R-2026-001 committed atomically with sequence counter, operation, and audit log',
    });
    console.log('[PASS] TEST 1: Income transaction committed atomically: R-2026-001\n');
  } else {
    report.push({ testName: 'TEST 1', passed: false, details: 'Income transaction did not commit cleanly' });
  }

  // ---------------------------------------------------------------------------
  // TEST 2: Real Client SDK Expense Transaction (Four-way atomic binding)
  // ---------------------------------------------------------------------------
  console.log('--- TEST 2: Real Expense Transaction Execution ---');
  const opId2 = '33333333-3333-4333-8333-333333333333';
  const expId2 = '44444444-4444-4444-8444-444444444444';
  const auditId2 = `audit_${opId2}`;
  const nowIso2 = '2026-11-25T11:00:00Z';

  const expensePayload = {
    amount: 1500,
    date: '2026-11-25',
    description: 'ജനറേറ്റർ ഇന്ധന ചാർജ്ജ്',
    headingId: 'h-expense-1',
    headingName: 'വൈദ്യുതി & ലൈറ്റ്',
    paidTo: 'സന്തോഷ് കുമാർ',
    paymentMode: 'CASH',
  };
  const hash2 = computePayloadHash(expensePayload);

  const txResult2 = await runTransaction(adminDb, async (tx) => {
    const opSnap = await tx.get(doc(adminDb, `festivals/2026/operations/${opId2}`));
    if (opSnap.exists()) {
      return { status: 'ALREADY_COMMITTED', allocatedNumber: opSnap.data().allocatedNumber };
    }

    const seqSnap = await tx.get(seqRef);
    if (!seqSnap.exists()) throw new Error('SEQ_NOT_FOUND');
    const seqData = seqSnap.data();

    const headSnap = await tx.get(expHeadingRef);
    if (!headSnap.exists()) throw new Error('HEAD_NOT_FOUND');

    const nextSeq = seqData.lastVoucherSeq + 1;
    const voucherNumber = formatVoucherNumber(nextSeq);

    tx.update(seqRef, {
      lastVoucherSeq: nextSeq,
      lastOperationId: opId2,
      updatedAt: nowIso2,
    });

    tx.set(doc(adminDb, `festivals/2026/operations/${opId2}`), {
      operationId: opId2,
      type: 'EXPENSE',
      entityId: expId2,
      seqNumber: nextSeq,
      allocatedNumber: voucherNumber,
      payloadHash: hash2,
      userEmail: 'jijopjohn@gmail.com',
      createdAt: nowIso2,
    });

    tx.set(doc(adminDb, `festivals/2026/expenses/${expId2}`), {
      id: expId2,
      voucherNumber,
      seqNumber: nextSeq,
      operationId: opId2,
      payloadHash: hash2,
      date: expensePayload.date,
      paidTo: expensePayload.paidTo,
      headingId: expensePayload.headingId,
      headingName: expensePayload.headingName,
      amount: expensePayload.amount,
      paymentMode: expensePayload.paymentMode,
      description: expensePayload.description,
      createdAt: nowIso2,
    });

    tx.set(doc(adminDb, `festivals/2026/audit_logs/${auditId2}`), {
      id: auditId2,
      operationId: opId2,
      entityId: expId2,
      entityType: 'EXPENSE',
      action: 'ADD_EXPENSE',
      summaryMl: `വൗച്ചർ ${voucherNumber} ചേർത്തു`,
      amount: expensePayload.amount,
      userEmail: 'jijopjohn@gmail.com',
      timestamp: nowIso2,
    });

    return { status: 'COMMITTED_NEW', allocatedNumber: voucherNumber };
  });

  const expSnap2 = await getDoc(doc(adminDb, `festivals/2026/expenses/${expId2}`));
  const seqSnap2 = await getDoc(seqRef);
  const opSnap2 = await getDoc(doc(adminDb, `festivals/2026/operations/${opId2}`));
  const auditSnap2 = await getDoc(doc(adminDb, `festivals/2026/audit_logs/${auditId2}`));

  if (
    txResult2.status === 'COMMITTED_NEW' &&
    txResult2.allocatedNumber === 'V-2026-001' &&
    expSnap2.exists() &&
    seqSnap2.data()?.lastVoucherSeq === 1 &&
    opSnap2.data()?.allocatedNumber === 'V-2026-001' &&
    auditSnap2.exists()
  ) {
    report.push({
      testName: 'TEST 2: Real Expense Transaction (Four-way binding)',
      passed: true,
      details: 'V-2026-001 committed atomically with voucher sequence counter, operation, and audit log',
    });
    console.log('[PASS] TEST 2: Expense transaction committed atomically: V-2026-001\n');
  } else {
    report.push({ testName: 'TEST 2', passed: false, details: 'Expense transaction did not commit cleanly' });
  }

  // ---------------------------------------------------------------------------
  // TEST 3: Atomic Failure Tests (Zero Partial Writes / Complete Rollback)
  // ---------------------------------------------------------------------------
  console.log('--- TEST 3: Atomic Failure & Rollback Tests ---');

  // Test 3a: Missing Audit Log (Transaction must abort, counter must remain 1)
  const opIdFail1 = '55555555-5555-4555-8555-555555555555';
  const incIdFail1 = '66666666-6666-4666-8666-666666666666';
  let failCaught1 = false;
  try {
    await runTransaction(adminDb, async (tx) => {
      const seqSnap = await tx.get(seqRef);
      const nextSeq = (seqSnap.data()?.lastReceiptSeq ?? 0) + 1;
      const receiptNumber = formatReceiptNumber(nextSeq);

      tx.update(seqRef, {
        lastReceiptSeq: nextSeq,
        lastOperationId: opIdFail1,
        updatedAt: nowIso1,
      });

      tx.set(doc(adminDb, `festivals/2026/operations/${opIdFail1}`), {
        operationId: opIdFail1,
        type: 'INCOME',
        entityId: incIdFail1,
        seqNumber: nextSeq,
        allocatedNumber: receiptNumber,
        payloadHash: hash1,
        userEmail: 'jijopjohn@gmail.com',
        createdAt: nowIso1,
      });

      tx.set(doc(adminDb, `festivals/2026/incomes/${incIdFail1}`), {
        id: incIdFail1,
        receiptNumber,
        seqNumber: nextSeq,
        operationId: opIdFail1,
        payloadHash: hash1,
        date: incomePayload.date,
        headingId: incomePayload.headingId,
        headingName: incomePayload.headingName,
        amount: incomePayload.amount,
        paymentMode: incomePayload.paymentMode,
        description: incomePayload.description,
        createdAt: nowIso1,
      });
      // DELIBERATELY OMIT AUDIT LOG WRITE
    });
  } catch (err: any) {
    failCaught1 = true;
  }

  const checkSeq3a = await getDoc(seqRef);
  const checkInc3a = await getDoc(doc(adminDb, `festivals/2026/incomes/${incIdFail1}`));
  const checkOp3a = await getDoc(doc(adminDb, `festivals/2026/operations/${opIdFail1}`));

  if (failCaught1 && checkSeq3a.data()?.lastReceiptSeq === 1 && !checkInc3a.exists() && !checkOp3a.exists()) {
    report.push({
      testName: 'TEST 3a: Missing Audit Document Rollback',
      passed: true,
      details: 'Rejected with PERMISSION_DENIED; Sequence counter preserved at 1, zero partial documents written',
    });
    console.log('[PASS] TEST 3a: Missing audit doc caused complete atomic rollback (zero partial writes).\n');
  } else {
    report.push({ testName: 'TEST 3a', passed: false, details: 'Rollback failed or state leaked' });
  }

  // Test 3b: EntityId Mismatch between Operation and Income
  const opIdFail2 = '77777777-7777-4777-8777-777777777777';
  const incIdFail2 = '88888888-8888-4888-8888-888888888888';
  const wrongEntityId = '99999999-9999-4999-8999-999999999999';
  let failCaught2 = false;
  try {
    await runTransaction(adminDb, async (tx) => {
      const seqSnap = await tx.get(seqRef);
      const nextSeq = (seqSnap.data()?.lastReceiptSeq ?? 0) + 1;
      const receiptNumber = formatReceiptNumber(nextSeq);

      tx.update(seqRef, {
        lastReceiptSeq: nextSeq,
        lastOperationId: opIdFail2,
        updatedAt: nowIso1,
      });

      tx.set(doc(adminDb, `festivals/2026/operations/${opIdFail2}`), {
        operationId: opIdFail2,
        type: 'INCOME',
        entityId: wrongEntityId, // WRONG ENTITY ID
        seqNumber: nextSeq,
        allocatedNumber: receiptNumber,
        payloadHash: hash1,
        userEmail: 'jijopjohn@gmail.com',
        createdAt: nowIso1,
      });

      tx.set(doc(adminDb, `festivals/2026/incomes/${incIdFail2}`), {
        id: incIdFail2,
        receiptNumber,
        seqNumber: nextSeq,
        operationId: opIdFail2,
        payloadHash: hash1,
        date: incomePayload.date,
        headingId: incomePayload.headingId,
        headingName: incomePayload.headingName,
        amount: incomePayload.amount,
        paymentMode: incomePayload.paymentMode,
        description: incomePayload.description,
        createdAt: nowIso1,
      });

      tx.set(doc(adminDb, `festivals/2026/audit_logs/audit_${opIdFail2}`), {
        id: `audit_${opIdFail2}`,
        operationId: opIdFail2,
        entityId: wrongEntityId,
        entityType: 'INCOME',
        action: 'ADD_INCOME',
        summaryMl: `രസീത് ${receiptNumber} ചേർത്തു`,
        amount: incomePayload.amount,
        userEmail: 'jijopjohn@gmail.com',
        timestamp: nowIso1,
      });
    });
  } catch (err: any) {
    failCaught2 = true;
  }

  const checkSeq3b = await getDoc(seqRef);
  const checkInc3b = await getDoc(doc(adminDb, `festivals/2026/incomes/${incIdFail2}`));

  if (failCaught2 && checkSeq3b.data()?.lastReceiptSeq === 1 && !checkInc3b.exists()) {
    report.push({
      testName: 'TEST 3b: Entity ID Mismatch Rollback',
      passed: true,
      details: 'Rejected with PERMISSION_DENIED; Sequence counter preserved at 1, zero partial documents written',
    });
    console.log('[PASS] TEST 3b: Entity ID mismatch caused complete atomic rollback.\n');
  } else {
    report.push({ testName: 'TEST 3b', passed: false, details: 'Rollback failed on entityId mismatch' });
  }

  // Test 3c: Unauthorized User Attempt (Intruder)
  let failCaught3c = false;
  try {
    const intruderSeqRef = doc(intruderDb, 'festivals/2026/sequences/accounting');
    await runTransaction(intruderDb, async (tx) => {
      const seqSnap = await tx.get(intruderSeqRef);
      const nextSeq = (seqSnap.data()?.lastReceiptSeq ?? 0) + 1;
      tx.update(intruderSeqRef, { lastReceiptSeq: nextSeq });
    });
  } catch {
    failCaught3c = true;
  }

  if (failCaught3c) {
    report.push({
      testName: 'TEST 3c: Unauthorized Client Rejection',
      passed: true,
      details: 'Rejected with PERMISSION_DENIED for unauthorized user token',
    });
    console.log('[PASS] TEST 3c: Unauthorized user transaction rejected with PERMISSION_DENIED.\n');
  } else {
    report.push({ testName: 'TEST 3c', passed: false, details: 'Intruder was able to execute transaction' });
  }

  // ---------------------------------------------------------------------------
  // TEST 4: Real Concurrent Transactions (Promise.all 5 simultaneous transactions)
  // ---------------------------------------------------------------------------
  console.log('--- TEST 4: Real Concurrent Transactions (5 simultaneous clients) ---');
  const concurrentOps = [
    { opId: 'c1111111-1111-4111-8111-111111111111', incId: 'd1111111-1111-4111-8111-111111111111', amount: 500 },
    { opId: 'c2222222-2222-4222-8222-222222222222', incId: 'd2222222-2222-4222-8222-222222222222', amount: 750 },
    { opId: 'c3333333-3333-4333-8333-333333333333', incId: 'd3333333-3333-4333-8333-333333333333', amount: 1200 },
    { opId: 'c4444444-4444-4444-8444-444444444444', incId: 'd4444444-4444-4444-8444-444444444444', amount: 2000 },
    { opId: 'c5555555-5555-4555-8555-555555555555', incId: 'd5555555-5555-4555-8555-555555555555', amount: 3000 },
  ];

  const concurrentPromises = concurrentOps.map(async (op, idx) => {
    const payload = {
      amount: op.amount,
      date: '2026-11-26',
      description: `നേർച്ച സമർപ്പണം #${idx + 1}`,
      headingId: 'h-income-1',
      headingName: 'നേർച്ച',
      paymentMode: 'CASH',
    };
    const pHash = computePayloadHash(payload);
    const auditId = `audit_${op.opId}`;

    // Real client retry loop with stable operationId
    let attempts = 0;
    while (attempts < 5) {
      attempts++;
      try {
        const nowIso = `2026-11-26T10:0${attempts}:00Z`;
        const result = await runTransaction(adminDb, async (tx) => {
          const opSnap = await tx.get(doc(adminDb, `festivals/2026/operations/${op.opId}`));
          if (opSnap.exists()) {
            return { opId: op.opId, allocatedNumber: opSnap.data().allocatedNumber, isRetry: true };
          }

          const seqSnap = await tx.get(seqRef);
          if (!seqSnap.exists()) throw new Error('SEQ_NOT_FOUND');

          const headSnap = await tx.get(incHeadingRef);
          if (!headSnap.exists()) throw new Error('HEAD_NOT_FOUND');

          const currentSeq = seqSnap.data()?.lastReceiptSeq ?? 0;
          const nextSeq = currentSeq + 1;
          const receiptNumber = formatReceiptNumber(nextSeq);

          tx.update(seqRef, {
            lastReceiptSeq: nextSeq,
            lastOperationId: op.opId,
            updatedAt: nowIso,
          });

          tx.set(doc(adminDb, `festivals/2026/operations/${op.opId}`), {
            operationId: op.opId,
            type: 'INCOME',
            entityId: op.incId,
            seqNumber: nextSeq,
            allocatedNumber: receiptNumber,
            payloadHash: pHash,
            userEmail: 'jijopjohn@gmail.com',
            createdAt: nowIso,
          });

          tx.set(doc(adminDb, `festivals/2026/incomes/${op.incId}`), {
            id: op.incId,
            receiptNumber,
            seqNumber: nextSeq,
            operationId: op.opId,
            payloadHash: pHash,
            date: payload.date,
            headingId: payload.headingId,
            headingName: payload.headingName,
            amount: payload.amount,
            paymentMode: payload.paymentMode,
            description: payload.description,
            createdAt: nowIso,
          });

          tx.set(doc(adminDb, `festivals/2026/audit_logs/${auditId}`), {
            id: auditId,
            operationId: op.opId,
            entityId: op.incId,
            entityType: 'INCOME',
            action: 'ADD_INCOME',
            summaryMl: `രസീത് ${receiptNumber} ചേർത്തു`,
            amount: payload.amount,
            userEmail: 'jijopjohn@gmail.com',
            timestamp: nowIso,
          });

          return { opId: op.opId, allocatedNumber: receiptNumber, isRetry: false };
        });
        return result;
      } catch (err: any) {
        if (attempts >= 5) {
          console.error(`[Concurrent Op ${idx + 1} (${op.opId}) Failed after 5 attempts]:`, err.message);
          throw err;
        }
        // Small backoff before retrying with the same stable operationId
        await new Promise((res) => setTimeout(res, 50 * attempts + Math.random() * 50));
      }
    }
    throw new Error(`Failed to commit op ${op.opId}`);
  });

  const concurrentResults = await Promise.all(concurrentPromises);
  const allocatedNumbers = concurrentResults.map((r) => r.allocatedNumber);
  const uniqueAllocated = new Set(allocatedNumbers);

  const finalSeqSnap = await getDoc(seqRef);
  const finalSeq = finalSeqSnap.data()?.lastReceiptSeq;

  console.log('Concurrent Transaction Results:', allocatedNumbers);
  console.log('Final Sequence Counter:', finalSeq);

  if (
    concurrentResults.length === 5 &&
    uniqueAllocated.size === 5 &&
    finalSeq === 6 &&
    allocatedNumbers.includes('R-2026-002') &&
    allocatedNumbers.includes('R-2026-003') &&
    allocatedNumbers.includes('R-2026-004') &&
    allocatedNumbers.includes('R-2026-005') &&
    allocatedNumbers.includes('R-2026-006')
  ) {
    report.push({
      testName: 'TEST 4: Real Concurrency Serialization (5 parallel transactions)',
      passed: true,
      details: 'All 5 transactions serialized cleanly with 0 collisions: allocated R-2026-002 through R-2026-006',
    });
    console.log('[PASS] TEST 4: All 5 parallel transactions serialized sequentially without duplicate numbers.\n');
  } else {
    report.push({ testName: 'TEST 4', passed: false, details: 'Concurrency collision or missing sequence numbers' });
  }

  // ---------------------------------------------------------------------------
  // TEST 5: Real Idempotency & Network Retry Test (Same operationId across 5 retries)
  // ---------------------------------------------------------------------------
  console.log('--- TEST 5: Real Idempotency Test (Duplicate operationId retries) ---');
  const idempotentOpId = 'e1111111-1111-4111-8111-111111111111';
  const idempotentIncId = 'f1111111-1111-4111-8111-111111111111';
  const idemPayload = {
    amount: 5000,
    date: '2026-11-26',
    description: 'സ്പെഷ്യൽ നേർച്ച',
    headingId: 'h-income-1',
    headingName: 'നേർച്ച',
    paymentMode: 'UPI',
  };
  const idemHash = computePayloadHash(idemPayload);

  // Send 5 concurrent identical requests (simulating network retries)
  const retryPromises = Array.from({ length: 5 }).map(async (_, idx) => {
    if (idx > 0) {
      await new Promise((res) => setTimeout(res, idx * 50));
    }
    for (let attempt = 0; attempt < 5; attempt++) {
      try {
        return await runTransaction(adminDb, async (tx) => {
          const opSnap = await tx.get(doc(adminDb, `festivals/2026/operations/${idempotentOpId}`));
          if (opSnap.exists()) {
            const existingData = opSnap.data();
            if (existingData.payloadHash !== idemHash) {
              throw new Error('IDEMPOTENCY_CONFLICT: Reused operationId with different payload');
            }
            return { status: 'ALREADY_COMMITTED', allocatedNumber: existingData.allocatedNumber, retryAttempt: idx + 1 };
          }

          const seqSnap = await tx.get(seqRef);
          if (!seqSnap.exists()) throw new Error('SEQ_NOT_FOUND');

          const headSnap = await tx.get(incHeadingRef);
          if (!headSnap.exists()) throw new Error('HEAD_NOT_FOUND');

          const nextSeq = seqSnap.data().lastReceiptSeq + 1;
          const receiptNumber = formatReceiptNumber(nextSeq);
          const nowIso = '2026-11-26T12:00:00Z';

          tx.update(seqRef, {
            lastReceiptSeq: nextSeq,
            lastOperationId: idempotentOpId,
            updatedAt: nowIso,
          });

          tx.set(doc(adminDb, `festivals/2026/operations/${idempotentOpId}`), {
            operationId: idempotentOpId,
            type: 'INCOME',
            entityId: idempotentIncId,
            seqNumber: nextSeq,
            allocatedNumber: receiptNumber,
            payloadHash: idemHash,
            userEmail: 'jijopjohn@gmail.com',
            createdAt: nowIso,
          });

          tx.set(doc(adminDb, `festivals/2026/incomes/${idempotentIncId}`), {
            id: idempotentIncId,
            receiptNumber,
            seqNumber: nextSeq,
            operationId: idempotentOpId,
            payloadHash: idemHash,
            date: idemPayload.date,
            headingId: idemPayload.headingId,
            headingName: idemPayload.headingName,
            amount: idemPayload.amount,
            paymentMode: idemPayload.paymentMode,
            description: idemPayload.description,
            createdAt: nowIso,
          });

          tx.set(doc(adminDb, `festivals/2026/audit_logs/audit_${idempotentOpId}`), {
            id: `audit_${idempotentOpId}`,
            operationId: idempotentOpId,
            entityId: idempotentIncId,
            entityType: 'INCOME',
            action: 'ADD_INCOME',
            summaryMl: `രസീത് ${receiptNumber} ചേർത്തു`,
            amount: idemPayload.amount,
            userEmail: 'jijopjohn@gmail.com',
            timestamp: nowIso,
          });

          return { status: 'COMMITTED_NEW', allocatedNumber: receiptNumber, retryAttempt: idx + 1 };
        });
      } catch (err: any) {
        if (err.message && err.message.includes('IDEMPOTENCY_CONFLICT')) {
          throw err;
        }
        if (attempt >= 4) throw err;
        await new Promise((res) => setTimeout(res, 50 * (attempt + 1) + Math.random() * 30));
      }
    }
    throw new Error('RETRY_EXHAUSTED');
  });

  const retryResults = await Promise.all(retryPromises);
  const newCommits = retryResults.filter((r) => r.status === 'COMMITTED_NEW');
  const idempotentReturns = retryResults.filter((r) => r.status === 'ALREADY_COMMITTED');
  const allReturnedSameReceipt = retryResults.every((r) => r.allocatedNumber === 'R-2026-007');

  const seqSnapAfterRetry = await getDoc(seqRef);

  console.log('Idempotency Results:', {
    newCommits: newCommits.length,
    idempotentReturns: idempotentReturns.length,
    receiptNumber: retryResults[0].allocatedNumber,
    lastReceiptSeq: seqSnapAfterRetry.data()?.lastReceiptSeq,
  });

  if (newCommits.length === 1 && idempotentReturns.length === 4 && allReturnedSameReceipt && seqSnapAfterRetry.data()?.lastReceiptSeq === 7) {
    report.push({
      testName: 'TEST 5: Real Idempotency & Network Retries (5 concurrent duplicates)',
      passed: true,
      details: 'Exactly 1 transaction committed new document (R-2026-007); 4 retries safely returned existing receipt without allocating duplicates',
    });
    console.log('[PASS] TEST 5: Exactly 1 commit and 4 idempotent safe returns. Counter incremented by 1.\n');
  } else {
    report.push({ testName: 'TEST 5', passed: false, details: 'Idempotency failure: multiple allocations occurred' });
  }

  // ---------------------------------------------------------------------------
  // TEST 6: Idempotency Conflict (Reused operationId with different payload)
  // ---------------------------------------------------------------------------
  console.log('--- TEST 6: Idempotency Conflict Detection ---');
  let conflictDetected = false;
  try {
    const tamperedPayload = { ...idemPayload, amount: 999999 }; // Different amount!
    const tamperedHash = computePayloadHash(tamperedPayload);

    await runTransaction(adminDb, async (tx) => {
      const opSnap = await tx.get(doc(adminDb, `festivals/2026/operations/${idempotentOpId}`));
      if (opSnap.exists()) {
        const existingData = opSnap.data();
        if (existingData.payloadHash !== tamperedHash) {
          throw new Error('IDEMPOTENCY_CONFLICT: Reused operationId with different payload');
        }
        return existingData.allocatedNumber;
      }
      throw new Error('UNEXPECTED');
    });
  } catch (err: any) {
    if (err.message.includes('IDEMPOTENCY_CONFLICT')) {
      conflictDetected = true;
    }
  }

  if (conflictDetected) {
    report.push({
      testName: 'TEST 6: Idempotency Payload Conflict Rejection',
      passed: true,
      details: 'Rejected with IDEMPOTENCY_CONFLICT when operationId reused with modified financial amount',
    });
    console.log('[PASS] TEST 6: Payload conflict successfully detected and rejected.\n');
  } else {
    report.push({ testName: 'TEST 6', passed: false, details: 'Did not detect payload tampering with reused operationId' });
  }

  // ---------------------------------------------------------------------------
  // TEST 7: Legacy Migration Bootstrap with Non-Consecutive Numbering
  // ---------------------------------------------------------------------------
  console.log('--- TEST 7: Legacy Migration Bootstrap with Non-Consecutive Records ---');
  // Scenario: Historical festival had 3 receipts with non-consecutive numbers R-001, R-002, R-007.
  // Total count = 3, max historical receipt seq = 7.
  // Next live receipt must be R-2026-008.
  const legacyYearDb = getFirestore(adminApp);
  const manifestRef = doc(legacyYearDb, 'festivals/2025_test/manifests/legacy_migration_manifest');
  const legacySeqRef = doc(legacyYearDb, 'festivals/2025_test/sequences/accounting');
  
  const testHistIncomes = [
    { seqNumber: 1, receiptNumber: 'R-2026-001', amount: 2000, date: '2026-11-22', headingName: 'നേർച്ച', description: 'ആദ്യ നേർച്ച' },
    { seqNumber: 2, receiptNumber: 'R-2026-002', amount: 1500, date: '2026-11-23', headingName: 'നേർച്ച', description: 'രണ്ടാം നേർച്ച' },
    { seqNumber: 7, receiptNumber: 'R-2026-007', amount: 3500, date: '2026-11-24', headingName: 'നേർച്ച', description: 'ഏഴാം നേർച്ച' },
  ];
  const realChecksum = await computeMigrationChecksum(testHistIncomes, []);

  const manifestData = {
    manifestId: 'legacy_migration_manifest',
    status: 'DRY_RUN_COMPLETED',
    initiatedAt: '2026-11-22T08:00:00Z',
    adminEmail: 'jijopjohn@gmail.com',
    totalIncomesMigrated: 3,
    totalExpensesMigrated: 0,
    maxHistoricalReceiptSeq: 7, // Non-consecutive: max number is 7
    maxHistoricalVoucherSeq: 0,
    totalIncomeAmount: 7000,
    totalExpenseAmount: 0,
    checksumSha256: realChecksum,
  };

  // Create Manifest
  await setDoc(manifestRef, manifestData);

  // Bootstrap Sequence Counter
  await setDoc(legacySeqRef, {
    yearId: '2025_test',
    lastReceiptSeq: 7, // Matches manifest maxHistoricalReceiptSeq
    lastVoucherSeq: 0,
    lastOperationId: '00000000-0000-4000-8000-000000000000',
    status: 'BOOTSTRAPPED_FROM_LEGACY',
    createdAt: '2026-11-22T08:00:00Z',
  });

  // Seed heading in 2025_test
  const testHeadingRef = doc(legacyYearDb, 'festivals/2025_test/headings/h-legacy-1');
  await setDoc(testHeadingRef, {
    id: 'h-legacy-1',
    name: 'നേർച്ച',
    type: 'INCOME',
    createdAt: '2026-11-22T08:00:00Z',
  });

  // Next live income transaction in 2025_test must allocate seq #8 (R-2026-008)
  const legacyOpId = 'a7777777-7777-4777-8777-777777777777';
  const legacyIncId = 'b7777777-7777-4777-8777-777777777777';
  const legacyAuditId = `audit_${legacyOpId}`;
  const legacyPayload = {
    amount: 1000,
    date: '2026-11-25',
    description: 'പോസ്റ്റ് മൈഗ്രേഷൻ ആദ്യ രസീത്',
    headingId: 'h-legacy-1',
    headingName: 'നേർച്ച',
    paymentMode: 'CASH',
  };
  const legacyHash = computePayloadHash(legacyPayload);
  const legacyNow = '2026-11-25T15:00:00Z';

  const postMigrationResult = await runTransaction(legacyYearDb, async (tx) => {
    const seqSnap = await tx.get(legacySeqRef);
    if (!seqSnap.exists()) throw new Error('SEQ_NOT_FOUND');

    const headSnap = await tx.get(testHeadingRef);
    if (!headSnap.exists()) throw new Error('HEAD_NOT_FOUND');

    const nextSeq = seqSnap.data().lastReceiptSeq + 1; // 7 + 1 = 8
    const receiptNumber = formatReceiptNumber(nextSeq); // R-2026-008

    tx.update(legacySeqRef, {
      lastReceiptSeq: nextSeq,
      lastOperationId: legacyOpId,
      updatedAt: legacyNow,
    });

    tx.set(doc(legacyYearDb, `festivals/2025_test/operations/${legacyOpId}`), {
      operationId: legacyOpId,
      type: 'INCOME',
      entityId: legacyIncId,
      seqNumber: nextSeq,
      allocatedNumber: receiptNumber,
      payloadHash: legacyHash,
      userEmail: 'jijopjohn@gmail.com',
      createdAt: legacyNow,
    });

    tx.set(doc(legacyYearDb, `festivals/2025_test/incomes/${legacyIncId}`), {
      id: legacyIncId,
      receiptNumber,
      seqNumber: nextSeq,
      operationId: legacyOpId,
      payloadHash: legacyHash,
      date: legacyPayload.date,
      headingId: legacyPayload.headingId,
      headingName: legacyPayload.headingName,
      amount: legacyPayload.amount,
      paymentMode: legacyPayload.paymentMode,
      description: legacyPayload.description,
      createdAt: legacyNow,
    });

    tx.set(doc(legacyYearDb, `festivals/2025_test/audit_logs/${legacyAuditId}`), {
      id: legacyAuditId,
      operationId: legacyOpId,
      entityId: legacyIncId,
      entityType: 'INCOME',
      action: 'ADD_INCOME',
      summaryMl: `രസീത് ${receiptNumber} ചേർത്തു`,
      amount: legacyPayload.amount,
      userEmail: 'jijopjohn@gmail.com',
      timestamp: legacyNow,
    });

    return receiptNumber;
  });

  const verifiedLegacySeq = await getDoc(legacySeqRef);

  if (postMigrationResult === 'R-2026-008' && verifiedLegacySeq.data()?.lastReceiptSeq === 8) {
    report.push({
      testName: 'TEST 7: Legacy Migration Bootstrap with Non-Consecutive Records',
      passed: true,
      details: 'Bootstrapped from max serial 7 (count 3). Post-migration live allocation produced sequential receipt R-2026-008 cleanly',
    });
    console.log('[PASS] TEST 7: Legacy migration bootstrap verified. Next allocated receipt was R-2026-008.\n');
  } else {
    report.push({ testName: 'TEST 7', passed: false, details: 'Post-migration allocation failed' });
  }

  // ---------------------------------------------------------------------------
  // TEST 8: Immutability Protection (Update & Delete Denied by Security Rules)
  // ---------------------------------------------------------------------------
  console.log('--- TEST 8: Immutability and Anti-Tamper Enforcement ---');
  let updateBlocked = false;
  let deleteBlocked = false;
  let auditUpdateBlocked = false;
  let seqDeleteBlocked = false;

  // Attempt update on committed income
  try {
    await updateDoc(doc(adminDb, `festivals/2026/incomes/${incId1}`), { amount: 999999 });
  } catch {
    updateBlocked = true;
  }

  // Attempt delete on committed income
  try {
    await deleteDoc(doc(adminDb, `festivals/2026/incomes/${incId1}`));
  } catch {
    deleteBlocked = true;
  }

  // Attempt update on audit log
  try {
    await updateDoc(doc(adminDb, `festivals/2026/audit_logs/${auditId1}`), { summaryMl: 'Tampered summary' });
  } catch {
    auditUpdateBlocked = true;
  }

  // Attempt delete on sequence counter
  try {
    await deleteDoc(seqRef);
  } catch {
    seqDeleteBlocked = true;
  }

  if (updateBlocked && deleteBlocked && auditUpdateBlocked && seqDeleteBlocked) {
    report.push({
      testName: 'TEST 8: Immutability and Anti-Tamper Protection',
      passed: true,
      details: 'Direct update/delete on income, audit log, and sequence counter were all blocked with PERMISSION_DENIED',
    });
    console.log('[PASS] TEST 8: Immutability verified. All tampering attempts rejected by Security Rules.\n');
  } else {
    report.push({ testName: 'TEST 8', passed: false, details: 'Tampering was not prevented' });
  }

  // ---------------------------------------------------------------------------
  // Summary & Snapshots
  // ---------------------------------------------------------------------------
  console.log('========================================================================');
  console.log('PHASE 1.12 TEST RESULTS SUMMARY:');
  console.log('========================================================================');
  let allPassed = true;
  for (const r of report) {
    console.log(`[${r.passed ? 'PASS' : 'FAIL'}] ${r.testName}`);
    console.log(`       Details: ${r.details}`);
    if (!r.passed) allPassed = false;
  }
  console.log('========================================================================');
  console.log(`TOTAL TESTS: ${report.length} | PASSED: ${report.filter((r) => r.passed).length} | FAILED: ${report.filter((r) => !r.passed).length}`);

  if (!allPassed) {
    throw new Error('One or more tests failed');
  }
}

main()
  .then(() => {
    console.log('\n>>> ALL PHASE 1.12 TESTS PASSED SUCCESSFULLY ON REAL FIRESTORE EMULATOR <<<');
    process.exit(0);
  })
  .catch((err) => {
    console.error('Suite error:', err);
    process.exit(1);
  });
