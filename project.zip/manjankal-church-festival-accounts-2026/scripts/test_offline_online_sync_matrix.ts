/**
 * Controlled Offline-to-Online Synchronization Matrix Test (10 Incomes + 10 Expenses)
 * Manjankal Mar Shemavoon Desthuni Orthodox Syrian Church - 2026 Festival Accounts
 * Runs against the local Firestore Emulator with official Firebase Client SDK.
 */

import { initializeApp } from 'firebase/app';
import { getAuth, connectAuthEmulator, signInWithCustomToken } from 'firebase/auth';
import {
  getFirestore,
  connectFirestoreEmulator,
  runTransaction,
  doc,
  getDoc,
  setDoc,
} from 'firebase/firestore';
import { initializeApp as initAdmin, getApps as getAdminApps } from 'firebase-admin/app';
import { getAuth as getAdminAuth } from 'firebase-admin/auth';
import { createHash } from 'crypto';

if (getAdminApps().length === 0) {
  initAdmin({ projectId: 'demo-church' });
}

function computePayloadHash(payload: any): string {
  const normalized = JSON.stringify(payload, Object.keys(payload).sort());
  return createHash('sha256').update(normalized).digest('hex');
}

function formatReceiptNumber(seq: number): string {
  if (seq < 1000) {
    return `R-2026-${String(seq).padStart(3, '0')}`;
  }
  return `R-2026-${seq}`;
}

function formatVoucherNumber(seq: number): string {
  if (seq < 1000) {
    return `V-2026-${String(seq).padStart(3, '0')}`;
  }
  return `V-2026-${seq}`;
}

// Generate RFC 4122 v4 UUID
function generateV4Uuid(prefix: number, index: number): string {
  const p = String(prefix).padStart(8, '0');
  const idx = String(index).padStart(4, '0');
  return `${p}-${idx}-4000-8000-${p}${idx}`;
}

async function runOfflineOnlineSyncTest() {
  console.log("========================================================================");
  console.log("TEST: CONTROLLED OFFLINE-TO-ONLINE SYNC (10 INCOMES + 10 EXPENSES)");
  console.log("========================================================================");

  const adminAuth = getAdminAuth();
  try {
    await adminAuth.createUser({
      uid: 'sync-admin-uid',
      email: 'jijopjohn@gmail.com',
      emailVerified: true,
    });
  } catch {
    // Exists
  }

  const customToken = await adminAuth.createCustomToken('sync-admin-uid', {
    email: 'jijopjohn@gmail.com',
    email_verified: true,
  });

  const clientApp = initializeApp({
    apiKey: 'demo-api-key',
    projectId: 'demo-church',
  }, 'sync-client');
  const clientAuth = getAuth(clientApp);
  connectAuthEmulator(clientAuth, 'http://127.0.0.1:9099', { disableWarnings: true });

  const clientDb = getFirestore(clientApp);
  connectFirestoreEmulator(clientDb, '127.0.0.1', 8088);

  await signInWithCustomToken(clientAuth, customToken);
  console.log("[PASS] Authenticated Super Admin (jijopjohn@gmail.com)");

  const headingIncomeRef = doc(clientDb, 'festivals/2026/headings/h-inc-sync');
  const headingExpenseRef = doc(clientDb, 'festivals/2026/headings/h-exp-sync');

  await setDoc(headingIncomeRef, {
    id: 'h-inc-sync',
    name: 'നേർച്ച & ലേലം',
    type: 'INCOME',
    createdAt: '2026-11-22T08:00:00Z',
  });

  await setDoc(headingExpenseRef, {
    id: 'h-exp-sync',
    name: 'ഭക്ഷണ ചിലവ്',
    type: 'EXPENSE',
    createdAt: '2026-11-22T08:00:00Z',
  });

  const seqRef = doc(clientDb, 'festivals/2026/sequences/accounting');
  await setDoc(seqRef, {
    yearId: '2026',
    lastReceiptSeq: 0,
    lastVoucherSeq: 0,
    lastOperationId: '00000000-0000-4000-8000-000000000000',
    status: 'INITIALIZED_EMPTY',
    createdAt: '2026-11-22T08:00:00Z',
  });
  console.log("[PASS] Clean sequence document initialized for 2026 festival.");

  // 1. GENERATE 10 OFFLINE INCOMES & 10 OFFLINE EXPENSES
  console.log("\n--- Step 1: Simulating 10 Offline Incomes and 10 Offline Expenses ---");
  const offlineIncomes: any[] = [];
  const offlineExpenses: any[] = [];

  for (let i = 1; i <= 10; i++) {
    const payload = {
      amount: 1000 * i,
      date: '2026-11-25',
      description: `Offline Income Donation #${i}`,
      donorName: `Donor ${i}`,
      headingId: 'h-inc-sync',
      headingName: 'നേർച്ച & ലേലം',
      paymentMode: 'CASH',
    };
    const hash = computePayloadHash(payload);
    offlineIncomes.push({
      localId: `offline-inc-${i}`,
      opId: generateV4Uuid(1001, i),
      entityId: generateV4Uuid(2002, i),
      expectedNumber: formatReceiptNumber(i),
      payload,
      hash,
    });
  }

  for (let i = 1; i <= 10; i++) {
    const payload = {
      amount: 500 * i,
      date: '2026-11-26',
      description: `Offline Expense Payment #${i}`,
      paidTo: `Vendor ${i}`,
      headingId: 'h-exp-sync',
      headingName: 'ഭക്ഷണ ചിലവ്',
      paymentMode: 'CASH',
    };
    const hash = computePayloadHash(payload);
    offlineExpenses.push({
      localId: `offline-exp-${i}`,
      opId: generateV4Uuid(3003, i),
      entityId: generateV4Uuid(4004, i),
      expectedNumber: formatVoucherNumber(i),
      payload,
      hash,
    });
  }

  console.log(`[PASS] Generated 10 offline incomes (₹1,000 to ₹10,000) and 10 offline expenses (₹500 to ₹5,000).`);

  // 2. SYNCHRONIZE OFFLINE INCOMES WITH 4-DOCUMENT ATOMIC WRITES
  console.log("\n--- Step 2: Synchronizing 10 Incomes to Cloud Firestore ---");
  for (const item of offlineIncomes) {
    const opRef = doc(clientDb, `festivals/2026/operations/${item.opId}`);
    const incRef = doc(clientDb, `festivals/2026/incomes/${item.entityId}`);
    const auditRef = doc(clientDb, `festivals/2026/audit_logs/audit_${item.opId}`);

    const res = await runTransaction(clientDb, async (transaction) => {
      const opSnap = await transaction.get(opRef);
      if (opSnap.exists()) {
        return { status: 'ALREADY_COMMITTED', num: opSnap.data().allocatedNumber };
      }

      const seqSnap = await transaction.get(seqRef);
      if (!seqSnap.exists()) throw new Error("SEQ_NOT_FOUND");
      const current = seqSnap.data();

      const headSnap = await transaction.get(headingIncomeRef);
      if (!headSnap.exists()) throw new Error("HEAD_NOT_FOUND");

      const nextSeq = current.lastReceiptSeq + 1;
      const receiptNumber = formatReceiptNumber(nextSeq);
      const nowIso = '2026-11-25T12:00:00Z';

      transaction.update(seqRef, {
        lastReceiptSeq: nextSeq,
        lastOperationId: item.opId,
        updatedAt: nowIso,
      });

      transaction.set(opRef, {
        operationId: item.opId,
        type: 'INCOME',
        entityId: item.entityId,
        seqNumber: nextSeq,
        allocatedNumber: receiptNumber,
        payloadHash: item.hash,
        userEmail: 'jijopjohn@gmail.com',
        createdAt: nowIso,
      });

      transaction.set(incRef, {
        id: item.entityId,
        receiptNumber,
        seqNumber: nextSeq,
        operationId: item.opId,
        payloadHash: item.hash,
        date: item.payload.date,
        headingId: item.payload.headingId,
        headingName: item.payload.headingName,
        amount: item.payload.amount,
        paymentMode: item.payload.paymentMode,
        description: item.payload.description,
        donorName: item.payload.donorName,
        createdAt: nowIso,
      });

      transaction.set(auditRef, {
        id: `audit_${item.opId}`,
        operationId: item.opId,
        entityId: item.entityId,
        entityType: 'INCOME',
        action: 'ADD_INCOME',
        summaryMl: `രസീത് ${receiptNumber} സിങ്ക് ചെയ്തു`,
        amount: item.payload.amount,
        userEmail: 'jijopjohn@gmail.com',
        timestamp: nowIso,
      });

      return { status: 'COMMITTED_NEW', num: receiptNumber };
    });

    if (res.num !== item.expectedNumber) {
      throw new Error(`Receipt number mismatch: expected ${item.expectedNumber}, got ${res.num}`);
    }
  }
  console.log(`[PASS] All 10 offline income transactions synced sequentially: R-2026-001 to R-2026-010.`);

  // 3. SYNCHRONIZE OFFLINE EXPENSES WITH 4-DOCUMENT ATOMIC WRITES
  console.log("\n--- Step 3: Synchronizing 10 Expenses to Cloud Firestore ---");
  for (const item of offlineExpenses) {
    const opRef = doc(clientDb, `festivals/2026/operations/${item.opId}`);
    const expRef = doc(clientDb, `festivals/2026/expenses/${item.entityId}`);
    const auditRef = doc(clientDb, `festivals/2026/audit_logs/audit_${item.opId}`);

    const res = await runTransaction(clientDb, async (transaction) => {
      const opSnap = await transaction.get(opRef);
      if (opSnap.exists()) {
        return { status: 'ALREADY_COMMITTED', num: opSnap.data().allocatedNumber };
      }

      const seqSnap = await transaction.get(seqRef);
      if (!seqSnap.exists()) throw new Error("SEQ_NOT_FOUND");
      const current = seqSnap.data();

      const headSnap = await transaction.get(headingExpenseRef);
      if (!headSnap.exists()) throw new Error("HEAD_NOT_FOUND");

      const nextSeq = current.lastVoucherSeq + 1;
      const voucherNumber = formatVoucherNumber(nextSeq);
      const nowIso = '2026-11-26T12:00:00Z';

      transaction.update(seqRef, {
        lastVoucherSeq: nextSeq,
        lastOperationId: item.opId,
        updatedAt: nowIso,
      });

      transaction.set(opRef, {
        operationId: item.opId,
        type: 'EXPENSE',
        entityId: item.entityId,
        seqNumber: nextSeq,
        allocatedNumber: voucherNumber,
        payloadHash: item.hash,
        userEmail: 'jijopjohn@gmail.com',
        createdAt: nowIso,
      });

      transaction.set(expRef, {
        id: item.entityId,
        voucherNumber,
        seqNumber: nextSeq,
        operationId: item.opId,
        payloadHash: item.hash,
        date: item.payload.date,
        headingId: item.payload.headingId,
        headingName: item.payload.headingName,
        amount: item.payload.amount,
        paymentMode: item.payload.paymentMode,
        description: item.payload.description,
        paidTo: item.payload.paidTo,
        createdAt: nowIso,
      });

      transaction.set(auditRef, {
        id: `audit_${item.opId}`,
        operationId: item.opId,
        entityId: item.entityId,
        entityType: 'EXPENSE',
        action: 'ADD_EXPENSE',
        summaryMl: `വൗച്ചർ ${voucherNumber} സിങ്ക് ചെയ്തു`,
        amount: item.payload.amount,
        userEmail: 'jijopjohn@gmail.com',
        timestamp: nowIso,
      });

      return { status: 'COMMITTED_NEW', num: voucherNumber };
    });

    if (res.num !== item.expectedNumber) {
      throw new Error(`Voucher number mismatch: expected ${item.expectedNumber}, got ${res.num}`);
    }
  }
  console.log(`[PASS] All 10 offline expense transactions synced sequentially: V-2026-001 to V-2026-010.`);

  // 4. RETRY ALL 20 TRANSACTIONS TO PROVE IDEMPOTENT RE-SYNC SAFETY
  console.log("\n--- Step 4: Re-running Sync for All 20 Records (Double Sync / Replay Test) ---");
  let alreadyCommittedCount = 0;
  for (const item of [...offlineIncomes, ...offlineExpenses]) {
    const opRef = doc(clientDb, `festivals/2026/operations/${item.opId}`);
    const res = await runTransaction(clientDb, async (transaction) => {
      const opSnap = await transaction.get(opRef);
      if (opSnap.exists()) {
        return { status: 'ALREADY_COMMITTED', num: opSnap.data().allocatedNumber };
      }
      throw new Error("Should have been committed already!");
    });
    if (res.status === 'ALREADY_COMMITTED') {
      alreadyCommittedCount++;
    }
  }

  if (alreadyCommittedCount !== 20) {
    throw new Error(`Expected 20 ALREADY_COMMITTED returns, got ${alreadyCommittedCount}`);
  }
  console.log(`[PASS] Re-sync test verified: Exactly 20/20 transactions detected as already committed. Zero duplicates allocated.`);

  // 5. VERIFY FINAL SEQUENCE COUNTER STATE
  const finalSeq = (await getDoc(seqRef)).data();
  console.log(`\n--- Step 5: Final Sequence Counter Verification ---`);
  console.log(`  lastReceiptSeq: ${finalSeq?.lastReceiptSeq} (Expected 10)`);
  console.log(`  lastVoucherSeq: ${finalSeq?.lastVoucherSeq} (Expected 10)`);
  console.log(`  status: ${finalSeq?.status} (Expected INITIALIZED_EMPTY)`);

  if (finalSeq?.lastReceiptSeq !== 10 || finalSeq?.lastVoucherSeq !== 10) {
    throw new Error("Final sequence counter state mismatch!");
  }
  console.log(`[PASS] Sequence state is strictly monotonic and consistent.`);

  console.log("\n========================================================================");
  console.log(">>> ALL 10+10 OFFLINE-TO-ONLINE SYNC CHECKS PASSED SUCCESSFULLY <<<");
  console.log("========================================================================");
}

runOfflineOnlineSyncTest().then(() => {
  process.exit(0);
}).catch(err => {
  console.error("Sync test failed:", err);
  process.exit(1);
});
