#!/usr/bin/env python3
"""
Source Code Archiver for Manjankal Mar Shemavoon Desthuni Orthodox Syrian Church
2026 Festival Accounts Management System

Packages the complete pristine source tree into a standard ZIP archive.
Strictly excludes:
- node_modules
- dist / build output
- .git
- credentials, private keys, live .env files
- runtime debug logs
"""

import os
import zipfile
import sys

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
PUBLIC_DIR = os.path.join(BASE_DIR, 'public')
DIST_DIR = os.path.join(BASE_DIR, 'dist')
ZIP_FILENAME = 'manjankal-church-festival-accounts-2026.zip'

EXCLUDE_DIRS = {
    'node_modules',
    'dist',
    '.git',
    '.aistudio',
    '__pycache__',
    '.turbo',
    '.next'
}

EXCLUDE_FILES = {
    '.env',
    '.env.local',
    '.audit_logs_store.json',
    'firestore-debug.log',
    ZIP_FILENAME
}

EXCLUDE_EXTENSIONS = {
    '.pyc',
    '.log',
    '.tmp',
    '.zip'
}

def should_exclude(rel_path):
    parts = rel_path.split(os.sep)
    for p in parts:
        if p in EXCLUDE_DIRS:
            return True
    filename = os.path.basename(rel_path)
    if filename in EXCLUDE_FILES:
        return True
    if any(filename.endswith(ext) for ext in EXCLUDE_EXTENSIONS):
        return True
    if filename.startswith('.env') and filename != '.env.example':
        return True
    return False

def create_zip(target_zip_path):
    os.makedirs(os.path.dirname(target_zip_path), exist_ok=True)
    count = 0
    total_uncompressed = 0
    
    with zipfile.ZipFile(target_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(BASE_DIR):
            # Prune excluded directories in-place (allow .github explicitly)
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS and (not d.startswith('.') or d == '.github')]
            
            for file in files:
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, BASE_DIR)
                
                if should_exclude(rel_path):
                    continue
                
                file_size = os.path.getsize(full_path)
                total_uncompressed += file_size
                count += 1
                
                # Archive name prefixed with clean root folder
                archive_name = os.path.join('manjankal-church-festival-accounts-2026', rel_path)
                zipf.write(full_path, archive_name)
    
    zip_size = os.path.getsize(target_zip_path)
    print(f"[OK] Archived {count} files ({total_uncompressed / 1024 / 1024:.2f} MB uncompressed) into: {target_zip_path}")
    print(f"     Compressed ZIP size: {zip_size / 1024 / 1024:.2f} MB ({zip_size} bytes)")
    return count, zip_size

if __name__ == '__main__':
    import shutil
    print("=" * 70)
    print("PACKAGING MANJANKAL CHURCH 2026 FESTIVAL ACCOUNTS SOURCE CODE")
    print("=" * 70)
    
    # 1. Output to root directory
    root_target = os.path.join(BASE_DIR, ZIP_FILENAME)
    count, size = create_zip(root_target)
    
    # 2. Output to public/ for HTTP download
    public_target = os.path.join(PUBLIC_DIR, ZIP_FILENAME)
    shutil.copyfile(root_target, public_target)
    shutil.copyfile(root_target, os.path.join(PUBLIC_DIR, 'source-code.zip'))
    
    # 3. Output to dist/ if dist exists
    if os.path.exists(DIST_DIR):
        dist_target = os.path.join(DIST_DIR, ZIP_FILENAME)
        shutil.copyfile(root_target, dist_target)
        shutil.copyfile(root_target, os.path.join(DIST_DIR, 'source-code.zip'))

    # 4. Output to Google AI Studio artifacts directory
    artifact_dir = '/.aistudio/artifacts/brain/3e9a34d6-5408-4817-a1af-11853a277840'
    if os.path.exists(artifact_dir):
        artifact_target = os.path.join(artifact_dir, ZIP_FILENAME)
        shutil.copyfile(root_target, artifact_target)
        print(f"  - {artifact_target}")
    
    print("\n[SUCCESS] Clean source code archive ready at:")
    print(f"  - /{ZIP_FILENAME}")
    print(f"  - /public/{ZIP_FILENAME}")
    print(f"  - /public/source-code.zip")
    if os.path.exists(DIST_DIR):
        print(f"  - /dist/{ZIP_FILENAME}")
        print(f"  - /dist/source-code.zip")
    sys.exit(0)
