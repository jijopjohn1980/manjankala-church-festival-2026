/**
 * PHASE 1.13 — Fresh Consistent Snapshot Capture Suite
 * Captures clean, internally consistent document snapshots from the official Firestore Emulator
 * after:
 * 1. One income transaction
 * 2. One expense transaction
 * 3. Five concurrent income transactions
 * 4. One successful legacy bootstrap & post-migration transaction
 */

import { initializeApp } from 'firebase/app';
import { getAuth, connectAuthEmulator, signInWithCustomToken } from 'firebase/auth';
import {
  getFirestore,
  connectFirestoreEmulator,
  runTransaction,
  doc,
  getDoc,
  setDoc,
} from 'firebase/firestore';
import { initializeApp as initAdmin, getApps as getAdminApps } from 'firebase-admin/app';
import { getAuth as getAdminAuth } from 'firebase-admin/auth';
import { createHash } from 'crypto';
import { computeMigrationChecksum } from '../src/utils/payloadNormalization';

if (getAdminApps().length === 0) {
  initAdmin({ projectId: 'demo-church' });
}

function computePayloadHash(payload: any): string {
  const normalized = JSON.stringify(payload, Object.keys(payload).sort());
  return createHash('sha256').update(normalized).digest('hex');
}

function formatReceiptNumber(seq: number): string {
  if (seq < 1000) return `R-2026-${String(seq).padStart(3, '0')}`;
  return `R-2026-${seq}`;
}

function formatVoucherNumber(seq: number): string {
  if (seq < 1000) return `V-2026-${String(seq).padStart(3, '0')}`;
  return `V-2026-${seq}`;
}

async function main() {
  console.log('========================================================================');
  console.log('PHASE 1.13: CAPTURING FRESH INTERNALLY CONSISTENT EMULATOR SNAPSHOTS');
  console.log('========================================================================\n');

  const adminAuth = getAdminAuth();
  try {
    await adminAuth.createUser({
      uid: 'super-admin-uid-113',
      email: 'jijopjohn@gmail.com',
      emailVerified: true,
    });
  } catch {}

  const customToken = await adminAuth.createCustomToken('super-admin-uid-113', {
    email: 'jijopjohn@gmail.com',
    email_verified: true,
  });

  const app = initializeApp({ apiKey: 'fake-api-key', projectId: 'demo-church' });
  const auth = getAuth(app);
  connectAuthEmulator(auth, 'http://127.0.0.1:9099', { disableWarnings: true });
  const db = getFirestore(app);
  connectFirestoreEmulator(db, '127.0.0.1', 8088);
  await signInWithCustomToken(auth, customToken);

  // Setup Headings
  const incHeadRef = doc(db, 'festivals/2026/headings/h-income-main');
  await setDoc(incHeadRef, {
    id: 'h-income-main',
    name: 'നേർച്ച',
    type: 'INCOME',
    createdAt: '2026-11-22T08:00:00Z',
  });

  const expHeadRef = doc(db, 'festivals/2026/headings/h-expense-main');
  await setDoc(expHeadRef, {
    id: 'h-expense-main',
    name: 'വൈദ്യുതി & ലൈറ്റ്',
    type: 'EXPENSE',
    createdAt: '2026-11-22T08:00:00Z',
  });

  // Setup Initial Sequence Counter
  const seqRef = doc(db, 'festivals/2026/sequences/accounting');
  await setDoc(seqRef, {
    yearId: '2026',
    lastReceiptSeq: 0,
    lastVoucherSeq: 0,
    lastOperationId: '00000000-0000-4000-8000-000000000000',
    status: 'INITIALIZED_EMPTY',
    createdAt: '2026-11-22T08:00:00Z',
  });

  // ---------------------------------------------------------------------------
  // MILESTONE 1: One Income Transaction
  // ---------------------------------------------------------------------------
  console.log('--- Executing Milestone 1: One Income Transaction ---');
  const m1OpId = '10000000-0000-4000-8000-000000000001';
  const m1IncId = '20000000-0000-4000-8000-000000000001';
  const m1AuditId = `audit_${m1OpId}`;
  const m1Now = '2026-11-25T10:00:00Z';
  const m1Payload = {
    amount: 1000,
    date: '2026-11-25',
    description: 'നേർച്ച സമർപ്പണം',
    headingId: 'h-income-main',
    headingName: 'നേർച്ച',
    paymentMode: 'CASH',
  };
  const m1Hash = computePayloadHash(m1Payload);

  await runTransaction(db, async (tx) => {
    const seqSnap = await tx.get(seqRef);
    const headSnap = await tx.get(incHeadRef);
    const nextSeq = seqSnap.data()!.lastReceiptSeq + 1;
    const receiptNumber = formatReceiptNumber(nextSeq);

    tx.update(seqRef, {
      lastReceiptSeq: nextSeq,
      lastOperationId: m1OpId,
      updatedAt: m1Now,
    });

    tx.set(doc(db, `festivals/2026/operations/${m1OpId}`), {
      operationId: m1OpId,
      type: 'INCOME',
      entityId: m1IncId,
      seqNumber: nextSeq,
      allocatedNumber: receiptNumber,
      payloadHash: m1Hash,
      userEmail: 'jijopjohn@gmail.com',
      createdAt: m1Now,
    });

    tx.set(doc(db, `festivals/2026/incomes/${m1IncId}`), {
      id: m1IncId,
      receiptNumber,
      seqNumber: nextSeq,
      operationId: m1OpId,
      payloadHash: m1Hash,
      date: m1Payload.date,
      headingId: m1Payload.headingId,
      headingName: m1Payload.headingName,
      amount: m1Payload.amount,
      paymentMode: m1Payload.paymentMode,
      description: m1Payload.description,
      createdAt: m1Now,
    });

    tx.set(doc(db, `festivals/2026/audit_logs/${m1AuditId}`), {
      id: m1AuditId,
      operationId: m1OpId,
      entityId: m1IncId,
      entityType: 'INCOME',
      action: 'ADD_INCOME',
      summaryMl: `രസീത് ${receiptNumber} ചേർത്തു`,
      amount: m1Payload.amount,
      userEmail: 'jijopjohn@gmail.com',
      timestamp: m1Now,
    });
  });

  const snapM1Seq = (await getDoc(seqRef)).data();
  const snapM1Inc = (await getDoc(doc(db, `festivals/2026/incomes/${m1IncId}`))).data();
  const snapM1Op = (await getDoc(doc(db, `festivals/2026/operations/${m1OpId}`))).data();
  const snapM1Audit = (await getDoc(doc(db, `festivals/2026/audit_logs/${m1AuditId}`))).data();

  console.log('\n>>> SNAPSHOT 1 (After 1 Income Transaction):');
  console.log('Sequence Counter:', JSON.stringify(snapM1Seq, null, 2));
  console.log('Income Document:', JSON.stringify(snapM1Inc, null, 2));
  console.log('Operation Document:', JSON.stringify(snapM1Op, null, 2));
  console.log('Audit Log Document:', JSON.stringify(snapM1Audit, null, 2));

  // ---------------------------------------------------------------------------
  // MILESTONE 2: One Expense Transaction
  // ---------------------------------------------------------------------------
  console.log('\n--- Executing Milestone 2: One Expense Transaction ---');
  const m2OpId = '10000000-0000-4000-8000-000000000002';
  const m2ExpId = '20000000-0000-4000-8000-000000000002';
  const m2AuditId = `audit_${m2OpId}`;
  const m2Now = '2026-11-25T11:00:00Z';
  const m2Payload = {
    amount: 1500,
    date: '2026-11-25',
    description: 'ജനറേറ്റർ ഇന്ധന ചാർജ്ജ്',
    headingId: 'h-expense-main',
    headingName: 'വൈദ്യുതി & ലൈറ്റ്',
    paidTo: 'സന്തോഷ് കുമാർ',
    paymentMode: 'CASH',
  };
  const m2Hash = computePayloadHash(m2Payload);

  await runTransaction(db, async (tx) => {
    const seqSnap = await tx.get(seqRef);
    const headSnap = await tx.get(expHeadRef);
    const nextSeq = seqSnap.data()!.lastVoucherSeq + 1;
    const voucherNumber = formatVoucherNumber(nextSeq);

    tx.update(seqRef, {
      lastVoucherSeq: nextSeq,
      lastOperationId: m2OpId,
      updatedAt: m2Now,
    });

    tx.set(doc(db, `festivals/2026/operations/${m2OpId}`), {
      operationId: m2OpId,
      type: 'EXPENSE',
      entityId: m2ExpId,
      seqNumber: nextSeq,
      allocatedNumber: voucherNumber,
      payloadHash: m2Hash,
      userEmail: 'jijopjohn@gmail.com',
      createdAt: m2Now,
    });

    tx.set(doc(db, `festivals/2026/expenses/${m2ExpId}`), {
      id: m2ExpId,
      voucherNumber,
      seqNumber: nextSeq,
      operationId: m2OpId,
      payloadHash: m2Hash,
      date: m2Payload.date,
      paidTo: m2Payload.paidTo,
      headingId: m2Payload.headingId,
      headingName: m2Payload.headingName,
      amount: m2Payload.amount,
      paymentMode: m2Payload.paymentMode,
      description: m2Payload.description,
      createdAt: m2Now,
    });

    tx.set(doc(db, `festivals/2026/audit_logs/${m2AuditId}`), {
      id: m2AuditId,
      operationId: m2OpId,
      entityId: m2ExpId,
      entityType: 'EXPENSE',
      action: 'ADD_EXPENSE',
      summaryMl: `വൗച്ചർ ${voucherNumber} ചേർത്തു`,
      amount: m2Payload.amount,
      userEmail: 'jijopjohn@gmail.com',
      timestamp: m2Now,
    });
  });

  const snapM2Seq = (await getDoc(seqRef)).data();
  const snapM2Exp = (await getDoc(doc(db, `festivals/2026/expenses/${m2ExpId}`))).data();
  const snapM2Op = (await getDoc(doc(db, `festivals/2026/operations/${m2OpId}`))).data();
  const snapM2Audit = (await getDoc(doc(db, `festivals/2026/audit_logs/${m2AuditId}`))).data();

  console.log('\n>>> SNAPSHOT 2 (After 1 Expense Transaction):');
  console.log('Sequence Counter:', JSON.stringify(snapM2Seq, null, 2));
  console.log('Expense Document:', JSON.stringify(snapM2Exp, null, 2));
  console.log('Operation Document:', JSON.stringify(snapM2Op, null, 2));
  console.log('Audit Log Document:', JSON.stringify(snapM2Audit, null, 2));

  // ---------------------------------------------------------------------------
  // MILESTONE 3: Five Concurrent Income Transactions
  // ---------------------------------------------------------------------------
  console.log('\n--- Executing Milestone 3: Five Concurrent Income Transactions ---');
  const m3Ops = [
    { opId: '30000000-0000-4000-8000-000000000001', incId: '40000000-0000-4000-8000-000000000001', amount: 500, desc: 'ഭക്തജന നേർച്ച #1' },
    { opId: '30000000-0000-4000-8000-000000000002', incId: '40000000-0000-4000-8000-000000000002', amount: 750, desc: 'ഭക്തജന നേർച്ച #2' },
    { opId: '30000000-0000-4000-8000-000000000003', incId: '40000000-0000-4000-8000-000000000003', amount: 1200, desc: 'ഭക്തജന നേർച്ച #3' },
    { opId: '30000000-0000-4000-8000-000000000004', incId: '40000000-0000-4000-8000-000000000004', amount: 2000, desc: 'ഭക്തജന നേർച്ച #4' },
    { opId: '30000000-0000-4000-8000-000000000005', incId: '40000000-0000-4000-8000-000000000005', amount: 3000, desc: 'ഭക്തജന നേർച്ച #5' },
  ];

  await Promise.all(
    m3Ops.map(async (item, idx) => {
      const payload = {
        amount: item.amount,
        date: '2026-11-26',
        description: item.desc,
        headingId: 'h-income-main',
        headingName: 'നേർച്ച',
        paymentMode: 'CASH',
      };
      const pHash = computePayloadHash(payload);
      const auditId = `audit_${item.opId}`;

      let attempts = 0;
      while (attempts < 5) {
        attempts++;
        try {
          const nowIso = `2026-11-26T10:0${attempts}:00Z`;
          return await runTransaction(db, async (tx) => {
            const opSnap = await tx.get(doc(db, `festivals/2026/operations/${item.opId}`));
            if (opSnap.exists()) return opSnap.data();

            const seqSnap = await tx.get(seqRef);
            const headSnap = await tx.get(incHeadRef);
            const nextSeq = seqSnap.data()!.lastReceiptSeq + 1;
            const receiptNumber = formatReceiptNumber(nextSeq);

            tx.update(seqRef, {
              lastReceiptSeq: nextSeq,
              lastOperationId: item.opId,
              updatedAt: nowIso,
            });

            tx.set(doc(db, `festivals/2026/operations/${item.opId}`), {
              operationId: item.opId,
              type: 'INCOME',
              entityId: item.incId,
              seqNumber: nextSeq,
              allocatedNumber: receiptNumber,
              payloadHash: pHash,
              userEmail: 'jijopjohn@gmail.com',
              createdAt: nowIso,
            });

            tx.set(doc(db, `festivals/2026/incomes/${item.incId}`), {
              id: item.incId,
              receiptNumber,
              seqNumber: nextSeq,
              operationId: item.opId,
              payloadHash: pHash,
              date: payload.date,
              headingId: payload.headingId,
              headingName: payload.headingName,
              amount: payload.amount,
              paymentMode: payload.paymentMode,
              description: payload.description,
              createdAt: nowIso,
            });

            tx.set(doc(db, `festivals/2026/audit_logs/${auditId}`), {
              id: auditId,
              operationId: item.opId,
              entityId: item.incId,
              entityType: 'INCOME',
              action: 'ADD_INCOME',
              summaryMl: `രസീത് ${receiptNumber} ചേർത്തു`,
              amount: payload.amount,
              userEmail: 'jijopjohn@gmail.com',
              timestamp: nowIso,
            });

            return { receiptNumber, seqNumber: nextSeq };
          });
        } catch (err: any) {
          if (attempts >= 5) throw err;
          await new Promise((r) => setTimeout(r, 40 * attempts + Math.random() * 40));
        }
      }
    })
  );

  const snapM3Seq = (await getDoc(seqRef)).data();
  // Fetch the final operation committed in the sequence counter
  const finalOpId = snapM3Seq!.lastOperationId;
  const snapM3Op = (await getDoc(doc(db, `festivals/2026/operations/${finalOpId}`))).data();
  const snapM3Inc = (await getDoc(doc(db, `festivals/2026/incomes/${snapM3Op!.entityId}`))).data();
  const snapM3Audit = (await getDoc(doc(db, `festivals/2026/audit_logs/audit_${finalOpId}`))).data();

  console.log('\n>>> SNAPSHOT 3 (After 5 Concurrent Income Transactions - Final State):');
  console.log('Sequence Counter (After 5 concurrent writes):', JSON.stringify(snapM3Seq, null, 2));
  console.log(`Final Operation Doc (${finalOpId}):`, JSON.stringify(snapM3Op, null, 2));
  console.log(`Final Income Doc (${snapM3Op!.entityId}):`, JSON.stringify(snapM3Inc, null, 2));
  console.log(`Final Audit Doc (audit_${finalOpId}):`, JSON.stringify(snapM3Audit, null, 2));

  // ---------------------------------------------------------------------------
  // MILESTONE 4: Successful Legacy Bootstrap & Post-Migration Transaction
  // ---------------------------------------------------------------------------
  console.log('\n--- Executing Milestone 4: Legacy Bootstrap & First Live Record ---');
  const bootstrappedYear = '2026_bootstrapped';
  const manifestRef = doc(db, `festivals/${bootstrappedYear}/manifests/legacy_migration_manifest`);
  const legacySeqRef = doc(db, `festivals/${bootstrappedYear}/sequences/accounting`);
  const legacyIncHeadRef = doc(db, `festivals/${bootstrappedYear}/headings/h-legacy-income`);
  const legacyExpHeadRef = doc(db, `festivals/${bootstrappedYear}/headings/h-legacy-expense`);

  await setDoc(legacyIncHeadRef, {
    id: 'h-legacy-income',
    name: 'നേർച്ച',
    type: 'INCOME',
    createdAt: '2026-11-22T08:00:00Z',
  });

  await setDoc(legacyExpHeadRef, {
    id: 'h-legacy-expense',
    name: 'വൈദ്യുതി & ലൈറ്റ്',
    type: 'EXPENSE',
    createdAt: '2026-11-22T08:00:00Z',
  });

  // Historical Records (Total Income: ₹7,000, Max Seq: 7 | Total Expense: ₹5,000, Max Seq: 5)
  const historicalIncomes = [
    { seqNumber: 1, receiptNumber: 'R-2026-001', amount: 2000, date: '2026-11-22', headingName: 'നേർച്ച', description: 'ആദ്യ നേർച്ച' },
    { seqNumber: 2, receiptNumber: 'R-2026-002', amount: 1500, date: '2026-11-23', headingName: 'നേർച്ച', description: 'രണ്ടാം നേർച്ച' },
    { seqNumber: 7, receiptNumber: 'R-2026-007', amount: 3500, date: '2026-11-24', headingName: 'നേർച്ച', description: 'ഏഴാം നേർച്ച' },
  ];
  const historicalExpenses = [
    { seqNumber: 1, voucherNumber: 'V-2026-001', amount: 2000, date: '2026-11-22', headingName: 'വൈദ്യുതി & ലൈറ്റ്', description: 'ലൈറ്റിംഗ്' },
    { seqNumber: 5, voucherNumber: 'V-2026-005', amount: 3000, date: '2026-11-24', headingName: 'വൈദ്യുതി & ലൈറ്റ്', description: 'ജനറേറ്റർ' },
  ];

  const realMigrationChecksum = await computeMigrationChecksum(historicalIncomes, historicalExpenses);

  const manifestData = {
    manifestId: 'legacy_migration_manifest',
    status: 'DRY_RUN_COMPLETED',
    initiatedAt: '2026-11-22T08:00:00Z',
    adminEmail: 'jijopjohn@gmail.com',
    totalIncomesMigrated: 3,
    totalExpensesMigrated: 2,
    maxHistoricalReceiptSeq: 7, // Non-consecutive: 001, 002, 007
    maxHistoricalVoucherSeq: 5, // Non-consecutive: 001, 005
    totalIncomeAmount: 7000,
    totalExpenseAmount: 5000,
    checksumSha256: realMigrationChecksum,
  };
  await setDoc(manifestRef, manifestData);

  // Bootstrap Sequence Counter
  await setDoc(legacySeqRef, {
    yearId: bootstrappedYear,
    lastReceiptSeq: 7, // Exactly matches manifest.maxHistoricalReceiptSeq
    lastVoucherSeq: 5, // Exactly matches manifest.maxHistoricalVoucherSeq
    lastOperationId: '00000000-0000-4000-8000-000000000000',
    status: 'BOOTSTRAPPED_FROM_LEGACY',
    createdAt: '2026-11-22T08:00:00Z',
  });

  const snapBootstrappedSeq = (await getDoc(legacySeqRef)).data();
  const snapManifest = (await getDoc(manifestRef)).data();

  console.log('\n>>> SNAPSHOT 4A (Immediately After Legacy Bootstrap):');
  console.log('Migration Manifest:', JSON.stringify(snapManifest, null, 2));
  console.log('Bootstrapped Sequence Counter:', JSON.stringify(snapBootstrappedSeq, null, 2));

  // Execute First Post-Migration Live Transaction (Must allocate seq 8 -> R-2026-008)
  const m4OpId = '50000000-0000-4000-8000-000000000001';
  const m4IncId = '60000000-0000-4000-8000-000000000001';
  const m4AuditId = `audit_${m4OpId}`;
  const m4Now = '2026-11-26T14:00:00Z';
  const m4Payload = {
    amount: 2000,
    date: '2026-11-26',
    description: 'പോസ്റ്റ് മൈഗ്രേഷൻ തത്സമയ രസീത്',
    headingId: 'h-legacy-income',
    headingName: 'നേർച്ച',
    paymentMode: 'CASH',
  };
  const m4Hash = computePayloadHash(m4Payload);

  await runTransaction(db, async (tx) => {
    const seqSnap = await tx.get(legacySeqRef);
    const headSnap = await tx.get(legacyIncHeadRef);
    const nextSeq = seqSnap.data()!.lastReceiptSeq + 1; // 7 + 1 = 8
    const receiptNumber = formatReceiptNumber(nextSeq); // R-2026-008

    tx.update(legacySeqRef, {
      lastReceiptSeq: nextSeq,
      lastOperationId: m4OpId,
      updatedAt: m4Now,
    });

    tx.set(doc(db, `festivals/${bootstrappedYear}/operations/${m4OpId}`), {
      operationId: m4OpId,
      type: 'INCOME',
      entityId: m4IncId,
      seqNumber: nextSeq,
      allocatedNumber: receiptNumber,
      payloadHash: m4Hash,
      userEmail: 'jijopjohn@gmail.com',
      createdAt: m4Now,
    });

    tx.set(doc(db, `festivals/${bootstrappedYear}/incomes/${m4IncId}`), {
      id: m4IncId,
      receiptNumber,
      seqNumber: nextSeq,
      operationId: m4OpId,
      payloadHash: m4Hash,
      date: m4Payload.date,
      headingId: m4Payload.headingId,
      headingName: m4Payload.headingName,
      amount: m4Payload.amount,
      paymentMode: m4Payload.paymentMode,
      description: m4Payload.description,
      createdAt: m4Now,
    });

    tx.set(doc(db, `festivals/${bootstrappedYear}/audit_logs/${m4AuditId}`), {
      id: m4AuditId,
      operationId: m4OpId,
      entityId: m4IncId,
      entityType: 'INCOME',
      action: 'ADD_INCOME',
      summaryMl: `രസീത് ${receiptNumber} ചേർത്തു`,
      amount: m4Payload.amount,
      userEmail: 'jijopjohn@gmail.com',
      timestamp: m4Now,
    });
  });

  // Execute First Post-Migration Live Expense Voucher (Must allocate seq 6 -> V-2026-006)
  const m4VoucherOpId = '50000000-0000-4000-8000-000000000002';
  const m4ExpId = '60000000-0000-4000-8000-000000000002';
  const m4VoucherAuditId = `audit_${m4VoucherOpId}`;
  const m4VoucherNow = '2026-11-26T14:30:00Z';
  const m4VoucherPayload = {
    amount: 1500,
    date: '2026-11-26',
    description: 'പോസ്റ്റ് മൈഗ്രേഷൻ തത്സമയ വൗച്ചർ',
    headingId: 'h-legacy-expense',
    headingName: 'വൈദ്യുതി & ലൈറ്റ്',
    paidTo: 'സന്തോഷ് കുമാർ',
    paymentMode: 'CASH',
  };
  const m4VoucherHash = computePayloadHash(m4VoucherPayload);

  await runTransaction(db, async (tx) => {
    const seqSnap = await tx.get(legacySeqRef);
    const headSnap = await tx.get(legacyExpHeadRef);
    const nextSeq = seqSnap.data()!.lastVoucherSeq + 1; // 5 + 1 = 6
    const voucherNumber = formatVoucherNumber(nextSeq); // V-2026-006

    tx.update(legacySeqRef, {
      lastVoucherSeq: nextSeq,
      lastOperationId: m4VoucherOpId,
      updatedAt: m4VoucherNow,
    });

    tx.set(doc(db, `festivals/${bootstrappedYear}/operations/${m4VoucherOpId}`), {
      operationId: m4VoucherOpId,
      type: 'EXPENSE',
      entityId: m4ExpId,
      seqNumber: nextSeq,
      allocatedNumber: voucherNumber,
      payloadHash: m4VoucherHash,
      userEmail: 'jijopjohn@gmail.com',
      createdAt: m4VoucherNow,
    });

    tx.set(doc(db, `festivals/${bootstrappedYear}/expenses/${m4ExpId}`), {
      id: m4ExpId,
      voucherNumber,
      seqNumber: nextSeq,
      operationId: m4VoucherOpId,
      payloadHash: m4VoucherHash,
      date: m4VoucherPayload.date,
      paidTo: m4VoucherPayload.paidTo,
      headingId: m4VoucherPayload.headingId,
      headingName: m4VoucherPayload.headingName,
      amount: m4VoucherPayload.amount,
      paymentMode: m4VoucherPayload.paymentMode,
      description: m4VoucherPayload.description,
      createdAt: m4VoucherNow,
    });

    tx.set(doc(db, `festivals/${bootstrappedYear}/audit_logs/${m4VoucherAuditId}`), {
      id: m4VoucherAuditId,
      operationId: m4VoucherOpId,
      entityId: m4ExpId,
      entityType: 'EXPENSE',
      action: 'ADD_EXPENSE',
      summaryMl: `വൗച്ചർ ${voucherNumber} ചേർത്തു`,
      amount: m4VoucherPayload.amount,
      userEmail: 'jijopjohn@gmail.com',
      timestamp: m4VoucherNow,
    });
  });

  const snapM4Seq = (await getDoc(legacySeqRef)).data();
  const snapM4Inc = (await getDoc(doc(db, `festivals/${bootstrappedYear}/incomes/${m4IncId}`))).data();
  const snapM4Exp = (await getDoc(doc(db, `festivals/${bootstrappedYear}/expenses/${m4ExpId}`))).data();
  const snapM4Op = (await getDoc(doc(db, `festivals/${bootstrappedYear}/operations/${m4OpId}`))).data();
  const snapM4Audit = (await getDoc(doc(db, `festivals/${bootstrappedYear}/audit_logs/${m4AuditId}`))).data();

  console.log('\n>>> SNAPSHOT 4B (After First Post-Migration Live Transactions - Receipt #8 & Voucher #6):');
  console.log('Sequence Counter (seq 8 receipts, seq 6 vouchers):', JSON.stringify(snapM4Seq, null, 2));
  console.log('Income Document (R-2026-008):', JSON.stringify(snapM4Inc, null, 2));
  console.log('Expense Document (V-2026-006):', JSON.stringify(snapM4Exp, null, 2));
  console.log('Operation Document:', JSON.stringify(snapM4Op, null, 2));
  console.log('Audit Log Document:', JSON.stringify(snapM4Audit, null, 2));

  console.log('\n========================================================================');
  console.log('ALL SNAPSHOTS SUCCESSFULLY CAPTURED AND VERIFIED INTERNALLY CONSISTENT');
  console.log('========================================================================');
}

main()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error('Error capturing snapshots:', err);
    process.exit(1);
  });
