/**
 * Real Firebase Client SDK Transaction Test against Firestore Emulator
 * Manjankal Mar Shemavoon Desthuni Orthodox Syrian Church - 2026 Festival Accounts
 */

import { initializeApp } from 'firebase/app';
import { getAuth, connectAuthEmulator, signInWithCustomToken } from 'firebase/auth';
import {
  getFirestore,
  connectFirestoreEmulator,
  runTransaction,
  doc,
  getDoc,
  setDoc,
} from 'firebase/firestore';
import { initializeApp as initAdmin, getApps as getAdminApps } from 'firebase-admin/app';
import { getAuth as getAdminAuth } from 'firebase-admin/auth';

if (getAdminApps().length === 0) {
  initAdmin({ projectId: 'demo-church' });
}

async function runTest() {
  console.log('--- Minting Super Admin Credentials in Auth Emulator ---');
  const adminAuth = getAdminAuth();
  try {
    await adminAuth.createUser({
      uid: 'admin-uid',
      email: 'jijopjohn@gmail.com',
      emailVerified: true,
    });
  } catch {
    // User already exists
  }

  const customToken = await adminAuth.createCustomToken('admin-uid', {
    email: 'jijopjohn@gmail.com',
    email_verified: true,
  });

  console.log('--- Initializing Firebase Web Client SDK ---');
  const clientApp = initializeApp({
    apiKey: 'fake-api-key',
    projectId: 'demo-church',
  });
  const clientAuth = getAuth(clientApp);
  connectAuthEmulator(clientAuth, 'http://127.0.0.1:9099', { disableWarnings: true });

  const clientDb = getFirestore(clientApp);
  connectFirestoreEmulator(clientDb, '127.0.0.1', 8088);

  const userCred = await signInWithCustomToken(clientAuth, customToken);
  console.log('Signed in as verified Super Admin:', userCred.user.email);

  // Seed Heading
  const headingRef = doc(clientDb, 'festivals/2026/headings/h-1');
  await setDoc(headingRef, {
    id: 'h-1',
    name: 'നേർച്ച',
    type: 'INCOME',
    createdAt: '2026-11-22T08:00:00Z',
  });
  console.log('[PASS] Created Heading using real Firebase Client SDK');

  // Seed Sequence Document (Bootstrap)
  const seqRef = doc(clientDb, 'festivals/2026/sequences/accounting');
  await setDoc(seqRef, {
    yearId: '2026',
    lastReceiptSeq: 0,
    lastVoucherSeq: 0,
    lastOperationId: '00000000-0000-4000-8000-000000000000',
    status: 'INITIALIZED_EMPTY',
    createdAt: '2026-11-22T08:00:00Z',
  });
  console.log('[PASS] Initialized Sequence Counter using real Firebase Client SDK');

  console.log('--- Executing Real runTransaction() via Client SDK ---');
  const opId = 'a1111111-1111-4111-8111-111111111111';
  const incId = 'b2222222-2222-4222-8222-222222222222';
  const auditId = `audit_${opId}`;

  const opRef = doc(clientDb, `festivals/2026/operations/${opId}`);
  const incRef = doc(clientDb, `festivals/2026/incomes/${incId}`);
  const auditRef = doc(clientDb, `festivals/2026/audit_logs/${auditId}`);

  // Canonical payload hash
  const payloadHash = '64315dac7bab0cf8031b49d7109fc4a5c79868894d909633e9abbce729d8cf81';
  const nowIso = '2026-11-25T10:00:00Z';

  const txResult = await runTransaction(clientDb, async (transaction) => {
    // 1. Reads
    const opSnap = await transaction.get(opRef);
    if (opSnap.exists()) {
      return { status: 'ALREADY_COMMITTED', receiptNumber: opSnap.data().allocatedNumber };
    }

    const seqSnap = await transaction.get(seqRef);
    if (!seqSnap.exists()) throw new Error('SEQ_NOT_FOUND');
    const currentSeq = seqSnap.data();

    const headSnap = await transaction.get(headingRef);
    if (!headSnap.exists()) throw new Error('HEAD_NOT_FOUND');

    const nextSeq = currentSeq.lastReceiptSeq + 1;
    const receiptNumber = 'R-2026-001';

    // 2. Writes
    transaction.update(seqRef, {
      lastReceiptSeq: nextSeq,
      lastOperationId: opId,
      updatedAt: nowIso,
    });

    transaction.set(opRef, {
      operationId: opId,
      type: 'INCOME',
      entityId: incId,
      seqNumber: nextSeq,
      allocatedNumber: receiptNumber,
      payloadHash,
      userEmail: 'jijopjohn@gmail.com',
      createdAt: nowIso,
    });

    transaction.set(incRef, {
      id: incId,
      receiptNumber,
      seqNumber: nextSeq,
      operationId: opId,
      payloadHash,
      date: '2026-11-25',
      headingId: 'h-1',
      headingName: 'നേർച്ച',
      amount: 1000,
      paymentMode: 'CASH',
      description: 'നേർച്ച സമർപ്പണം',
      createdAt: nowIso,
    });

    transaction.set(auditRef, {
      id: auditId,
      operationId: opId,
      entityId: incId,
      entityType: 'INCOME',
      action: 'ADD_INCOME',
      summaryMl: 'രസീത് R-2026-001 ചേർത്തു',
      amount: 1000,
      userEmail: 'jijopjohn@gmail.com',
      timestamp: nowIso,
    });

    return { status: 'COMMITTED_NEW', receiptNumber };
  });

  console.log('[PASS] runTransaction completed successfully with result:', txResult);

  // Read back documents from the Emulator to verify persistence
  const savedInc = await getDoc(incRef);
  const savedSeq = await getDoc(seqRef);
  const savedOp = await getDoc(opRef);
  const savedAudit = await getDoc(auditRef);

  console.log('[PASS] Stored Document Snapshot from Real Emulator:');
  console.log('  Income Doc:', JSON.stringify(savedInc.data()));
  console.log('  Sequence Counter:', JSON.stringify(savedSeq.data()));
  console.log('  Operation Doc:', JSON.stringify(savedOp.data()));
  console.log('  Audit Log:', JSON.stringify(savedAudit.data()));
}

runTest().then(() => {
  console.log('=== REAL CLIENT SDK TRANSACTION TEST PASSED ===');
  process.exit(0);
}).catch((err) => {
  console.error('Test Failed:', err);
  process.exit(1);
});
