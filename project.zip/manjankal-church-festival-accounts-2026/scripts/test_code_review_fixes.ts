import assert from 'node:assert';
import { numberToMalayalamWords, formatINR } from '../src/utils/numberToMalayalamWords';

console.log('--- TESTING THE 6 APPROVED CODE REVIEW FIXES ---\n');

// -------------------------------------------------------------
// Test 1: numberToMalayalamWords & Whole-Rupee Amount Handling
// -------------------------------------------------------------
console.log('Test 1: Whole-rupee conversion & Malayalam words without silent truncation:');
assert.strictEqual(numberToMalayalamWords(0), 'പൂജ്യം രൂപ മാത്രം');
assert.strictEqual(numberToMalayalamWords(500), 'അഞ്ഞൂറ് രൂപ മാത്രം');
assert.strictEqual(numberToMalayalamWords(15000), 'പതിനഞ്ച് ആയിരം രൂപ മാത്രം');
assert.strictEqual(numberToMalayalamWords(250000), 'രണ്ട് ലക്ഷം അൻപത് ആയിരം രൂപ മാത്രം');

// Decimal test: Explicit paise conversion rather than silent dropping
const withPaise = numberToMalayalamWords(500.50);
assert(withPaise.includes('പൈസ'), `Expected Malayalam words for 500.50 to explicitly note paise, got: ${withPaise}`);
console.log('✓ Whole-rupee conversion & explicit paise representation verified: ' + withPaise);

// -------------------------------------------------------------
// Test 2: Duplicate Receipt Number Prevention Logic
// -------------------------------------------------------------
console.log('\nTest 2: Duplicate receipt number prevention within festival year:');
const existingIncomes = [
  { id: 'inc-1', receiptNumber: 'R-2026-001', amount: 1000 },
  { id: 'inc-2', receiptNumber: 'R-2026-002', amount: 2500 },
];

function checkDuplicateReceipt(newReceiptNo: string, editingId?: string): boolean {
  const trimmed = newReceiptNo.trim().toLowerCase();
  return existingIncomes.some(
    (i) => i.id !== editingId && i.receiptNumber.trim().toLowerCase() === trimmed
  );
}

assert.strictEqual(checkDuplicateReceipt('R-2026-001'), true, 'Should detect duplicate receipt number');
assert.strictEqual(checkDuplicateReceipt('  r-2026-001  '), true, 'Should detect case/whitespace duplicate');
assert.strictEqual(checkDuplicateReceipt('R-2026-001', 'inc-1'), false, 'Should allow editing existing record with its own receipt number');
assert.strictEqual(checkDuplicateReceipt('R-2026-003'), false, 'Should allow new unique receipt number');
console.log('✓ Duplicate receipt detection correctly enforces uniqueness per year');

// -------------------------------------------------------------
// Test 3: Duplicate Voucher Number Prevention Logic
// -------------------------------------------------------------
console.log('\nTest 3: Duplicate voucher number prevention within festival year:');
const existingExpenses = [
  { id: 'exp-1', voucherNumber: 'V-2026-001', amount: 5000 },
  { id: 'exp-2', voucherNumber: 'V-2026-002', amount: 12000 },
];

function checkDuplicateVoucher(newVoucherNo: string, editingId?: string): boolean {
  const trimmed = newVoucherNo.trim().toLowerCase();
  return existingExpenses.some(
    (e) => e.id !== editingId && e.voucherNumber.trim().toLowerCase() === trimmed
  );
}

assert.strictEqual(checkDuplicateVoucher('V-2026-001'), true, 'Should detect duplicate voucher number');
assert.strictEqual(checkDuplicateVoucher('  v-2026-002  '), true, 'Should detect case/whitespace duplicate');
assert.strictEqual(checkDuplicateVoucher('V-2026-002', 'exp-2'), false, 'Should allow editing existing record with its own voucher number');
assert.strictEqual(checkDuplicateVoucher('V-2026-003'), false, 'Should allow new unique voucher number');
console.log('✓ Duplicate voucher detection correctly enforces uniqueness per year');

// -------------------------------------------------------------
// Test 4: SummaryCards Uncategorized Breakdown Reconciliation
// -------------------------------------------------------------
console.log('\nTest 4: SummaryCards item-wise breakdown reconciliation with uncategorized transactions:');
const activeHeadings = [
  { id: 'h-1', name: 'നേർച്ച പിരിവ്', type: 'INCOME' },
  { id: 'h-2', name: 'ലേലം', type: 'INCOME' },
];

const sampleIncomes = [
  { id: 'inc-1', headingId: 'h-1', headingName: 'നേർച്ച പിരിവ്', amount: 10000 },
  { id: 'inc-2', headingId: 'h-2', headingName: 'ലേലം', amount: 5000 },
  { id: 'inc-3', headingId: 'deleted-h-99', headingName: 'പഴയ ശീർഷകം', amount: 3000 }, // Uncategorized!
];

const grandTotalIncome = sampleIncomes.reduce((s, i) => s + i.amount, 0); // 18000

// Computation matching SummaryCards.tsx
const incomeList: { headingName: string; total: number; count: number }[] = activeHeadings.map((h) => {
  const matching = sampleIncomes.filter((i) => i.headingId === h.id || i.headingName === h.name);
  return {
    headingName: h.name,
    total: matching.reduce((s, i) => s + i.amount, 0),
    count: matching.length,
  };
});

const uncategorizedIncomes = sampleIncomes.filter(
  (i) => !activeHeadings.some((h) => h.id === i.headingId || h.name === i.headingName)
);
if (uncategorizedIncomes.length > 0) {
  incomeList.push({
    headingName: 'മറ്റ് വരവുകൾ / ശീർഷകം ഇല്ലാത്തവ (Uncategorized)',
    total: uncategorizedIncomes.reduce((s, i) => s + i.amount, 0),
    count: uncategorizedIncomes.length,
  });
}

const breakdownSum = incomeList.reduce((s, item) => s + item.total, 0);
assert.strictEqual(breakdownSum, grandTotalIncome, 'Breakdown sum must equal grandTotalIncome 100%');
assert.strictEqual(breakdownSum, 18000);
console.log(`✓ Reconciliation verified: Top grand total (${grandTotalIncome}) === Breakdown sum (${breakdownSum})`);

// -------------------------------------------------------------
// Test 5: Whole-Rupee Input Validation Guard
// -------------------------------------------------------------
console.log('\nTest 5: Whole-rupee input validation check:');
function validateAmountInput(amountStr: string): { valid: boolean; error?: string } {
  const parsed = Number(amountStr);
  if (isNaN(parsed) || !Number.isInteger(parsed) || parsed <= 0) {
    return {
      valid: false,
      error: 'തുക പൂർണ്ണ രൂപയിൽ (Whole Rupees) നൽകുക. പൈസ അനുവദനീയമല്ല (ഉദാ: ₹500).',
    };
  }
  return { valid: true };
}

assert.strictEqual(validateAmountInput('500').valid, true);
assert.strictEqual(validateAmountInput('500.50').valid, false);
assert.strictEqual(validateAmountInput('0').valid, false);
assert.strictEqual(validateAmountInput('-100').valid, false);
assert.strictEqual(validateAmountInput('abc').valid, false);
console.log('✓ Whole-rupee validation rejects decimals, negative numbers, and non-integers');

// -------------------------------------------------------------
// Test 6: Audit Logger Token Guard
// -------------------------------------------------------------
console.log('\nTest 6: Audit logger token guard in pre-provisioning offline mode:');
function shouldSendHttpAudit(token?: string): boolean {
  return Boolean(token && !token.startsWith('sa_'));
}

assert.strictEqual(shouldSendHttpAudit(undefined), false, 'No token -> retain locally only');
assert.strictEqual(shouldSendHttpAudit('sa_12345_local'), false, 'Offline PIN token -> retain locally only (no misleading 401)');
assert.strictEqual(shouldSendHttpAudit('eyJhbGciOi...genuine_firebase_id_token'), true, 'Genuine Firebase ID token -> send via Authorization: Bearer');
console.log('✓ Audit logger safely avoids firing unauthenticated requests prior to Firebase provisioning');

console.log('\n=========================================');
console.log('ALL 6 CODE REVIEW FINDINGS TESTS PASSED! ');
console.log('=========================================');
