/**
 * Concurrent Transaction Submission & Duplicate Operation ID Stress Test
 * Manjankal Mar Shemavoon Desthuni Orthodox Syrian Church - 2026 Festival Accounts
 */

import crypto from 'crypto';
import {
  canonicalizeIncomePayload,
  computePayloadFingerprint,
  formatReceiptNumber
} from '../src/utils/payloadNormalization';

class TransactionalDatabaseSimulator {
  private db: Map<string, any> = new Map();
  private lock: Promise<void> = Promise.resolve();

  constructor() {
    this.db.set('festivals/2026/sequences/accounting', {
      yearId: '2026',
      lastReceiptSeq: 0,
      lastVoucherSeq: 0,
      status: 'ACTIVE'
    });
    this.db.set('festivals/2026/headings/h-1', {
      id: 'h-1',
      name: 'നേർച്ച',
      type: 'INCOME'
    });
  }

  async runTransaction<T>(updateFunction: (tx: TransactionContext) => Promise<T>): Promise<T> {
    const prevLock = this.lock;
    let release: () => void;
    this.lock = new Promise<void>((r) => { release = r; });
    await prevLock;

    try {
      const tx = new TransactionContext(this.db);
      const res = await updateFunction(tx);
      tx.commit();
      return res;
    } finally {
      release!();
    }
  }

  getDoc(path: string) {
    return this.db.get(path);
  }

  getAllDocs() {
    return Object.fromEntries(this.db.entries());
  }
}

class TransactionContext {
  private writes: Map<string, any> = new Map();

  constructor(private sharedDb: Map<string, any>) {}

  async get(path: string) {
    return this.sharedDb.get(path) ? JSON.parse(JSON.stringify(this.sharedDb.get(path))) : null;
  }

  set(path: string, data: any) {
    this.writes.set(path, JSON.parse(JSON.stringify(data)));
  }

  update(path: string, updates: any) {
    const existing = this.sharedDb.get(path);
    if (!existing) throw new Error(`Document ${path} not found`);
    this.writes.set(path, { ...existing, ...JSON.parse(JSON.stringify(updates)) });
  }

  commit() {
    for (const [k, v] of this.writes.entries()) {
      this.sharedDb.set(k, v);
    }
  }
}

async function allocateIncome(
  dbSim: TransactionalDatabaseSimulator,
  operationId: string,
  amount: number,
  donorName: string
) {
  const payload = {
    amount,
    date: '2026-11-25',
    headingId: 'h-1',
    description: 'നേർച്ച സമർപ്പണം',
    paymentMode: 'CASH' as const,
    donorName
  };
  const canonical = canonicalizeIncomePayload(payload);
  const payloadHash = await computePayloadFingerprint(canonical);

  const opPath = `festivals/2026/operations/${operationId}`;
  const seqPath = 'festivals/2026/sequences/accounting';

  return await dbSim.runTransaction(async (tx) => {
    // 1. Reads
    const existingOp = await tx.get(opPath);
    if (existingOp) {
      if (existingOp.payloadHash === payloadHash) {
        return {
          status: 'ALREADY_COMMITTED',
          receiptNumber: existingOp.allocatedNumber,
          seqNumber: existingOp.seqNumber
        };
      } else {
        throw new Error('IDEMPOTENCY_CONFLICT');
      }
    }

    const seqDoc = await tx.get(seqPath);
    const nextSeq = seqDoc.lastReceiptSeq + 1;
    const receiptNumber = formatReceiptNumber(nextSeq, '2026');
    const incomeId = crypto.randomUUID();

    // 2. Writes
    tx.update(seqPath, {
      lastReceiptSeq: nextSeq,
      lastOperationId: operationId
    });

    tx.set(opPath, {
      operationId,
      type: 'INCOME',
      entityId: incomeId,
      seqNumber: nextSeq,
      allocatedNumber: receiptNumber,
      payloadHash,
      createdAt: new Date().toISOString()
    });

    tx.set(`festivals/2026/incomes/${incomeId}`, {
      id: incomeId,
      receiptNumber,
      seqNumber: nextSeq,
      amount,
      donorName
    });

    tx.set(`festivals/2026/audit_logs/audit_${operationId}`, {
      id: `audit_${operationId}`,
      operationId,
      entityId: incomeId,
      action: 'ADD_INCOME'
    });

    return {
      status: 'COMMITTED_NEW',
      receiptNumber,
      seqNumber: nextSeq
    };
  });
}

async function runTest() {
  console.log('=== RUNNING CONCURRENT TRANSACTION STRESS TEST ===');
  const db = new TransactionalDatabaseSimulator();

  // Test 1: 5 Concurrent requests with DIFFERENT operationIds
  console.log('Dispatching 5 concurrent transactions with distinct operationIds...');
  const promises = Array.from({ length: 5 }).map((_, i) => {
    const opId = crypto.randomUUID();
    return allocateIncome(db, opId, 1000 * (i + 1), `Donor #${i + 1}`);
  });

  const results = await Promise.all(promises);
  console.table(results);

  const finalSeq = db.getDoc('festivals/2026/sequences/accounting').lastReceiptSeq;
  console.log(`Final Counter Sequence: ${finalSeq} (Expected: 5)`);
  if (finalSeq === 5) {
    console.log('[PASS] All 5 concurrent transactions serialized properly without gaps or duplicates');
  } else {
    console.error('[FAIL] Concurrency race condition detected');
    process.exit(1);
  }

  // Test 2: 5 Concurrent requests with the SAME operationId (Duplicate Submission Attack)
  console.log('\nDispatching 5 simultaneous requests with the SAME operationId...');
  const sharedOpId = crypto.randomUUID();
  const dupPromises = Array.from({ length: 5 }).map(() => {
    return allocateIncome(db, sharedOpId, 500, 'Duplicate Attacker');
  });

  const dupResults = await Promise.all(dupPromises);
  console.table(dupResults);

  const committedNewCount = dupResults.filter(r => r.status === 'COMMITTED_NEW').length;
  const alreadyCommittedCount = dupResults.filter(r => r.status === 'ALREADY_COMMITTED').length;
  const newFinalSeq = db.getDoc('festivals/2026/sequences/accounting').lastReceiptSeq;

  console.log(`Committed New: ${committedNewCount} (Expected: 1)`);
  console.log(`Already Committed: ${alreadyCommittedCount} (Expected: 4)`);
  console.log(`Final Counter Sequence: ${newFinalSeq} (Expected: 6)`);

  if (committedNewCount === 1 && alreadyCommittedCount === 4 && newFinalSeq === 6) {
    console.log('[PASS] Exact single-commit idempotency verified under simultaneous duplicate submissions');
  } else {
    console.error('[FAIL] Duplicate operationId was not properly serialized');
    process.exit(1);
  }

  console.log('\n=== ALL CONCURRENCY TESTS PASSED (EXIT CODE 0) ===');
}

runTest().catch((err) => {
  console.error('Fatal concurrency test failure:', err);
  process.exit(1);
});
