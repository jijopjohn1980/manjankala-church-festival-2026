/**
 * Formal Firestore Security Rules Test Suite using @firebase/rules-unit-testing
 * 
 * Target: /firestore.rules
 * Purpose: Verifies Zero-Trust Default Deny, Sole Super Admin RBAC, and Backend-Only Audit Logs.
 */

import {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
  RulesTestEnvironment,
} from '@firebase/rules-unit-testing';
import fs from 'fs';
import path from 'path';

const PROJECT_ID = 'manjakala-church-festival-test';
const RULES_PATH = path.resolve(__dirname, '../firestore.rules');

describe('Manjankal Church Festival Accounting - Firestore Security Rules Test Suite', () => {
  let testEnv: RulesTestEnvironment;

  beforeAll(async () => {
    const rules = fs.readFileSync(RULES_PATH, 'utf8');
    testEnv = await initializeTestEnvironment({
      projectId: PROJECT_ID,
      firestore: {
        rules,
        host: '127.0.0.1',
        port: 8080,
      },
    });
  });

  afterAll(async () => {
    await testEnv.cleanup();
  });

  afterEach(async () => {
    await testEnv.clearFirestore();
  });

  // ---------------------------------------------------------------------------
  // 1. DEFAULT-DENY & UNAUTHENTICATED ACCESS
  // ---------------------------------------------------------------------------
  test('T1: Unauthenticated visitors are DENIED read and write on all collections', async () => {
    const unauth = testEnv.unauthenticatedContext();
    const db = unauth.firestore();

    await assertFails(db.collection('festival_years').doc('2026').get());
    await assertFails(db.collection('festival_years').doc('2026').collection('incomes').get());
    await assertFails(db.collection('festival_years').doc('2026').collection('expenses').get());
    await assertFails(db.collection('authorized_users').doc('any-uid').get());
    await assertFails(db.collection('audit_logs').get());
  });

  // ---------------------------------------------------------------------------
  // 2. UNAUTHORIZED GOOGLE ACCOUNT ACCESS
  // ---------------------------------------------------------------------------
  test('T2: Unauthorized Google user (not jijopjohn@gmail.com) is DENIED access', async () => {
    const hacker = testEnv.authenticatedContext('hacker-uid', {
      email: 'hacker@gmail.com',
      email_verified: true,
    });
    const db = hacker.firestore();

    await assertFails(db.collection('festival_years').doc('2026').collection('incomes').get());
    await assertFails(
      db.collection('festival_years').doc('2026').collection('expenses').add({
        id: 'exp-1',
        voucherNumber: 'V-001',
        amount: 1000,
      })
    );
  });

  // ---------------------------------------------------------------------------
  // 3. UNVERIFIED EMAIL SPOOFING DEFENSE
  // ---------------------------------------------------------------------------
  test('T3: Attempt to access with email jijopjohn@gmail.com but email_verified: false is DENIED', async () => {
    const spoof = testEnv.authenticatedContext('spoof-uid', {
      email: 'jijopjohn@gmail.com',
      email_verified: false, // Spoofed / unverified
    });
    const db = spoof.firestore();

    await assertFails(db.collection('festival_years').doc('2026').collection('incomes').get());
    await assertFails(db.collection('authorized_users').doc('spoof-uid').get());
  });

  // ---------------------------------------------------------------------------
  // 4. AUTHORIZED USERS BOOTSTRAP & SOLE SUPER ADMIN ROLE
  // ---------------------------------------------------------------------------
  test('T4: Sole Super Admin can bootstrap own record, but cannot delete or edit it', async () => {
    const saUid = 'sa-google-uid-12345';
    const saContext = testEnv.authenticatedContext(saUid, {
      email: 'jijopjohn@gmail.com',
      email_verified: true,
    });
    const db = saContext.firestore();

    // Bootstrap creation of authorized_users document
    await assertSucceeds(
      db.collection('authorized_users').doc(saUid).set({
        uid: saUid,
        email: 'jijopjohn@gmail.com',
        role: 'SUPER_ADMIN',
        createdAt: new Date(), // Server timestamp in rules
      })
    );

    // Deletion is strictly forbidden
    await assertFails(db.collection('authorized_users').doc(saUid).delete());

    // Role escalation / update is strictly forbidden
    await assertFails(
      db.collection('authorized_users').doc(saUid).update({
        role: 'OTHER_ROLE',
      })
    );
  });

  // ---------------------------------------------------------------------------
  // 5. CLIENT AUDIT LOGS MUTATION DENIAL (BACKEND ONLY)
  // ---------------------------------------------------------------------------
  test('T5: Super Admin client is DENIED direct creation, update or deletion of audit logs', async () => {
    const saUid = 'sa-google-uid-12345';
    const saContext = testEnv.authenticatedContext(saUid, {
      email: 'jijopjohn@gmail.com',
      email_verified: true,
    });
    const db = saContext.firestore();

    // Direct client create is forbidden
    await assertFails(
      db.collection('audit_logs').doc('client-log-1').set({
        id: 'client-log-1',
        action: 'FORGED_AUDIT',
        summaryMl: 'ഫേക്ക് ലോഗ്',
      })
    );

    // Direct client update is forbidden
    await assertFails(
      db.collection('audit_logs').doc('existing-log').update({
        summaryMl: 'തിരുത്തിയ വിവരണം',
      })
    );

    // Direct client delete is forbidden
    await assertFails(db.collection('audit_logs').doc('existing-log').delete());
  });

  // ---------------------------------------------------------------------------
  // 6. FESTIVAL YEAR DATA DELETION PROTECTION
  // ---------------------------------------------------------------------------
  test('T6: Deletion of the festival accounting period (/festival_years/2026) is DENIED', async () => {
    const saUid = 'sa-google-uid-12345';
    const saContext = testEnv.authenticatedContext(saUid, {
      email: 'jijopjohn@gmail.com',
      email_verified: true,
    });
    const db = saContext.firestore();

    // Deletion of root festival year is blocked
    await assertFails(db.collection('festival_years').doc('2026').delete());
  });
});
