import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { initializeApp, getApps } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const SUPER_ADMIN_EMAIL = 'jijopjohn@gmail.com';

// Resolve Firebase Project ID strictly from environment configuration or official provisioning config (ZERO hardcoded fallbacks)
function resolveFirebaseProjectId(): string | undefined {
  if (process.env.FIREBASE_PROJECT_ID && process.env.FIREBASE_PROJECT_ID.trim()) {
    return process.env.FIREBASE_PROJECT_ID.trim();
  }
  if (process.env.GCLOUD_PROJECT && process.env.GCLOUD_PROJECT.trim()) {
    return process.env.GCLOUD_PROJECT.trim();
  }
  try {
    const configPath = path.join(__dirname, 'firebase-applet-config.json');
    if (fs.existsSync(configPath)) {
      const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
      if (typeof config.projectId === 'string' && config.projectId.trim().length > 0) {
        return config.projectId.trim();
      }
    }
  } catch {
    // Config unreadable or missing
  }
  return undefined;
}

const FIREBASE_PROJECT_ID = resolveFirebaseProjectId();

// Mandatory strict fail-safe: Fail server startup in production if verified project ID is missing
if (process.env.NODE_ENV === 'production' && !FIREBASE_PROJECT_ID) {
  throw new Error(
    'FATAL CONFIGURATION ERROR: Missing verified FIREBASE_PROJECT_ID or GCLOUD_PROJECT in environment. Server startup aborted to prevent unauthenticated execution.'
  );
}

app.use(express.json({ limit: '1mb' }));

// Initialize Firebase Admin SDK strictly using verified environment project ID and Application Default Credentials (ADC)
if (getApps().length === 0 && FIREBASE_PROJECT_ID) {
  try {
    initializeApp({
      projectId: FIREBASE_PROJECT_ID,
    });
    console.log(`Firebase Admin SDK initialized using ADC for verified project: ${FIREBASE_PROJECT_ID}`);
  } catch (err) {
    console.warn('Firebase Admin SDK initialization notice:', err);
  }
} else if (!FIREBASE_PROJECT_ID) {
  console.warn('NOTICE: Pre-provisioning development mode active. Cloud Firebase initialization is paused awaiting database provisioning approval.');
}

export interface AuthenticatedSuperAdmin {
  uid: string;
  email: string;
  emailVerified: boolean;
}

declare global {
  namespace Express {
    interface Request {
      superAdmin?: AuthenticatedSuperAdmin;
    }
  }
}

// Strict Allowlist of Audit Actions
const ALLOWED_AUDIT_ACTIONS = new Set([
  'LOGIN',
  'LOGOUT',
  'ADD_HEADING',
  'EDIT_HEADING',
  'DELETE_HEADING',
  'ADD_INCOME',
  'EDIT_INCOME',
  'DELETE_INCOME',
  'ADD_EXPENSE',
  'EDIT_EXPENSE',
  'DELETE_EXPENSE',
  'BACKUP_EXPORT',
  'BACKUP_RESTORE',
  'CHANGE_PIN',
]);

/**
 * 1. SECURE SUPER ADMIN AUTHENTICATION & AUTHORIZATION MIDDLEWARE
 * 
 * Strict Zero-Trust Rules:
 * - NO trust in any client-supplied custom headers.
 * - Requires Authorization: Bearer <FIREBASE_ID_TOKEN>.
 * - ONLY verifies tokens using Firebase Admin SDK verifyIdToken() with strict audience/issuer checks.
 * - Enforces email === 'jijopjohn@gmail.com' and email_verified === true.
 * - FAILS CLOSED (HTTP 403) if /authorized_users/{uid} does not exist or role != SUPER_ADMIN.
 * - FAILS CLOSED (HTTP 403) on any database lookup error.
 */
export async function requireSuperAdminAuth(
  req: express.Request,
  res: express.Response,
  next: express.NextFunction
) {
  const authHeader = req.headers.authorization;

  // 1. Mandatory Bearer Token Header Check
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      error: 'UNAUTHORIZED',
      message: 'Authentication failed: Missing or malformed Bearer Authorization header.',
    });
  }

  const idToken = authHeader.split('Bearer ')[1]?.trim();
  if (!idToken) {
    return res.status(401).json({
      error: 'UNAUTHORIZED',
      message: 'Authentication failed: Empty Bearer token.',
    });
  }

  try {
    // 2. Strict Firebase Admin SDK Token Verification
    const auth = getAuth();
    const decoded = await auth.verifyIdToken(idToken, true);

    const verifiedEmail = decoded.email;
    const isEmailVerified = decoded.email_verified === true;
    const firebaseUid = decoded.uid; // Actual authoritative Firebase User UID

    // 3. Strict Email Authorization
    if (!verifiedEmail || verifiedEmail.toLowerCase() !== SUPER_ADMIN_EMAIL.toLowerCase()) {
      return res.status(403).json({
        error: 'FORBIDDEN',
        message: `Authorization failed: Token email (${verifiedEmail}) is not the authorized Super Admin.`,
      });
    }

    // 4. Strict Email Verification Flag Check
    if (!isEmailVerified) {
      return res.status(403).json({
        error: 'EMAIL_NOT_VERIFIED',
        message: 'Authorization failed: Google account email is not verified.',
      });
    }

    // 5. Mandatory Database Authorization Check (FAILS CLOSED)
    try {
      const db = getFirestore();
      const userDoc = await db.collection('authorized_users').doc(firebaseUid).get();

      if (!userDoc.exists) {
        return res.status(403).json({
          error: 'UNAUTHORIZED_USER',
          message: 'Authorization failed: No authorized_users record found for this UID. Access denied.',
        });
      }

      const userData = userDoc.data();
      if (userData?.role !== 'SUPER_ADMIN' || userData?.email !== SUPER_ADMIN_EMAIL) {
        return res.status(403).json({
          error: 'ROLE_REVOKED',
          message: 'Authorization failed: User does not possess active SUPER_ADMIN role.',
        });
      }
    } catch (dbErr: any) {
      // FAILS CLOSED ON ANY FIRESTORE ERROR
      return res.status(403).json({
        error: 'DATABASE_AUTHORIZATION_FAILED',
        message: 'Authorization failed: Unable to verify database authorization record. Access denied.',
      });
    }

    req.superAdmin = {
      uid: firebaseUid,
      email: verifiedEmail,
      emailVerified: isEmailVerified,
    };

    next();
  } catch (err: any) {
    return res.status(401).json({
      error: 'INVALID_TOKEN',
      message: err.message || 'Authentication failed: Cryptographic signature verification failed or token expired.',
    });
  }
}

/**
 * 2. ATOMIC FIRST-TIME BOOTSTRAP ENDPOINT (POST /api/auth/bootstrap)
 * 
 * Uses an atomic Firestore transaction to prevent race conditions or duplicate bootstrap records.
 */
app.post('/api/auth/bootstrap', async (req, res) => {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      error: 'UNAUTHORIZED',
      message: 'Bootstrap failed: Missing or malformed Bearer Authorization header.',
    });
  }

  const idToken = authHeader.split('Bearer ')[1]?.trim();
  if (!idToken) {
    return res.status(401).json({
      error: 'UNAUTHORIZED',
      message: 'Bootstrap failed: Empty Bearer token.',
    });
  }

  try {
    const auth = getAuth();
    const decoded = await auth.verifyIdToken(idToken, true);

    if (!decoded.email || decoded.email.toLowerCase() !== SUPER_ADMIN_EMAIL.toLowerCase()) {
      return res.status(403).json({
        error: 'FORBIDDEN',
        message: 'Bootstrap failed: Only jijopjohn@gmail.com can initialize Super Admin.',
      });
    }

    if (decoded.email_verified !== true) {
      return res.status(403).json({
        error: 'EMAIL_NOT_VERIFIED',
        message: 'Bootstrap failed: Email must be verified by Google.',
      });
    }

    const db = getFirestore();

    // ATOMIC TRANSACTION: Guarantees serialized execution and prevents race conditions
    let bootstrappedRecord: any;
    try {
      await db.runTransaction(async (transaction) => {
        // Read inside transaction
        const existingUsersQuery = db.collection('authorized_users').limit(1);
        const existingSnapshot = await transaction.get(existingUsersQuery);

        if (!existingSnapshot.empty) {
          throw new Error('ALREADY_INITIALIZED');
        }

        const newAdminRef = db.collection('authorized_users').doc(decoded.uid);
        bootstrappedRecord = {
          uid: decoded.uid,
          email: SUPER_ADMIN_EMAIL,
          role: 'SUPER_ADMIN',
          createdAt: FieldValue.serverTimestamp(),
        };

        transaction.set(newAdminRef, bootstrappedRecord);
      });

      return res.status(201).json({
        success: true,
        message: 'Super Admin authorization successfully established atomically.',
        uid: decoded.uid,
        email: SUPER_ADMIN_EMAIL,
      });
    } catch (txErr: any) {
      if (txErr.message === 'ALREADY_INITIALIZED') {
        return res.status(409).json({
          error: 'ALREADY_INITIALIZED',
          message: 'Bootstrap failed: Super Admin has already been initialized. Bootstrap is closed.',
        });
      }
      throw txErr;
    }
  } catch (err: any) {
    return res.status(401).json({
      error: 'BOOTSTRAP_TOKEN_FAILED',
      message: err.message || 'Token verification failed during bootstrap.',
    });
  }
});

/**
 * 3. DURABLE SERVER-SIDE AUDIT LOGGING (POST /api/audit)
 * Protected by requireSuperAdminAuth
 */
app.post('/api/audit', requireSuperAdminAuth, async (req, res) => {
  const { action, summaryMl, amount, details } = req.body;

  // 1. Validate action against explicit allowlist
  if (!action || typeof action !== 'string' || !ALLOWED_AUDIT_ACTIONS.has(action)) {
    return res.status(400).json({
      error: 'INVALID_ACTION',
      message: `Invalid action. Must be one of: ${Array.from(ALLOWED_AUDIT_ACTIONS).join(', ')}`,
    });
  }

  // 2. Validate summaryMl (type and length: 1 to 500 characters)
  if (!summaryMl || typeof summaryMl !== 'string' || summaryMl.trim().length === 0 || summaryMl.length > 500) {
    return res.status(400).json({
      error: 'INVALID_SUMMARY',
      message: 'summaryMl must be a non-empty string between 1 and 500 characters.',
    });
  }

  // 3. Validate amount (if provided, must be finite non-negative number)
  let validatedAmount: number | null = null;
  if (amount !== undefined && amount !== null) {
    if (typeof amount !== 'number' || !Number.isFinite(amount) || amount < 0 || amount > 100000000) {
      return res.status(400).json({
        error: 'INVALID_AMOUNT',
        message: 'Amount must be a non-negative finite number up to 100,000,000.',
      });
    }
    validatedAmount = amount;
  }

  // 4. Validate details (if provided, must be a plain object under 4KB)
  let validatedDetails: Record<string, any> = {};
  if (details !== undefined && details !== null) {
    if (typeof details !== 'object' || Array.isArray(details)) {
      return res.status(400).json({
        error: 'INVALID_DETAILS',
        message: 'Details must be a plain object.',
      });
    }
    const detailsJson = JSON.stringify(details);
    if (detailsJson.length > 4096) {
      return res.status(400).json({
        error: 'DETAILS_TOO_LARGE',
        message: 'Details payload exceeds maximum allowed size (4KB).',
      });
    }
    validatedDetails = details;
  }

  // 5. Construct log: SERVER-ENFORCED IDENTITY & SERVER TIMESTAMP (Never client-supplied!)
  const logEntry = {
    id: `audit-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    userUid: req.superAdmin!.uid, // Authoritative Firebase UID from verified token
    userEmail: req.superAdmin!.email, // Authoritative email from verified token
    action,
    summaryMl: summaryMl.trim(),
    amount: validatedAmount,
    details: validatedDetails,
    serverIp: req.ip,
    createdAt: FieldValue.serverTimestamp(), // Authoritative server timestamp
  };

  try {
    const db = getFirestore();
    await db.collection('audit_logs').doc(logEntry.id).set(logEntry);
    return res.status(201).json({ success: true, logId: logEntry.id });
  } catch (dbErr: any) {
    return res.status(500).json({
      error: 'AUDIT_PERSISTENCE_FAILED',
      message: 'Failed to durably write audit log to Firestore database.',
    });
  }
});

/**
 * 4. AUDIT LOG RETRIEVAL (GET /api/audit)
 * Protected by requireSuperAdminAuth
 */
app.get('/api/audit', requireSuperAdminAuth, async (req, res) => {
  try {
    const db = getFirestore();
    const snapshot = await db.collection('audit_logs').orderBy('createdAt', 'desc').limit(200).get();
    const logs = snapshot.docs.map((doc) => doc.data());
    return res.json({ logs });
  } catch (err: any) {
    return res.status(500).json({
      error: 'AUDIT_FETCH_FAILED',
      message: 'Failed to retrieve audit logs from database.',
    });
  }
});

/**
 * 5. DIRECT SOURCE CODE ZIP DOWNLOAD ENDPOINT
 * Serves the sanitized project source code archive with attachment disposition
 */
app.get(['/download/source-code.zip', '/download/source-code', '/download-zip'], (req, res) => {
  const zipPath = path.join(__dirname, 'public', 'manjankal-church-festival-accounts-2026.zip');
  if (fs.existsSync(zipPath)) {
    res.download(zipPath, 'manjankal-church-festival-accounts-2026.zip');
  } else {
    res.status(404).json({ error: 'ARCHIVE_NOT_FOUND', message: 'Source code archive not found.' });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`Church Festival Accounts Secure Server running on http://localhost:${PORT}`);
  });
}

startServer();
