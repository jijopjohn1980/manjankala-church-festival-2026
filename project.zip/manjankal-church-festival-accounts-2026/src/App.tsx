import React, { useState, useEffect } from 'react';
import {
  AppState,
  FestivalYear,
  Heading,
  IncomeTransaction,
  ExpenseTransaction,
  YearAccountingData,
  AuditLog,
  SyncStatus,
} from './types/festival';
import {
  loadAppState,
  saveAppState,
  createInitialYearData,
  createCleanInitialState,
  CHURCH_DETAILS,
} from './utils/storage';
import {
  getActiveSession,
  clearSession,
  refreshSession,
  SUPER_ADMIN_EMAIL,
  AuthSession,
  getSecurityStatus,
} from './utils/auth';
import { Header } from './components/Header';
import { SummaryCards } from './components/SummaryCards';
import { HeadingsManager } from './components/HeadingsManager';
import { IncomeManager } from './components/IncomeManager';
import { ExpenseManager } from './components/ExpenseManager';
import { ReportsView } from './components/ReportsView';
import { AuditLogView } from './components/AuditLogView';
import { BackupRestoreModal } from './components/BackupRestoreModal';
import { SecurityAuditModal } from './components/SecurityAuditModal';
import { LoginGate } from './components/LoginGate';
import { ShieldCheck, UserCheck, AlertTriangle, KeyRound } from 'lucide-react';
import { isFirebaseClientConfigured, signOutGoogle, checkRedirectAuthResult } from './services/firebase';
import {
  commitIncomeToFirestore,
  commitExpenseToFirestore,
  commitHeadingToFirestore,
  updateHeadingInFirestore,
  commitAdminAuditLogToFirestore,
  subscribeToYearAccounting,
} from './services/firestoreSync';

export default function App() {
  const [appState, setAppState] = useState<AppState>(() => loadAppState());
  const [session, setSession] = useState<AuthSession | null>(() => getActiveSession());
  const [activeTab, setActiveTab] = useState<'DASHBOARD' | 'INCOME' | 'EXPENSE' | 'HEADINGS' | 'REPORTS' | 'AUDIT'>('DASHBOARD');
  const [autoOpenIncomeModal, setAutoOpenIncomeModal] = useState(false);
  const [isBackupModalOpen, setIsBackupModalOpen] = useState(false);
  const [isSecurityModalOpen, setIsSecurityModalOpen] = useState(false);
  const [securityModalTab, setSecurityModalTab] = useState<'AUDIT' | 'PIN'>('AUDIT');
  const [securityStatus, setSecurityStatus] = useState(() => getSecurityStatus());

  // Requirement 4: Visible Synchronization Status (Defaults to SAVED_LOCALLY in pre-cloud mode)
  const [syncStatus, setSyncStatus] = useState<SyncStatus>('SAVED_LOCALLY');
  const [isOnline, setIsOnline] = useState<boolean>(() => (typeof navigator !== 'undefined' ? navigator.onLine : true));
  const [storageError, setStorageError] = useState<string | null>(null);

  // Connectivity event listeners
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Sync to local storage immediately and verify write success
  useEffect(() => {
    const res = saveAppState(appState);
    if (res.success) {
      setStorageError(null);
      // Only show SAVED_LOCALLY if not already confirmed SYNCED_FIREBASE
      setSyncStatus((prev) => (prev === 'SYNCED_FIREBASE' ? 'SYNCED_FIREBASE' : 'SAVED_LOCALLY'));
    } else {
      setStorageError(res.error || 'സംഭരണ തകരാർ നേരിട്ടു.');
      setSyncStatus('STORAGE_FAILED');
    }
  }, [appState]);

  // Requirement 5: Prevent silent loss of unsynced records on close, reload, or navigate away
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      let totalRecords = 0;
      Object.values(appState.dataByYear).forEach((d) => {
        totalRecords += (d.incomes?.length || 0) + (d.expenses?.length || 0);
      });

      // If records exist and are stored only locally in browser, trigger browser safety prompt
      if (totalRecords > 0 && syncStatus !== 'SYNCED_FIREBASE') {
        e.preventDefault();
        e.returnValue = 'നിങ്ങൾ രേഖപ്പെടുത്തിയ കണക്കുകൾ ഈ ബ്രൗസറിൽ മാത്രമേയുള്ളൂ (ക്ലൗഡിലേക്ക് സിങ്ക് ചെയ്തിട്ടില്ല). പേജ് ക്ലോസ് ചെയ്താൽ ബ്രൗസർ ഡാറ്റ മായ്ച്ചാൽ വിവരങ്ങൾ നഷ്ടപ്പെടാം. ഉറപ്പാണോ?';
        return e.returnValue;
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [appState, syncStatus]);

  // Session timeout auto-check and refresh on user activity
  useEffect(() => {
    if (!session) return;

    const interval = setInterval(() => {
      const current = getActiveSession();
      if (!current) {
        setSession(null);
      }
    }, 15000);

    const handleUserActivity = () => {
      refreshSession();
    };

    window.addEventListener('mousedown', handleUserActivity);
    window.addEventListener('keydown', handleUserActivity);

    return () => {
      clearInterval(interval);
      window.removeEventListener('mousedown', handleUserActivity);
      window.removeEventListener('keydown', handleUserActivity);
    };
  }, [session]);

  // Current active year and its accounting data
  const activeYear =
    appState.years.find((y) => y.id === appState.activeYearId) ||
    appState.years[0] || {
      id: '2026',
      yearName: '2026 വാർഷിക പെരുന്നാൾ',
      startDate: '2026-11-22',
      endDate: '2026-12-10',
      theme: 'വാർഷിക പെരുന്നാൾ മഹോത്സവം (22-11-2026 to 10-12-2026)',
      isCurrent: true,
    };

  const activeData: YearAccountingData =
    appState.dataByYear[activeYear.id] || createInitialYearData(activeYear.id);

  // Immutable Audit Logger (Synchronizes with trusted backend API)
  const recordAudit = (
    action: AuditLog['action'],
    summaryMl: string,
    amount?: number,
    details?: Record<string, any>
  ) => {
    const newLog: AuditLog = {
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      timestamp: new Date().toISOString(),
      userEmail: SUPER_ADMIN_EMAIL,
      action,
      summaryMl,
      amount,
      details,
    };
    setAppState((prev) => ({
      ...prev,
      auditLogs: [newLog, ...(prev.auditLogs || [])],
    }));

    // Finding 1: Attach valid Firebase ID token when available.
    // In pre-provisioning / offline local session mode (e.g. sa_ local session token),
    // safely retain audit events locally in appState.auditLogs without sending unauthenticated requests that produce 401 errors.
    // Never trust x-admin-email header.
    const activeToken = session?.token;
    const isFirebaseIdToken = activeToken && !activeToken.startsWith('sa_');

    if (isFirebaseIdToken) {
      fetch('/api/audit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${activeToken}`,
        },
        body: JSON.stringify({ action, summaryMl, amount, details }),
      }).catch((err) => {
        console.warn('Backend audit sync notice:', err);
      });
    }

    // Direct Firestore audit persistence matching firestore.rules Branch 2
    if (isFirebaseClientConfigured() && isOnline) {
      commitAdminAuditLogToFirestore(activeYear.id, {
        action,
        summaryMl,
        amount,
        details,
      }).catch((err) => {
        console.warn('Direct Firestore audit log notice:', err);
      });
    }
  };

  // Real-time Cloud Firestore synchronization when Firebase is configured and user is authenticated
  useEffect(() => {
    if (!isFirebaseClientConfigured() || !session || !isOnline) return;

    const unsubscribe = subscribeToYearAccounting(
      activeYear.id,
      (partial) => {
        setAppState((prev) => {
          const currentData = prev.dataByYear[activeYear.id] || createInitialYearData(activeYear.id);
          const updatedYearData: YearAccountingData = {
            ...currentData,
            ...partial,
          };
          return {
            ...prev,
            dataByYear: {
              ...prev.dataByYear,
              [activeYear.id]: updatedYearData,
            },
          };
        });
        setSyncStatus('SYNCED_FIREBASE');
      },
      (err) => {
        console.warn('Real-time Firestore sync notice:', err);
      }
    );

    return () => unsubscribe();
  }, [activeYear.id, session, isOnline]);

  const handleLogout = () => {
    recordAudit('LOGOUT', `സൂപ്പർ അഡ്മിൻ (${SUPER_ADMIN_EMAIL}) വിജയകരമായി ലോഗൗട്ട് ചെയ്തു`);
    signOutGoogle().catch(() => {});
    clearSession();
    setSession(null);
  };

  // If not authenticated, render Login Gate (Default Deny)
  if (!session) {
    return (
      <LoginGate
        onLoginSuccess={(newSession) => setSession(newSession)}
        onRecordAudit={recordAudit}
      />
    );
  }

  // Handlers for switching and adding festival years
  const handleSelectYear = (yearId: string) => {
    setAppState((prev) => ({
      ...prev,
      activeYearId: yearId,
    }));
  };

  const handleAddYear = (newYear: FestivalYear) => {
    setAppState((prev) => {
      const updatedYears = [newYear, ...prev.years];
      const initialData = createInitialYearData(newYear.id);
      return {
        ...prev,
        years: updatedYears,
        activeYearId: newYear.id,
        dataByYear: {
          ...prev.dataByYear,
          [newYear.id]: initialData,
        },
      };
    });
    recordAudit('BACKUP_RESTORE', `പുതിയ പെരുന്നാൾ വർഷം ആരംഭിച്ചു: ${newYear.yearName} (${newYear.id})`);
  };

  // Mutator helper for active year's data
  const updateActiveData = (updater: (prevData: YearAccountingData) => YearAccountingData) => {
    setAppState((prev) => {
      const currentData = prev.dataByYear[activeYear.id] || createInitialYearData(activeYear.id);
      const nextData = updater(currentData);
      return {
        ...prev,
        dataByYear: {
          ...prev.dataByYear,
          [activeYear.id]: nextData,
        },
      };
    });
  };

  // Heading Handlers
  const handleAddHeading = (headingInput: Omit<Heading, 'id'>) => {
    const newId = `${headingInput.type.toLowerCase()}-head-${activeYear.id}-${Date.now()}`;
    const newHeading: Heading = {
      ...headingInput,
      id: newId,
    };
    updateActiveData((data) => ({
      ...data,
      headings: [...data.headings, newHeading],
    }));
    recordAudit(
      'ADD_HEADING',
      `പുതിയ ശീർഷകം ചേർത്തു: "${headingInput.name}" (${headingInput.type === 'INCOME' ? 'വരവ്' : 'ചിലവ്'})`
    );
    if (isFirebaseClientConfigured() && isOnline) {
      commitHeadingToFirestore(activeYear.id, newHeading).catch((err) => {
        console.warn('Heading Firestore sync notice:', err);
      });
    }
  };

  const handleUpdateHeading = (updatedHeading: Heading) => {
    updateActiveData((data) => ({
      ...data,
      headings: data.headings.map((h) => (h.id === updatedHeading.id ? updatedHeading : h)),
      incomes: data.incomes.map((i) =>
        i.headingId === updatedHeading.id ? { ...i, headingName: updatedHeading.name } : i
      ),
      expenses: data.expenses.map((e) =>
        e.headingId === updatedHeading.id ? { ...e, headingName: updatedHeading.name } : e
      ),
    }));
    recordAudit('EDIT_HEADING', `ശീർഷകം തിരുത്തി: "${updatedHeading.name}"`);
    if (isFirebaseClientConfigured() && isOnline) {
      updateHeadingInFirestore(activeYear.id, updatedHeading).catch((err) => {
        console.warn('Heading Firestore update notice:', err);
      });
    }
  };

  const handleDeleteHeading = (headingId: string) => {
    const headingToDelete = activeData.headings.find((h) => h.id === headingId);
    updateActiveData((data) => ({
      ...data,
      headings: data.headings.filter((h) => h.id !== headingId),
    }));
    recordAudit('DELETE_HEADING', `ശീർഷകം നീക്കം ചെയ്തു: "${headingToDelete?.name || headingId}"`);
  };

  // Security Guard: Mandatory PIN change required before any income/expense accounting mutations
  const checkPinRequirement = (): boolean => {
    const status = getSecurityStatus();
    if (!status.hasCustomPin) {
      setSecurityModalTab('PIN');
      setIsSecurityModalOpen(true);
      return false;
    }
    return true;
  };

  // Income Handlers
  const handleAddIncome = (incomeInput: Omit<IncomeTransaction, 'id' | 'createdAt'>) => {
    if (!checkPinRequirement()) return;

    // Cloud Firestore Sync Path (when Firebase is configured and online)
    if (isFirebaseClientConfigured() && isOnline && session) {
      commitIncomeToFirestore(activeYear.id, incomeInput)
        .then((res) => {
          if (res.success && res.transaction) {
            setSyncStatus('SYNCED_FIREBASE');
            recordAudit(
              'ADD_INCOME',
              `വരവ് രസീത് ചേർത്തു: ${res.transaction.receiptNumber}${res.transaction.donorName ? ` - ${res.transaction.donorName}` : ''} (${res.transaction.headingName})`,
              res.transaction.amount
            );
          } else {
            console.warn('Firestore income commit notice, falling back locally:', res.error);
            saveIncomeLocally(incomeInput);
          }
        })
        .catch((err) => {
          console.warn('Firestore income commit error, falling back locally:', err);
          saveIncomeLocally(incomeInput);
        });
      return;
    }

    // Local / Offline mode
    saveIncomeLocally(incomeInput);
  };

  const saveIncomeLocally = (incomeInput: Omit<IncomeTransaction, 'id' | 'createdAt'>) => {
    updateActiveData((data) => {
      const newSeq = (data.lastReceiptSeq || 0) + 1;
      const newIncome: IncomeTransaction = {
        ...incomeInput,
        id: `inc-${activeYear.id}-${Date.now()}`,
        createdAt: new Date().toISOString(),
      };
      return {
        ...data,
        lastReceiptSeq: newSeq,
        incomes: [newIncome, ...data.incomes],
      };
    });
    setSyncStatus('SAVED_LOCALLY');
    recordAudit(
      'ADD_INCOME',
      `വരവ് രസീത് ചേർത്തു: ${incomeInput.receiptNumber}${incomeInput.donorName ? ` - ${incomeInput.donorName}` : ''} (${incomeInput.headingName})`,
      incomeInput.amount
    );
  };

  const handleUpdateIncome = (updatedIncome: IncomeTransaction) => {
    if (!checkPinRequirement()) return;
    updateActiveData((data) => ({
      ...data,
      incomes: data.incomes.map((i) => (i.id === updatedIncome.id ? updatedIncome : i)),
    }));
    recordAudit(
      'EDIT_INCOME',
      `വരവ് രസീത് തിരുത്തി: ${updatedIncome.receiptNumber}${updatedIncome.donorName ? ` - ${updatedIncome.donorName}` : ''}`,
      updatedIncome.amount
    );
  };

  const handleDeleteIncome = (incomeId: string) => {
    if (!checkPinRequirement()) return;
    const item = activeData.incomes.find((i) => i.id === incomeId);
    updateActiveData((data) => ({
      ...data,
      incomes: data.incomes.filter((i) => i.id !== incomeId),
    }));
    recordAudit(
      'DELETE_INCOME',
      `വരവ് രസീത് നീക്കം ചെയ്തു: ${item?.receiptNumber || incomeId}${item?.donorName ? ` (${item.donorName})` : ''}`,
      item?.amount
    );
  };

  const handleOpenAddIncomeFromDashboard = () => {
    if (!checkPinRequirement()) return;
    setAutoOpenIncomeModal(true);
    setActiveTab('INCOME');
  };

  // Expense Handlers
  const handleAddExpense = (expenseInput: Omit<ExpenseTransaction, 'id' | 'createdAt'>) => {
    if (!checkPinRequirement()) return;

    // Cloud Firestore Sync Path (when Firebase is configured and online)
    if (isFirebaseClientConfigured() && isOnline && session) {
      commitExpenseToFirestore(activeYear.id, expenseInput)
        .then((res) => {
          if (res.success && res.transaction) {
            setSyncStatus('SYNCED_FIREBASE');
            recordAudit(
              'ADD_EXPENSE',
              `ചിലവ് വൗച്ചർ ചേർത്തു: ${res.transaction.voucherNumber} - ${res.transaction.paidTo} (${res.transaction.headingName})`,
              res.transaction.amount
            );
          } else {
            console.warn('Firestore expense commit notice, falling back locally:', res.error);
            saveExpenseLocally(expenseInput);
          }
        })
        .catch((err) => {
          console.warn('Firestore expense commit error, falling back locally:', err);
          saveExpenseLocally(expenseInput);
        });
      return;
    }

    // Local / Offline mode
    saveExpenseLocally(expenseInput);
  };

  const saveExpenseLocally = (expenseInput: Omit<ExpenseTransaction, 'id' | 'createdAt'>) => {
    updateActiveData((data) => {
      const newSeq = (data.lastVoucherSeq || 0) + 1;
      const newExpense: ExpenseTransaction = {
        ...expenseInput,
        id: `exp-${activeYear.id}-${Date.now()}`,
        createdAt: new Date().toISOString(),
      };
      return {
        ...data,
        lastVoucherSeq: newSeq,
        expenses: [newExpense, ...data.expenses],
      };
    });
    setSyncStatus('SAVED_LOCALLY');
    recordAudit(
      'ADD_EXPENSE',
      `ചിലവ് വൗച്ചർ ചേർത്തു: ${expenseInput.voucherNumber} - ${expenseInput.paidTo} (${expenseInput.headingName})`,
      expenseInput.amount
    );
  };

  const handleUpdateExpense = (updatedExpense: ExpenseTransaction) => {
    if (!checkPinRequirement()) return;
    updateActiveData((data) => ({
      ...data,
      expenses: data.expenses.map((e) => (e.id === updatedExpense.id ? updatedExpense : e)),
    }));
    recordAudit(
      'EDIT_EXPENSE',
      `ചിലവ് വൗച്ചർ തിരുത്തി: ${updatedExpense.voucherNumber} - ${updatedExpense.paidTo}`,
      updatedExpense.amount
    );
  };

  const handleDeleteExpense = (expenseId: string) => {
    if (!checkPinRequirement()) return;
    const item = activeData.expenses.find((e) => e.id === expenseId);
    updateActiveData((data) => ({
      ...data,
      expenses: data.expenses.filter((e) => e.id !== expenseId),
    }));
    recordAudit(
      'DELETE_EXPENSE',
      `ചിലവ് വൗച്ചർ നീക്കം ചെയ്തു: ${item?.voucherNumber || expenseId} (${item?.paidTo || ''})`,
      item?.amount
    );
  };

  // Backup and Restore
  const handleRestoreState = (restored: AppState) => {
    setAppState(restored);
  };

  const handleResetSample = () => {
    const clean = createCleanInitialState();
    setAppState(clean);
  };

  return (
    <div className="min-h-screen flex flex-col bg-amber-50/30 text-slate-800">
      {/* Official Header */}
      <Header
        years={appState.years}
        activeYear={activeYear}
        onSelectYear={handleSelectYear}
        onAddYear={handleAddYear}
        onOpenBackupModal={() => setIsBackupModalOpen(true)}
        onOpenSecurityModal={() => {
          setSecurityModalTab('AUDIT');
          setIsSecurityModalOpen(true);
        }}
        onLogout={handleLogout}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        syncStatus={syncStatus}
        isOnline={isOnline}
      />

      {/* Persistent Critical Storage Alert Banner */}
      {storageError && (
        <div className="bg-rose-700 text-white px-4 py-3 text-xs font-bold text-center flex flex-wrap items-center justify-center gap-2 shadow-md border-b-2 border-rose-900 animate-pulse">
          <AlertTriangle className="w-4 h-4 text-rose-200 shrink-0" />
          <span>അതീവ സുരക്ഷാ മുന്നറിയിപ്പ്: {storageError}</span>
          <button
            type="button"
            onClick={() => setIsBackupModalOpen(true)}
            className="ml-2 underline bg-white text-rose-900 px-3 py-1 rounded-lg hover:bg-rose-50 text-[11px] font-black cursor-pointer shadow-xs"
          >
            ഉടൻ ബാക്കപ്പ് ഡൗൺലോഡ് ചെയ്യുക
          </button>
        </div>
      )}

      {/* Persistent Default PIN Security Warning Banner */}
      {!securityStatus.hasCustomPin && (
        <div className="bg-amber-500 text-amber-950 px-4 py-2.5 text-xs font-bold text-center flex flex-wrap items-center justify-center gap-2 border-b border-amber-600 shadow-xs">
          <KeyRound className="w-4 h-4 text-amber-900 shrink-0" />
          <span>
            സുരക്ഷാ മുന്നറിയിപ്പ്: നിങ്ങൾ നിലവിൽ പ്രാരംഭ ഡിഫോൾട്ട് പിൻ (221126) ആണ് ഉപയോഗിക്കുന്നത്. പെരുന്നാൾ കണക്കുകൾ രേഖപ്പെടുത്തുന്നതിന് മുൻപായി സുരക്ഷാ പിൻ ഉടൻ മാറ്റേണ്ടതാണ്.
          </span>
          <button
            type="button"
            onClick={() => {
              setSecurityModalTab('PIN');
              setIsSecurityModalOpen(true);
            }}
            className="ml-2 bg-amber-950 hover:bg-black text-amber-100 px-3 py-1 rounded-lg text-[11px] font-black cursor-pointer shadow-xs transition"
          >
            പിൻ മാറ്റുക (Change PIN)
          </button>
        </div>
      )}

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {activeTab === 'DASHBOARD' && (
          <div className="space-y-6">
            <SummaryCards
              data={activeData}
              year={activeYear}
              onNavigateToIncome={() => setActiveTab('INCOME')}
              onNavigateToExpense={() => setActiveTab('EXPENSE')}
              onNavigateToReports={() => setActiveTab('REPORTS')}
              onNavigateToHeadings={() => setActiveTab('HEADINGS')}
              onAddHeading={handleAddHeading}
              onOpenAddIncome={handleOpenAddIncomeFromDashboard}
            />
          </div>
        )}

        {activeTab === 'INCOME' && (
          <IncomeManager
            data={activeData}
            year={activeYear}
            onAddIncome={handleAddIncome}
            onUpdateIncome={handleUpdateIncome}
            onDeleteIncome={handleDeleteIncome}
            onNavigateToHeadings={() => setActiveTab('HEADINGS')}
            hasCustomPin={securityStatus.hasCustomPin}
            onRequestChangePin={() => {
              setSecurityModalTab('PIN');
              setIsSecurityModalOpen(true);
            }}
            autoOpenAdd={autoOpenIncomeModal}
            onCloseAutoOpenAdd={() => setAutoOpenIncomeModal(false)}
          />
        )}

        {activeTab === 'EXPENSE' && (
          <ExpenseManager
            data={activeData}
            year={activeYear}
            onAddExpense={handleAddExpense}
            onUpdateExpense={handleUpdateExpense}
            onDeleteExpense={handleDeleteExpense}
            onNavigateToHeadings={() => setActiveTab('HEADINGS')}
            hasCustomPin={securityStatus.hasCustomPin}
            onRequestChangePin={() => {
              setSecurityModalTab('PIN');
              setIsSecurityModalOpen(true);
            }}
          />
        )}

        {activeTab === 'HEADINGS' && (
          <HeadingsManager
            data={activeData}
            onAddHeading={handleAddHeading}
            onUpdateHeading={handleUpdateHeading}
            onDeleteHeading={handleDeleteHeading}
          />
        )}

        {activeTab === 'REPORTS' && (
          <ReportsView data={activeData} year={activeYear} />
        )}

        {activeTab === 'AUDIT' && (
          <AuditLogView logs={appState.auditLogs || []} />
        )}
      </main>

      {/* Footer (hidden in print) */}
      <footer className="bg-white border-t border-amber-200 py-6 text-center text-xs text-slate-500 no-print">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <img
              src={CHURCH_DETAILS.logoUrl}
              alt="Logo"
              className="w-6 h-6 object-contain rounded-full"
            />
            <span className="font-bold text-slate-700">{CHURCH_DETAILS.nameMl}</span>
          </div>

          <div className="text-[11px] text-slate-400">
            വാർഷിക പെരുന്നാൾ വരവ് ചിലവ് കണക്ക് സൂക്ഷിപ്പ് പോർട്ടൽ • രൂപ (INR ₹)
          </div>

          <div className="inline-flex items-center gap-1.5 text-[11px] text-emerald-800 font-semibold bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
            <span>സൂപ്പർ അഡ്മിൻ സുരക്ഷിത സിസ്റ്റം ({SUPER_ADMIN_EMAIL})</span>
          </div>
        </div>
      </footer>

      {/* Backup & Restore Modal */}
      {isBackupModalOpen && (
        <BackupRestoreModal
          appState={appState}
          onRestoreState={handleRestoreState}
          onResetSample={handleResetSample}
          onClose={() => setIsBackupModalOpen(false)}
          onRecordAudit={recordAudit}
        />
      )}

      {/* Security Audit & PIN Settings Modal */}
      {isSecurityModalOpen && (
        <SecurityAuditModal
          initialTab={securityModalTab}
          onClose={() => {
            setIsSecurityModalOpen(false);
            setSecurityStatus(getSecurityStatus());
          }}
          onRecordAudit={recordAudit}
        />
      )}
    </div>
  );
}
