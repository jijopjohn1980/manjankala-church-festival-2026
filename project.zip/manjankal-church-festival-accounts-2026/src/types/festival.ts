export type TransactionType = 'INCOME' | 'EXPENSE';

export interface Heading {
  id: string;
  name: string; // e.g. "നേർച്ച", "ലേലം"
  type: TransactionType;
  description?: string;
  isDefault?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface IncomeTransaction {
  id: string;
  receiptNumber: string; // e.g. "R-2026-001"
  date: string; // YYYY-MM-DD
  donorName?: string; // Name of Donor / Contributor (ഓപ്ഷണൽ)
  donorAddress?: string; // വീട്ടുപേര് / വിലാസം / ഫോൺ
  headingId: string;
  headingName: string;
  amount: number;
  paymentMode: 'CASH' | 'BANK' | 'UPI' | 'CHEQUE';
  referenceNumber?: string; // UPI txn / Cheque no
  description: string; // കുറിപ്പ് / വിവരണം
  collectedBy?: string; // പിരിവെടുത്തയാൾ
  createdAt: string;
}

export interface ExpenseTransaction {
  id: string;
  voucherNumber: string; // e.g. "V-2026-001"
  date: string; // YYYY-MM-DD
  paidTo: string; // തുക നൽകിയത് (വ്യക്തി / സ്ഥാപനം)
  headingId: string;
  headingName: string;
  amount: number;
  paymentMode: 'CASH' | 'BANK' | 'UPI' | 'CHEQUE';
  referenceNumber?: string; // ബിൽ നമ്പർ / ചെക്ക് നമ്പർ / ട്രാൻസാക്ഷൻ ഐഡി
  description: string; // ചിലവിന്റെ വിവരണം
  authorizedBy?: string; // അംഗീകരിച്ച കൺവീനർ / ട്രഷറർ
  createdAt: string;
}

export interface FestivalYear {
  id: string; // e.g. "2026"
  yearName: string; // e.g. "2026 പെരുന്നാൾ"
  startDate: string;
  endDate: string;
  theme?: string; // e.g. "117-ാമത് വാർഷിക പെരുന്നാൾ"
  isCurrent?: boolean;
}

export interface YearAccountingData {
  yearId: string;
  headings: Heading[];
  incomes: IncomeTransaction[];
  expenses: ExpenseTransaction[];
  lastReceiptSeq: number;
  lastVoucherSeq: number;
  notes?: string;
}

export interface AuditLog {
  id: string;
  timestamp: string; // ISO string
  userEmail: string; // "jijopjohn@gmail.com"
  action:
    | 'LOGIN'
    | 'LOGOUT'
    | 'ADD_HEADING'
    | 'EDIT_HEADING'
    | 'DELETE_HEADING'
    | 'ADD_INCOME'
    | 'EDIT_INCOME'
    | 'DELETE_INCOME'
    | 'ADD_EXPENSE'
    | 'EDIT_EXPENSE'
    | 'DELETE_EXPENSE'
    | 'BACKUP_EXPORT'
    | 'BACKUP_RESTORE'
    | 'CHANGE_PIN'
    | 'FAILED_LOGIN';
  entityType?: 'HEADING' | 'INCOME' | 'EXPENSE' | 'SYSTEM' | 'SECURITY';
  entityId?: string;
  summaryMl: string; // Malayalam summary
  amount?: number;
  details?: Record<string, any>;
}

export interface AppState {
  years: FestivalYear[];
  activeYearId: string;
  dataByYear: Record<string, YearAccountingData>;
  auditLogs?: AuditLog[];
}

export type SyncStatus = 'SAVED_LOCALLY' | 'SYNC_PENDING' | 'SYNCED_FIREBASE' | 'STORAGE_FAILED';

