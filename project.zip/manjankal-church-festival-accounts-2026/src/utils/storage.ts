import { AppState, Heading, YearAccountingData, FestivalYear } from '../types/festival';

export const STORAGE_KEY = 'manjakala_festival_accounts_2026_custom_v3';

export const CHURCH_DETAILS = {
  nameMl: 'മാർ ശെമവൂൻ ദെസ്തൂനി ഓർത്തഡോക്സ് സുറിയാനി പള്ളി, മഞ്ഞക്കാല',
  shortNameMl: 'മഞ്ഞക്കാല മാർ ശെമവൂൻ ദെസ്തൂനി പള്ളി',
  subMl: 'കൊല്ലം ഭദ്രാസനം (സ്ഥാപിതം 1909)',
  logoUrl: '/public/assets/aistudio/Untitled-1_copy_557a904e.jpg',
  photoUrl: '/public/assets/aistudio/arch_dedc7e87.jpg',
  titleMl: '2026 വാർഷിക പെരുന്നാൾ വരവ് ചിലവ് കണക്കുകൾ',
  festivalPeriodText: '22-11-2026 to 10-12-2026',
};

// ZERO predefined headings - completely empty lists as required
export const DEFAULT_INCOME_HEADINGS: Omit<Heading, 'id'>[] = [];
export const DEFAULT_EXPENSE_HEADINGS: Omit<Heading, 'id'>[] = [];

export function createInitialYearData(yearId: string): YearAccountingData {
  return {
    yearId,
    headings: [],
    incomes: [],
    expenses: [],
    lastReceiptSeq: 0,
    lastVoucherSeq: 0,
  };
}

export function createCleanInitialState(): AppState {
  const y2026: FestivalYear = {
    id: '2026',
    yearName: '2026 വാർഷിക പെരുന്നാൾ',
    startDate: '2026-11-22',
    endDate: '2026-12-10',
    theme: 'വാർഷിക പെരുന്നാൾ മഹോത്സവം (22-11-2026 to 10-12-2026)',
    isCurrent: true,
  };

  const data2026 = createInitialYearData('2026');

  return {
    years: [y2026],
    activeYearId: '2026',
    dataByYear: {
      '2026': data2026,
    },
  };
}

/**
 * Comprehensive AppState Schema Validator
 * Guarantees that an object contains valid structure, required fields, and correct types
 */
export function isValidAppStateSchema(data: any): data is AppState {
  if (!data || typeof data !== 'object') return false;
  if (!Array.isArray(data.years) || data.years.length === 0) return false;
  if (typeof data.activeYearId !== 'string' || !data.activeYearId.trim()) return false;
  if (!data.dataByYear || typeof data.dataByYear !== 'object') return false;

  // Validate each year entry and its corresponding accounting dataset
  for (const year of data.years) {
    if (!year || typeof year !== 'object') return false;
    if (typeof year.id !== 'string' || !year.id.trim()) return false;
    if (typeof year.yearName !== 'string' || !year.yearName.trim()) return false;

    const yearData = data.dataByYear[year.id];
    if (!yearData || typeof yearData !== 'object') return false;
    if (!Array.isArray(yearData.headings)) return false;
    if (!Array.isArray(yearData.incomes)) return false;
    if (!Array.isArray(yearData.expenses)) return false;

    // Validate income transaction integrity
    for (const inc of yearData.incomes) {
      if (!inc || typeof inc !== 'object') return false;
      if (typeof inc.id !== 'string' || typeof inc.amount !== 'number' || isNaN(inc.amount)) return false;
      if (typeof inc.receiptNumber !== 'string') return false;
    }

    // Validate expense transaction integrity
    for (const exp of yearData.expenses) {
      if (!exp || typeof exp !== 'object') return false;
      if (typeof exp.id !== 'string' || typeof exp.amount !== 'number' || isNaN(exp.amount)) return false;
      if (typeof exp.voucherNumber !== 'string') return false;
    }
  }

  return true;
}

export function loadAppState(): AppState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const initial = createCleanInitialState();
      saveAppState(initial);
      return initial;
    }
    const parsed = JSON.parse(raw);
    if (!isValidAppStateSchema(parsed)) {
      console.warn('Corrupted or incomplete state detected in localStorage. Loading clean state.');
      const initial = createCleanInitialState();
      saveAppState(initial);
      return initial;
    }
    return parsed;
  } catch (err) {
    console.error('Failed to load accounts state from storage:', err);
    return createCleanInitialState();
  }
}

/**
 * Robust, read-back verified localStorage persistence
 * Returns explicit success status and error message (e.g. QuotaExceededError)
 */
export function saveAppState(state: AppState): { success: boolean; error?: string } {
  try {
    if (!isValidAppStateSchema(state)) {
      throw new Error('Refusing to persist invalid or malformed AppState schema.');
    }

    const serialized = JSON.stringify(state);
    localStorage.setItem(STORAGE_KEY, serialized);

    // Exact content read-back verification: Any character-level mismatch constitutes a failed save
    const readBack = localStorage.getItem(STORAGE_KEY);
    if (!readBack || readBack !== serialized) {
      throw new Error('Read-back verification failed: stored content does not exactly match serialized state.');
    }

    return { success: true };
  } catch (err: any) {
    console.error('CRITICAL localStorage persistence failure:', err);
    const isQuota =
      err.name === 'QuotaExceededError' ||
      err.name === 'NS_ERROR_DOM_QUOTA_REACHED' ||
      err.code === 22 ||
      err.code === 1014;

    return {
      success: false,
      error: isQuota
        ? 'ബ്രൗസർ മെമ്മറി പരിധി കവിഞ്ഞു (Storage Quota Exceeded). പുതിയ വിവരങ്ങൾ സേവ് ചെയ്യാൻ സാധിക്കുന്നില്ല. ഉടൻ ബാക്കപ്പ് ഡൗൺലോഡ് ചെയ്യുക!'
        : err.message || 'ലോക്കൽ സ്റ്റോറേജ് സേവ് പരാജയപ്പെട്ടു.',
    };
  }
}
