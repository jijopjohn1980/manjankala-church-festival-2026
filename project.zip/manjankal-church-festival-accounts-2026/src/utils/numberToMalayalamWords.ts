/**
 * Convert Indian Rupee numbers to Malayalam words for receipts and vouchers
 */

const units = [
  '',
  'ഒന്ന്',
  'രണ്ട്',
  'മൂന്ന്',
  'നാല്',
  'അഞ്ച്',
  'ആറ്',
  'ഏഴ്',
  'എട്ട്',
  'ഒൻപത്',
  'പത്ത്',
  'പതിനൊന്ന്',
  'പന്ത്രണ്ട്',
  'പതിമൂന്ന്',
  'പതിനാല്',
  'പതിനഞ്ച്',
  'പതിനാറ്',
  'പതിനേഴ്',
  'പതിനെട്ട്',
  'പത്തൊൻപത്',
];

const tens = [
  '',
  'പത്ത്',
  'ഇരുപത്',
  'മുപ്പത്',
  'നാല്പത്',
  'അൻപത്',
  'അറുപത്',
  'എഴുപത്',
  'എൺപത്',
  'തൊണ്ണൂറ്',
];

const tensPrefix = [
  '',
  'പതി',
  'ഇരുപത്തി',
  'മുപ്പത്തി',
  'നാല്പത്തി',
  'അൻപത്തി',
  'അറുപത്തി',
  'എഴുപത്തി',
  'എൺപത്തി',
  'തൊണ്ണൂറ്റി',
];

function convertTwoDigits(n: number): string {
  if (n === 0) return '';
  if (n < 20) return units[n];
  const ten = Math.floor(n / 10);
  const rem = n % 10;
  if (rem === 0) return tens[ten];
  return tensPrefix[ten] + units[rem];
}

function convertThreeDigits(n: number): string {
  if (n === 0) return '';
  const hundred = Math.floor(n / 100);
  const rem = n % 100;
  let res = '';
  if (hundred > 0) {
    if (hundred === 1) res = 'നൂറ്';
    else if (hundred === 2) res = 'ഇരുന്നൂറ്';
    else if (hundred === 3) res = 'മുന്നൂറ്';
    else if (hundred === 4) res = 'നാനൂറ്';
    else if (hundred === 5) res = 'അഞ്ഞൂറ്';
    else if (hundred === 6) res = 'അറുന്നൂറ്';
    else if (hundred === 7) res = 'എഴുന്നൂറ്';
    else if (hundred === 8) res = 'എണ്ണൂറ്';
    else if (hundred === 9) res = 'തൊള്ളായിരം';

    if (rem > 0) {
      if (hundred === 1) res = 'നൂറ്റി ';
      else if (hundred === 2) res = 'ഇരുന്നൂറ്റി ';
      else if (hundred === 3) res = 'മുന്നൂറ്റി ';
      else if (hundred === 4) res = 'നാനൂറ്റി ';
      else if (hundred === 5) res = 'അഞ്ഞൂറ്റി ';
      else if (hundred === 6) res = 'അറുന്നൂറ്റി ';
      else if (hundred === 7) res = 'എഴുന്നൂറ്റി ';
      else if (hundred === 8) res = 'എണ്ണൂറ്റി ';
      else if (hundred === 9) res = 'തൊള്ളായിരത്തി ';
    }
  }
  if (rem > 0) {
    res += convertTwoDigits(rem);
  }
  return res.trim();
}

export function numberToMalayalamWords(num: number): string {
  if (num === 0) return 'പൂജ്യം രൂപ മാത്രം';
  if (num < 0) return 'മൈനസ് ' + numberToMalayalamWords(Math.abs(num));

  // Handle whole rupees and paise explicitly without silent truncation
  const wholeRupees = Math.floor(num);
  const paise = Math.round((num - wholeRupees) * 100);

  const crores = Math.floor(wholeRupees / 10000000);
  let rem = wholeRupees % 10000000;
  const lakhs = Math.floor(rem / 100000);
  rem = rem % 100000;
  const thousands = Math.floor(rem / 1000);
  rem = rem % 1000;
  const hundreds = rem;

  const parts: string[] = [];

  if (crores > 0) {
    parts.push(convertTwoDigits(crores) + ' കോടി');
  }
  if (lakhs > 0) {
    parts.push(convertTwoDigits(lakhs) + ' ലക്ഷം');
  }
  if (thousands > 0) {
    if (thousands === 1) parts.push('ആയിരം');
    else parts.push(convertTwoDigits(thousands) + ' ആയിരം');
  }
  if (hundreds > 0) {
    parts.push(convertThreeDigits(hundreds));
  }

  const result = parts.join(' ').trim();
  const rupeeText = result ? `${result} രൂപ` : `${wholeRupees} രൂപ`;

  if (paise > 0) {
    return `${rupeeText} ${convertTwoDigits(paise)} പൈസ മാത്രം`;
  }
  return `${rupeeText} മാത്രം`;
}

export function formatINR(val: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(val || 0);
}
