/**
 * Canonical Payload Normalization & SHA-256 Fingerprinting Module
 * Manjankal Mar Shemavoon Desthuni Orthodox Syrian Church - 2026 Festival Accounts
 * 
 * Guarantees:
 * 1. Decimal rejection: Whole Indian Rupees only. No silent rounding or truncate.
 * 2. Deterministic serialization: Sorted keys, trimmed strings, null-coalesced optionals.
 * 3. Native Web Crypto API: Zero external dependencies, runs in browser and modern Node.
 */

export interface CanonicalIncomePayload {
  date: string;
  headingId: string;
  amount: number;
  paymentMode: 'CASH' | 'BANK' | 'UPI' | 'CHEQUE';
  description: string;
  donorName?: string | null;
  donorAddress?: string | null;
  referenceNumber?: string | null;
  collectedBy?: string | null;
}

export interface CanonicalExpensePayload {
  date: string;
  paidTo: string;
  headingId: string;
  amount: number;
  paymentMode: 'CASH' | 'BANK' | 'UPI' | 'CHEQUE';
  description: string;
  referenceNumber?: string | null;
  authorizedBy?: string | null;
}

/**
 * Validates whole Indian Rupee constraint. Decimals and fractions are strictly rejected.
 * Rejects non-primitive types (boolean, array, object) and malformed strings.
 */
export function validateWholeRupeeAmount(amount: unknown): number {
  if (typeof amount !== 'number' && typeof amount !== 'string') {
    throw new Error('INVALID_AMOUNT: സാധുവായ ഒരു പോസിറ്റീവ് പൂർണ്ണ സംഖ്യ നൽകുക.');
  }

  if (typeof amount === 'string') {
    if (amount.includes('.')) {
      throw new Error('DECIMAL_AMOUNT_REJECTED: തുക പൂർണ്ണ രൂപയിൽ (Whole Rupees) നൽകുക. പൈസ അനുവദനീയമല്ല.');
    }
    // Must be positive integer digits only (optionally surrounded by whitespace)
    if (!/^\s*\d+\s*$/.test(amount)) {
      throw new Error('INVALID_AMOUNT: സാധുവായ ഒരു പോസിറ്റീവ് പൂർണ്ണ സംഖ്യ നൽകുക.');
    }
  }

  const num = Number(amount);
  if (!Number.isFinite(num) || num <= 0) {
    throw new Error('INVALID_AMOUNT: സാധുവായ ഒരു പോസിറ്റീവ് പൂർണ്ണ സംഖ്യ നൽകുക.');
  }
  if (!Number.isInteger(num)) {
    throw new Error('DECIMAL_AMOUNT_REJECTED: തുക പൂർണ്ണ രൂപയിൽ (Whole Rupees) നൽകുക. പൈസ അനുവദനീയമല്ല.');
  }
  if (num > 5000000) {
    throw new Error('AMOUNT_EXCEEDED: തുക പരമാവധി പരിധിയായ ₹50,00,000-ൽ താഴെയായിരിക്കണം.');
  }
  return num;
}

/**
 * Normalizes optional string properties: undefined, null, "", and whitespace-only strings
 * all deterministically coalesce to null. Non-empty strings are trimmed.
 */
export function normalizeOptionalString(val?: unknown): string | null {
  if (val === null || val === undefined) return null;
  if (typeof val !== 'string') return null;
  const trimmed = val.trim();
  return trimmed.length > 0 ? trimmed : null;
}

/**
 * Normalizes required string properties with validation.
 */
export function normalizeRequiredString(val: unknown, fieldName: string): string {
  if (typeof val !== 'string' || val.trim().length === 0) {
    throw new Error(`INVALID_PAYLOAD: ${fieldName} നൽകിയിട്ടില്ല.`);
  }
  return val.trim();
}

/**
 * Normalizes an Income payload into a canonical key-sorted JSON string
 */
export function canonicalizeIncomePayload(payload: CanonicalIncomePayload): string {
  if (!payload || typeof payload !== 'object') {
    throw new Error('INVALID_PAYLOAD: വരുമാന വിവരങ്ങൾ നൽകിയിട്ടില്ല.');
  }

  const validatedAmount = validateWholeRupeeAmount(payload.amount);

  const canonicalObj = {
    amount: validatedAmount,
    collectedBy: normalizeOptionalString(payload.collectedBy),
    date: normalizeRequiredString(payload.date, 'date'),
    description: normalizeRequiredString(payload.description, 'description'),
    donorAddress: normalizeOptionalString(payload.donorAddress),
    donorName: normalizeOptionalString(payload.donorName),
    headingId: normalizeRequiredString(payload.headingId, 'headingId'),
    paymentMode: normalizeRequiredString(payload.paymentMode, 'paymentMode'),
    referenceNumber: normalizeOptionalString(payload.referenceNumber),
  };

  const sortedKeys = Object.keys(canonicalObj).sort();
  return JSON.stringify(canonicalObj, sortedKeys);
}

/**
 * Normalizes an Expense payload into a canonical key-sorted JSON string
 */
export function canonicalizeExpensePayload(payload: CanonicalExpensePayload): string {
  if (!payload || typeof payload !== 'object') {
    throw new Error('INVALID_PAYLOAD: ചിലവ് വിവരങ്ങൾ നൽകിയിട്ടില്ല.');
  }

  const validatedAmount = validateWholeRupeeAmount(payload.amount);

  const canonicalObj = {
    amount: validatedAmount,
    authorizedBy: normalizeOptionalString(payload.authorizedBy),
    date: normalizeRequiredString(payload.date, 'date'),
    description: normalizeRequiredString(payload.description, 'description'),
    headingId: normalizeRequiredString(payload.headingId, 'headingId'),
    paidTo: normalizeRequiredString(payload.paidTo, 'paidTo'),
    paymentMode: normalizeRequiredString(payload.paymentMode, 'paymentMode'),
    referenceNumber: normalizeOptionalString(payload.referenceNumber),
  };

  const sortedKeys = Object.keys(canonicalObj).sort();
  return JSON.stringify(canonicalObj, sortedKeys);
}

/**
 * Generates SHA-256 hexadecimal hash using the native Web Crypto API
 */
export async function computePayloadFingerprint(canonicalJsonString: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(canonicalJsonString);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Standardized Receipt Number Generator
 * Serials 1-999 padded with 3 zeros; natural string thereafter
 */
export function formatReceiptNumber(seq: number, yearId = '2026'): string {
  if (seq <= 0) throw new Error('INVALID_SEQUENCE: Sequence number must be > 0');
  const numStr = seq < 1000 ? String(seq).padStart(3, '0') : String(seq);
  return `R-${yearId}-${numStr}`;
}

/**
 * Standardized Voucher Number Generator
 * Serials 1-999 padded with 3 zeros; natural string thereafter
 */
export function formatVoucherNumber(seq: number, yearId = '2026'): string {
  if (seq <= 0) throw new Error('INVALID_SEQUENCE: Sequence number must be > 0');
  const numStr = seq < 1000 ? String(seq).padStart(3, '0') : String(seq);
  return `V-${yearId}-${numStr}`;
}

export interface MigrationIncomeRecord {
  seqNumber: number;
  receiptNumber: string;
  amount: number;
  date: string;
  headingName: string;
  description: string;
  donorName?: string | null;
}

export interface MigrationExpenseRecord {
  seqNumber: number;
  voucherNumber: string;
  amount: number;
  date: string;
  headingName: string;
  description: string;
  paidTo?: string | null;
}

/**
 * Computes canonical SHA-256 checksum over the set of historical migration records.
 * Sorts records deterministically (incomes by seqNumber, expenses by seqNumber),
 * canonicalizes each record, serializes to JSON, and digests with SHA-256.
 * Guarantees that any addition, deletion, or modification of any field alters the checksum.
 */
export async function computeMigrationChecksum(
  incomes: MigrationIncomeRecord[],
  expenses: MigrationExpenseRecord[]
): Promise<string> {
  const safeIncomes = Array.isArray(incomes) ? incomes : [];
  const safeExpenses = Array.isArray(expenses) ? expenses : [];

  const canonicalIncomes = [...safeIncomes]
    .sort((a, b) => a.seqNumber - b.seqNumber)
    .map((inc) => ({
      amount: validateWholeRupeeAmount(inc.amount),
      date: normalizeRequiredString(inc.date, 'date'),
      description: normalizeRequiredString(inc.description, 'description'),
      donorName: normalizeOptionalString(inc.donorName),
      headingName: normalizeRequiredString(inc.headingName, 'headingName'),
      receiptNumber: normalizeRequiredString(inc.receiptNumber, 'receiptNumber'),
      seqNumber: inc.seqNumber,
    }));

  const canonicalExpenses = [...safeExpenses]
    .sort((a, b) => a.seqNumber - b.seqNumber)
    .map((exp) => ({
      amount: validateWholeRupeeAmount(exp.amount),
      date: normalizeRequiredString(exp.date, 'date'),
      description: normalizeRequiredString(exp.description, 'description'),
      headingName: normalizeRequiredString(exp.headingName, 'headingName'),
      paidTo: normalizeRequiredString(exp.paidTo, 'paidTo'),
      seqNumber: exp.seqNumber,
      voucherNumber: normalizeRequiredString(exp.voucherNumber, 'voucherNumber'),
    }));

  const manifestPayload = {
    expenses: canonicalExpenses,
    incomes: canonicalIncomes,
  };

  const canonicalJson = JSON.stringify(manifestPayload);
  return computePayloadFingerprint(canonicalJson);
}

export function isValidFestivalDate(dateStr: string): boolean {
  if (!dateStr || typeof dateStr !== 'string') return false;
  return /^(2026-11-(2[2-9]|30)|2026-12-(0[1-9]|10))$/.test(dateStr.trim());
}

export interface MigrationValidationResult {
  valid: boolean;
  errors: string[];
  totalIncomes: number;
  totalExpenses: number;
  totalIncomeAmount: number;
  totalExpenseAmount: number;
  maxHistoricalReceiptSeq: number;
  maxHistoricalVoucherSeq: number;
  checksumSha256: string;
}

/**
 * Rigorously validates a legacy migration dataset before any dry-run or live ingestion.
 * Enforces:
 * 1. Zero duplicate serial numbers across historical records.
 * 2. Exact receipt/voucher format compliance (R-2026-XXX, V-2026-XXX).
 * 3. Permitted festival dates (2026-11-22 to 2026-12-10).
 * 4. Whole Indian Rupee amounts (decimals and fractions strictly rejected).
 * 5. Presence of required fields (headingName, description, paidTo for expenses).
 * 6. Generates canonical SHA-256 digest covering all records.
 */
export async function validateAndDigestMigrationDataset(
  incomes: MigrationIncomeRecord[],
  expenses: MigrationExpenseRecord[]
): Promise<MigrationValidationResult> {
  const errors: string[] = [];

  if (!Array.isArray(incomes)) {
    return {
      valid: false,
      errors: ['INVALID_DATASET: Incomes must be an array.'],
      totalIncomes: 0,
      totalExpenses: 0,
      totalIncomeAmount: 0,
      totalExpenseAmount: 0,
      maxHistoricalReceiptSeq: 0,
      maxHistoricalVoucherSeq: 0,
      checksumSha256: '',
    };
  }

  if (!Array.isArray(expenses)) {
    return {
      valid: false,
      errors: ['INVALID_DATASET: Expenses must be an array.'],
      totalIncomes: incomes.length,
      totalExpenses: 0,
      totalIncomeAmount: 0,
      totalExpenseAmount: 0,
      maxHistoricalReceiptSeq: 0,
      maxHistoricalVoucherSeq: 0,
      checksumSha256: '',
    };
  }

  // Check duplicate income seqNumbers and formats
  const seenIncomeSeqs = new Set<number>();
  let totalIncomeAmount = 0;
  let maxHistoricalReceiptSeq = 0;

  for (let idx = 0; idx < incomes.length; idx++) {
    const inc = incomes[idx];
    if (!inc) {
      errors.push(`Income record #${idx + 1} is empty or null.`);
      continue;
    }
    if (!Number.isInteger(inc.seqNumber) || inc.seqNumber <= 0) {
      errors.push(`Income record #${idx + 1}: Invalid seqNumber ${inc.seqNumber}. Must be a positive integer.`);
    } else {
      if (seenIncomeSeqs.has(inc.seqNumber)) {
        errors.push(`DUPLICATE_SERIAL: Income serial #${inc.seqNumber} occurs more than once.`);
      }
      seenIncomeSeqs.add(inc.seqNumber);
      if (inc.seqNumber > maxHistoricalReceiptSeq) {
        maxHistoricalReceiptSeq = inc.seqNumber;
      }
      const expectedReceiptNum = formatReceiptNumber(inc.seqNumber);
      if (inc.receiptNumber !== expectedReceiptNum) {
        errors.push(`INVALID_SERIAL_FORMAT: Income seq #${inc.seqNumber} has receiptNumber "${inc.receiptNumber}", expected "${expectedReceiptNum}".`);
      }
    }

    if (!isValidFestivalDate(inc.date)) {
      errors.push(`INVALID_DATE: Income #${inc.seqNumber || idx + 1} date "${inc.date}" outside 2026 festival period (2026-11-22 to 2026-12-10).`);
    }

    if (typeof inc.headingName !== 'string' || !inc.headingName.trim()) {
      errors.push(`MISSING_FIELD: Income #${inc.seqNumber || idx + 1} is missing headingName.`);
    }

    if (typeof inc.description !== 'string' || !inc.description.trim()) {
      errors.push(`MISSING_FIELD: Income #${inc.seqNumber || idx + 1} is missing description.`);
    }

    try {
      const validatedAmt = validateWholeRupeeAmount(inc.amount);
      totalIncomeAmount += validatedAmt;
    } catch (amtErr: any) {
      errors.push(`INVALID_AMOUNT (Income #${inc.seqNumber || idx + 1}): ${amtErr.message}`);
    }
  }

  // Check duplicate expense seqNumbers and formats
  const seenExpenseSeqs = new Set<number>();
  let totalExpenseAmount = 0;
  let maxHistoricalVoucherSeq = 0;

  for (let idx = 0; idx < expenses.length; idx++) {
    const exp = expenses[idx];
    if (!exp) {
      errors.push(`Expense record #${idx + 1} is empty or null.`);
      continue;
    }
    if (!Number.isInteger(exp.seqNumber) || exp.seqNumber <= 0) {
      errors.push(`Expense record #${idx + 1}: Invalid seqNumber ${exp.seqNumber}. Must be a positive integer.`);
    } else {
      if (seenExpenseSeqs.has(exp.seqNumber)) {
        errors.push(`DUPLICATE_SERIAL: Expense serial #${exp.seqNumber} occurs more than once.`);
      }
      seenExpenseSeqs.add(exp.seqNumber);
      if (exp.seqNumber > maxHistoricalVoucherSeq) {
        maxHistoricalVoucherSeq = exp.seqNumber;
      }
      const expectedVoucherNum = formatVoucherNumber(exp.seqNumber);
      if (exp.voucherNumber !== expectedVoucherNum) {
        errors.push(`INVALID_SERIAL_FORMAT: Expense seq #${exp.seqNumber} has voucherNumber "${exp.voucherNumber}", expected "${expectedVoucherNum}".`);
      }
    }

    if (!isValidFestivalDate(exp.date)) {
      errors.push(`INVALID_DATE: Expense #${exp.seqNumber || idx + 1} date "${exp.date}" outside 2026 festival period (2026-11-22 to 2026-12-10).`);
    }

    if (typeof exp.paidTo !== 'string' || !exp.paidTo.trim()) {
      errors.push(`MISSING_FIELD: Expense #${exp.seqNumber || idx + 1} is missing paidTo (payee).`);
    }

    if (typeof exp.headingName !== 'string' || !exp.headingName.trim()) {
      errors.push(`MISSING_FIELD: Expense #${exp.seqNumber || idx + 1} is missing headingName.`);
    }

    if (typeof exp.description !== 'string' || !exp.description.trim()) {
      errors.push(`MISSING_FIELD: Expense #${exp.seqNumber || idx + 1} is missing description.`);
    }

    try {
      const validatedAmt = validateWholeRupeeAmount(exp.amount);
      totalExpenseAmount += validatedAmt;
    } catch (amtErr: any) {
      errors.push(`INVALID_AMOUNT (Expense #${exp.seqNumber || idx + 1}): ${amtErr.message}`);
    }
  }

  let checksumSha256 = '';
  if (errors.length === 0) {
    checksumSha256 = await computeMigrationChecksum(incomes, expenses);
  }

  return {
    valid: errors.length === 0,
    errors,
    totalIncomes: incomes.length,
    totalExpenses: expenses.length,
    totalIncomeAmount,
    totalExpenseAmount,
    maxHistoricalReceiptSeq,
    maxHistoricalVoucherSeq,
    checksumSha256,
  };
}

