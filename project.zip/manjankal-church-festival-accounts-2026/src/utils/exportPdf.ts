import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import { YearAccountingData, FestivalYear } from '../types/festival';
import { CHURCH_DETAILS } from './storage';
import { formatINR, numberToMalayalamWords } from './numberToMalayalamWords';

export interface PdfExportOptions {
  year: FestivalYear;
  data: YearAccountingData;
  reportType: 'COMPLETE' | 'DAILY' | 'MONTHLY' | 'HEADINGS' | 'ALL_DETAILS';
  selectedDay?: string;
}

/**
 * Downloads a Blob reliably on mobile browsers (Android Chrome, iOS Safari) and Desktop.
 * Creates an object URL, clicks an invisible anchor, and handles cleanup safely.
 */
export function downloadPdfBlob(blob: Blob, fileName: string): { downloaded: boolean; url: string } {
  try {
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    link.rel = 'noopener';
    link.target = '_blank';
    link.style.display = 'none';

    document.body.appendChild(link);
    link.click();

    setTimeout(() => {
      try {
        if (link.parentNode) {
          document.body.removeChild(link);
        }
      } catch (e) {
        // cleanup suppression
      }
    }, 1000);

    return { downloaded: true, url };
  } catch (err) {
    console.error('Failed to trigger PDF download:', err);
    return { downloaded: false, url: '' };
  }
}

/**
 * Safely escapes HTML special characters to prevent Cross-Site Scripting (XSS).
 * Converts &, <, >, ", ', and ` into their corresponding safe HTML entities.
 * Handles null, undefined, numbers, and strings gracefully without breaking Malayalam Unicode characters.
 */
export function escapeHtml(value: unknown): string {
  if (value === null || value === undefined) return '';
  const str = String(value);
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
    .replace(/`/g, '&#96;');
}

/**
 * Builds the HTML template for the PDF report.
 * Uses inline styling and fixed 800px width to ensure:
 * 1. 100% accurate Malayalam text shaping and ligatures via browser engine.
 * 2. Proper table widths that fit within A4 portrait page margins without horizontal clipping.
 * 3. Consistent layout regardless of user viewport or mobile device screen size.
 * 4. Strict XSS mitigation by escaping all user-controlled and imported transaction fields.
 */
export function buildReportHtml(options: PdfExportOptions): string {
  const { year, data, reportType, selectedDay } = options;

  const totalIncome = data.incomes.reduce((acc, i) => acc + (i.amount || 0), 0);
  const totalExpense = data.expenses.reduce((acc, e) => acc + (e.amount || 0), 0);
  const netBalance = totalIncome - totalExpense;
  const isSurplus = netBalance >= 0;

  // Heading-wise income totals
  const incomeHeadingsMap: Record<string, { name: string; amount: number; count: number }> = {};
  data.headings
    .filter((h) => h.type === 'INCOME')
    .forEach((h) => {
      incomeHeadingsMap[h.name] = { name: h.name, amount: 0, count: 0 };
    });
  data.incomes.forEach((i) => {
    if (!incomeHeadingsMap[i.headingName]) {
      incomeHeadingsMap[i.headingName] = { name: i.headingName, amount: 0, count: 0 };
    }
    incomeHeadingsMap[i.headingName].amount += i.amount;
    incomeHeadingsMap[i.headingName].count += 1;
  });

  // Heading-wise expense totals
  const expenseHeadingsMap: Record<string, { name: string; amount: number; count: number }> = {};
  data.headings
    .filter((h) => h.type === 'EXPENSE')
    .forEach((h) => {
      expenseHeadingsMap[h.name] = { name: h.name, amount: 0, count: 0 };
    });
  data.expenses.forEach((e) => {
    if (!expenseHeadingsMap[e.headingName]) {
      expenseHeadingsMap[e.headingName] = { name: e.headingName, amount: 0, count: 0 };
    }
    expenseHeadingsMap[e.headingName].amount += e.amount;
    expenseHeadingsMap[e.headingName].count += 1;
  });

  // Daily Breakdown
  const allDates = Array.from(
    new Set([...data.incomes.map((i) => i.date), ...data.expenses.map((e) => e.date)])
  ).sort();

  const dailyData = allDates.map((date) => {
    const dayIncomes = data.incomes.filter((i) => i.date === date);
    const dayExpenses = data.expenses.filter((e) => e.date === date);
    const dayIncTotal = dayIncomes.reduce((sum, i) => sum + i.amount, 0);
    const dayExpTotal = dayExpenses.reduce((sum, e) => sum + e.amount, 0);
    return {
      date,
      incomes: dayIncomes,
      expenses: dayExpenses,
      incomeTotal: dayIncTotal,
      expenseTotal: dayExpTotal,
      balance: dayIncTotal - dayExpTotal,
    };
  });

  // Monthly Breakdown
  const monthMap: Record<string, { monthStr: string; income: number; expense: number }> = {};
  data.incomes.forEach((i) => {
    const m = i.date.substring(0, 7);
    if (!monthMap[m]) monthMap[m] = { monthStr: m, income: 0, expense: 0 };
    monthMap[m].income += i.amount;
  });
  data.expenses.forEach((e) => {
    const m = e.date.substring(0, 7);
    if (!monthMap[m]) monthMap[m] = { monthStr: m, income: 0, expense: 0 };
    monthMap[m].expense += e.amount;
  });
  const monthlyList = Object.values(monthMap).sort((a, b) => a.monthStr.localeCompare(b.monthStr));

  const reportDateStr = new Date().toLocaleDateString('en-GB');

  let reportTitleMl = 'സമ്പൂർണ്ണ വരവ് ചിലവ് കണക്കുകൾ & ഓഡിറ്റ് സ്റ്റേറ്റ്‌മെന്റ്';
  if (reportType === 'DAILY') reportTitleMl = 'ദിവസേനയുള്ള വരവ് - ചിലവ് കണക്കുകൾ (Daily Log)';
  if (reportType === 'MONTHLY') reportTitleMl = 'മാസ തിരിച്ചുള്ള കണക്കുകൾ (Monthly Statement)';
  if (reportType === 'HEADINGS') reportTitleMl = 'ശീർഷക തിരിച്ചുള്ള കണക്കുകളുടെ സംഗ്രഹം (Headings Summary)';
  if (reportType === 'ALL_DETAILS') reportTitleMl = 'സമ്പൂർണ്ണ പെരുന്നാൾ കണക്ക് പുസ്തകം (Complete Register & Details)';

  return `
    <div style="font-family: 'Noto Sans Malayalam', 'Manrope', system-ui, -apple-system, sans-serif; width: 800px; padding: 32px; background-color: #ffffff; color: #0f172a; box-sizing: border-box; line-height: 1.4;">
      <style>
        @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Malayalam:wght@400;500;600;700;800;900&display=swap');
        * {
          box-sizing: border-box;
          font-family: 'Noto Sans Malayalam', 'Manrope', system-ui, -apple-system, sans-serif !important;
          font-feature-settings: 'kern' 1, 'liga' 1, 'clig' 1, 'calt' 1;
          font-variant-ligatures: normal;
          text-rendering: optimizeLegibility;
        }
      </style>
      
      <!-- Church Letterhead & Official Title -->
      <div style="text-align: center; border-bottom: 2px solid #7f1d1d; padding-bottom: 16px; margin-bottom: 20px;">
        <div style="display: flex; align-items: center; justify-content: center; gap: 16px; margin-bottom: 8px;">
          <img src="${CHURCH_DETAILS.logoUrl}" alt="Church Seal" style="width: 72px; height: 72px; object-fit: contain; border-radius: 50%; border: 2px solid #b45309; padding: 2px; background: #ffffff;" />
          <div style="text-align: left;">
            <div style="font-size: 13px; font-weight: 700; color: #78350f;">
              ${escapeHtml(CHURCH_DETAILS.subMl)}
            </div>
            <div style="font-size: 20px; font-weight: 900; color: #450a0a; margin-top: 2px; letter-spacing: -0.02em;">
              ${escapeHtml(CHURCH_DETAILS.nameMl)}
            </div>
            <div style="font-size: 13px; font-weight: 800; color: #92400e; margin-top: 2px;">
              ${escapeHtml(year.yearName)} • ${escapeHtml(reportTitleMl)}
            </div>
          </div>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 10px; font-size: 11px; font-weight: 700; color: #334155; border-top: 1px dashed #cbd5e1; padding-top: 8px;">
          <span>പെരുന്നാൾ കാലാവധി: <strong style="color: #78350f;">22-11-2026 to 10-12-2026</strong></span>
          <span>സ്ഥലം: <strong>മഞ്ഞക്കാല</strong> • റിപ്പോർട്ട് തീയതി: <strong>${escapeHtml(reportDateStr)}</strong></span>
        </div>
      </div>

      <!-- Financial Overview Banner -->
      <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 20px;">
        <div style="background-color: #ecfdf5; border: 1.5px solid #a7f3d0; border-radius: 12px; padding: 12px; text-align: center;">
          <div style="font-size: 11px; font-weight: 800; color: #065f46; text-transform: uppercase;">
            ആകെ വരവ് (Total Income)
          </div>
          <div style="font-size: 20px; font-weight: 900; color: #047857; margin-top: 4px;">
            ${formatINR(totalIncome)}
          </div>
          <div style="font-size: 10px; font-weight: 600; color: #059669; margin-top: 2px;">
            രസീതുകൾ: ${data.incomes.length} എണ്ണം
          </div>
        </div>

        <div style="background-color: #fff1f2; border: 1.5px solid #fecdd3; border-radius: 12px; padding: 12px; text-align: center;">
          <div style="font-size: 11px; font-weight: 800; color: #9f1239; text-transform: uppercase;">
            ആകെ ചിലവ് (Total Expenses)
          </div>
          <div style="font-size: 20px; font-weight: 900; color: #be123c; margin-top: 4px;">
            ${formatINR(totalExpense)}
          </div>
          <div style="font-size: 10px; font-weight: 600; color: #e11d48; margin-top: 2px;">
            വൗച്ചറുകൾ: ${data.expenses.length} എണ്ണം
          </div>
        </div>

        <div style="background-color: #fefce8; border: 1.5px solid #fef08a; border-radius: 12px; padding: 12px; text-align: center;">
          <div style="font-size: 11px; font-weight: 800; color: #854d0e; text-transform: uppercase;">
            നീക്കിയിരിപ്പ് (Net Balance)
          </div>
          <div style="font-size: 20px; font-weight: 900; color: ${isSurplus ? '#713f12' : '#991b1b'}; margin-top: 4px;">
            ${formatINR(netBalance)}
          </div>
          <div style="font-size: 10px; font-weight: 700; color: ${isSurplus ? '#15803d' : '#b91c1c'}; margin-top: 2px;">
            ${isSurplus ? '✓ നീക്കിയിരിപ്പ് തുക (Surplus)' : '⚠ ചിലവ് കവിഞ്ഞു (Deficit)'}
          </div>
        </div>
      </div>

      <!-- Balance In Words -->
      <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 10px 14px; margin-bottom: 24px; font-size: 11px;">
        <strong style="color: #475569;">അന്തിമ നീക്കിയിരിപ്പ് അക്ഷരത്തിൽ:</strong>
        <span style="font-weight: 700; color: #0f172a; margin-left: 6px;">${numberToMalayalamWords(netBalance)}</span>
      </div>

      ${
        // 1. COMPLETE STATEMENT OR ALL_DETAILS
        reportType === 'COMPLETE' || reportType === 'ALL_DETAILS'
          ? `
        <!-- Side-by-Side Headings Ledger -->
        <div style="display: flex; gap: 16px; margin-bottom: 24px;">
          <!-- Income Column -->
          <div style="flex: 1; border: 1.5px solid #10b981; border-radius: 10px; overflow: hidden;">
            <div style="background-color: #065f46; color: #ffffff; padding: 8px 12px; font-weight: 800; font-size: 12px; display: flex; justify-content: space-between;">
              <span>വരവ് ശീർഷകങ്ങൾ (Income)</span>
              <span>${data.incomes.length} രസീതുകൾ</span>
            </div>
            <table style="width: 100%; border-collapse: collapse; font-size: 11px;">
              <tbody>
                ${
                  Object.values(incomeHeadingsMap).length === 0
                    ? `<tr><td style="padding: 12px; text-align: center; color: #94a3b8;">വരവ് ശീർഷകങ്ങൾ ഇല്ല</td></tr>`
                    : Object.values(incomeHeadingsMap)
                        .map(
                          (h, idx) => `
                    <tr style="border-bottom: 1px solid #f1f5f9; background-color: ${idx % 2 === 0 ? '#ffffff' : '#f8fafc'};">
                      <td style="padding: 6px 10px; color: #1e293b; font-weight: 600;">
                        ${idx + 1}. ${escapeHtml(h.name)} <span style="font-size: 9px; color: #64748b;">(${h.count})</span>
                      </td>
                      <td style="padding: 6px 10px; text-align: right; font-weight: 700; color: #047857;">
                        ${formatINR(h.amount)}
                      </td>
                    </tr>
                  `
                        )
                        .join('')
                }
              </tbody>
              <tfoot>
                <tr style="background-color: #ecfdf5; border-top: 1.5px solid #10b981; font-weight: 800; font-size: 12px;">
                  <td style="padding: 8px 10px; color: #065f46;">ആകെ വരവ് തുക:</td>
                  <td style="padding: 8px 10px; text-align: right; color: #047857;">${formatINR(totalIncome)}</td>
                </tr>
              </tfoot>
            </table>
          </div>

          <!-- Expense Column -->
          <div style="flex: 1; border: 1.5px solid #f43f5e; border-radius: 10px; overflow: hidden;">
            <div style="background-color: #881337; color: #ffffff; padding: 8px 12px; font-weight: 800; font-size: 12px; display: flex; justify-content: space-between;">
              <span>ചിലവ് ശീർഷകങ്ങൾ (Expenses)</span>
              <span>${data.expenses.length} വൗച്ചറുകൾ</span>
            </div>
            <table style="width: 100%; border-collapse: collapse; font-size: 11px;">
              <tbody>
                ${
                  Object.values(expenseHeadingsMap).length === 0
                    ? `<tr><td style="padding: 12px; text-align: center; color: #94a3b8;">ചിലവ് ശീർഷകങ്ങൾ ഇല്ല</td></tr>`
                    : Object.values(expenseHeadingsMap)
                        .map(
                          (h, idx) => `
                    <tr style="border-bottom: 1px solid #f1f5f9; background-color: ${idx % 2 === 0 ? '#ffffff' : '#f8fafc'};">
                      <td style="padding: 6px 10px; color: #1e293b; font-weight: 600;">
                        ${idx + 1}. ${escapeHtml(h.name)} <span style="font-size: 9px; color: #64748b;">(${h.count})</span>
                      </td>
                      <td style="padding: 6px 10px; text-align: right; font-weight: 700; color: #be123c;">
                        ${formatINR(h.amount)}
                      </td>
                    </tr>
                  `
                        )
                        .join('')
                }
              </tbody>
              <tfoot>
                <tr style="background-color: #fff1f2; border-top: 1.5px solid #f43f5e; font-weight: 800; font-size: 12px;">
                  <td style="padding: 8px 10px; color: #881337;">ആകെ ചിലവ് തുക:</td>
                  <td style="padding: 8px 10px; text-align: right; color: #be123c;">${formatINR(totalExpense)}</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
        `
          : ''
      }

      ${
        // 2. DAILY REPORT
        reportType === 'DAILY'
          ? `
        <div style="margin-bottom: 24px;">
          <div style="font-weight: 800; font-size: 13px; color: #0f172a; margin-bottom: 10px; border-bottom: 1px solid #cbd5e1; padding-bottom: 4px;">
            ദിവസേനയുള്ള വരവ് - ചിലവ് പട്ടിക (Daily Log Table)
          </div>
          <table style="width: 100%; border-collapse: collapse; font-size: 11px; border: 1px solid #cbd5e1;">
            <thead>
              <tr style="background-color: #f1f5f9; font-weight: 800; color: #334155; border-bottom: 1.5px solid #94a3b8;">
                <th style="padding: 8px 10px; text-align: left;">തീയതി</th>
                <th style="padding: 8px 10px; text-align: right; color: #047857;">ദിവസ വരവ് (₹)</th>
                <th style="padding: 8px 10px; text-align: right; color: #be123c;">ദിവസ ചിലവ് (₹)</th>
                <th style="padding: 8px 10px; text-align: right; color: #0f172a;">നീക്കിയിരിപ്പ് (₹)</th>
              </tr>
            </thead>
            <tbody>
              ${
                dailyData.length === 0
                  ? `<tr><td colspan="4" style="padding: 16px; text-align: center; color: #94a3b8;">ഇടപാടുകൾ ഇല്ല</td></tr>`
                  : dailyData
                      .map(
                        (d, idx) => `
                  <tr style="border-bottom: 1px solid #e2e8f0; background-color: ${idx % 2 === 0 ? '#ffffff' : '#f8fafc'};">
                    <td style="padding: 7px 10px; font-weight: 700; color: #1e293b;">${escapeHtml(d.date)}</td>
                    <td style="padding: 7px 10px; text-align: right; font-weight: 700; color: #047857;">${formatINR(d.incomeTotal)}</td>
                    <td style="padding: 7px 10px; text-align: right; font-weight: 700; color: #be123c;">${formatINR(d.expenseTotal)}</td>
                    <td style="padding: 7px 10px; text-align: right; font-weight: 800; color: #0f172a;">${formatINR(d.balance)}</td>
                  </tr>
                `
                      )
                      .join('')
              }
            </tbody>
            <tfoot>
              <tr style="background-color: #f8fafc; border-top: 2px solid #64748b; font-weight: 800; font-size: 12px;">
                <td style="padding: 8px 10px;">ആകെത്തുക:</td>
                <td style="padding: 8px 10px; text-align: right; color: #047857;">${formatINR(totalIncome)}</td>
                <td style="padding: 8px 10px; text-align: right; color: #be123c;">${formatINR(totalExpense)}</td>
                <td style="padding: 8px 10px; text-align: right; color: #0f172a;">${formatINR(netBalance)}</td>
              </tr>
            </tfoot>
          </table>
        </div>
        `
          : ''
      }

      ${
        // 3. MONTHLY REPORT
        reportType === 'MONTHLY'
          ? `
        <div style="margin-bottom: 24px;">
          <div style="font-weight: 800; font-size: 13px; color: #0f172a; margin-bottom: 10px; border-bottom: 1px solid #cbd5e1; padding-bottom: 4px;">
            മാസ തിരിച്ചുള്ള വരവ് ചിലവ് താരതമ്യം (Monthly Cash Flow)
          </div>
          <table style="width: 100%; border-collapse: collapse; font-size: 11px; border: 1px solid #cbd5e1;">
            <thead>
              <tr style="background-color: #f1f5f9; font-weight: 800; color: #334155; border-bottom: 1.5px solid #94a3b8;">
                <th style="padding: 8px 10px; text-align: left;">മാസം</th>
                <th style="padding: 8px 10px; text-align: right; color: #047857;">ആകെ വരവ് (₹)</th>
                <th style="padding: 8px 10px; text-align: right; color: #be123c;">ആകെ ചിലവ് (₹)</th>
                <th style="padding: 8px 10px; text-align: right; color: #0f172a;">മാസ നീക്കിയിരിപ്പ് (₹)</th>
              </tr>
            </thead>
            <tbody>
              ${
                monthlyList.length === 0
                  ? `<tr><td colspan="4" style="padding: 16px; text-align: center; color: #94a3b8;">മാസ കണക്കുകൾ ഇല്ല</td></tr>`
                  : monthlyList
                      .map(
                        (m, idx) => `
                  <tr style="border-bottom: 1px solid #e2e8f0; background-color: ${idx % 2 === 0 ? '#ffffff' : '#f8fafc'};">
                    <td style="padding: 7px 10px; font-weight: 700; color: #1e293b;">${escapeHtml(m.monthStr)}</td>
                    <td style="padding: 7px 10px; text-align: right; font-weight: 700; color: #047857;">${formatINR(m.income)}</td>
                    <td style="padding: 7px 10px; text-align: right; font-weight: 700; color: #be123c;">${formatINR(m.expense)}</td>
                    <td style="padding: 7px 10px; text-align: right; font-weight: 800; color: #0f172a;">${formatINR(m.income - m.expense)}</td>
                  </tr>
                `
                      )
                      .join('')
              }
            </tbody>
          </table>
        </div>
        `
          : ''
      }

      ${
        // 4. DETAILED TRANSACTIONS LISTING (Requirement 5: Income, expenses, headings and transaction details)
        reportType === 'ALL_DETAILS' || reportType === 'COMPLETE'
          ? `
        <!-- Detailed Transaction Registers -->
        <div style="margin-top: 24px;">
          
          <!-- Income Transactions Table -->
          <div style="font-weight: 800; font-size: 13px; color: #065f46; margin-bottom: 8px; border-bottom: 1.5px solid #a7f3d0; padding-bottom: 4px;">
            📥 പെരുന്നാൾ വരവ് രസീതുകൾ (Income Transactions Register)
          </div>
          <table style="width: 100%; border-collapse: collapse; font-size: 10px; margin-bottom: 24px; border: 1px solid #e2e8f0;">
            <thead>
              <tr style="background-color: #ecfdf5; font-weight: 800; color: #065f46; border-bottom: 1.5px solid #a7f3d0;">
                <th style="padding: 6px 8px; text-align: left; width: 85px;">രസീത് നമ്പർ</th>
                <th style="padding: 6px 8px; text-align: left; width: 75px;">തീയതി</th>
                <th style="padding: 6px 8px; text-align: left;">Name of Donor / Contributor</th>
                <th style="padding: 6px 8px; text-align: left;">വരവ് ശീർഷകം</th>
                <th style="padding: 6px 8px; text-align: right; width: 85px;">തുക (₹)</th>
              </tr>
            </thead>
            <tbody>
              ${
                data.incomes.length === 0
                  ? `<tr><td colspan="5" style="padding: 12px; text-align: center; color: #94a3b8;">വരവ് രസീതുകൾ ഇല്ല</td></tr>`
                  : data.incomes
                      .map(
                        (i, idx) => `
                  <tr style="border-bottom: 1px solid #f1f5f9; background-color: ${idx % 2 === 0 ? '#ffffff' : '#f8fafc'};">
                    <td style="padding: 5px 8px; font-weight: 700; color: #1e293b; font-family: monospace;">${escapeHtml(i.receiptNumber)}</td>
                    <td style="padding: 5px 8px; color: #475569;">${escapeHtml(i.date)}</td>
                    <td style="padding: 5px 8px; font-weight: 700; color: #0f172a;">${i.donorName ? escapeHtml(i.donorName) : '-'}</td>
                    <td style="padding: 5px 8px; color: #334155;">${escapeHtml(i.headingName)}</td>
                    <td style="padding: 5px 8px; text-align: right; font-weight: 700; color: #047857;">${formatINR(i.amount)}</td>
                  </tr>
                `
                      )
                      .join('')
              }
            </tbody>
          </table>

          <!-- Expense Transactions Table -->
          <div style="font-weight: 800; font-size: 13px; color: #9f1239; margin-bottom: 8px; border-bottom: 1.5px solid #fecdd3; padding-bottom: 4px;">
            📤 പെരുന്നാൾ ചിലവ് വൗച്ചറുകൾ (Expense Vouchers Register)
          </div>
          <table style="width: 100%; border-collapse: collapse; font-size: 10px; margin-bottom: 24px; border: 1px solid #e2e8f0;">
            <thead>
              <tr style="background-color: #fff1f2; font-weight: 800; color: #9f1239; border-bottom: 1.5px solid #fecdd3;">
                <th style="padding: 6px 8px; text-align: left; width: 85px;">വൗച്ചർ നമ്പർ</th>
                <th style="padding: 6px 8px; text-align: left; width: 75px;">തീയതി</th>
                <th style="padding: 6px 8px; text-align: left;">നൽകിയത് (Paid To)</th>
                <th style="padding: 6px 8px; text-align: left;">ചിലവ് ശീർഷകം</th>
                <th style="padding: 6px 8px; text-align: right; width: 85px;">തുക (₹)</th>
              </tr>
            </thead>
            <tbody>
              ${
                data.expenses.length === 0
                  ? `<tr><td colspan="5" style="padding: 12px; text-align: center; color: #94a3b8;">ചിലവ് വൗച്ചറുകൾ ഇല്ല</td></tr>`
                  : data.expenses
                      .map(
                        (e, idx) => `
                  <tr style="border-bottom: 1px solid #f1f5f9; background-color: ${idx % 2 === 0 ? '#ffffff' : '#f8fafc'};">
                    <td style="padding: 5px 8px; font-weight: 700; color: #1e293b; font-family: monospace;">${escapeHtml(e.voucherNumber)}</td>
                    <td style="padding: 5px 8px; color: #475569;">${escapeHtml(e.date)}</td>
                    <td style="padding: 5px 8px; font-weight: 700; color: #0f172a;">${escapeHtml(e.paidTo)}</td>
                    <td style="padding: 5px 8px; color: #334155;">${escapeHtml(e.headingName)}</td>
                    <td style="padding: 5px 8px; text-align: right; font-weight: 700; color: #be123c;">${formatINR(e.amount)}</td>
                  </tr>
                `
                      )
                      .join('')
              }
            </tbody>
          </table>

        </div>
        `
          : ''
      }

      <!-- Official Signatures Block (Requirement 5) -->
      <div style="margin-top: 36px; padding-top: 24px; border-top: 1.5px solid #cbd5e1; display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; text-align: center; font-size: 11px;">
        <div>
          <div style="height: 36px; border-bottom: 1px dotted #94a3b8; width: 110px; margin: 0 auto 6px;"></div>
          <div style="font-weight: 800; color: #0f172a;">ജനറൽ കൺവീനർ</div>
          <div style="font-size: 9px; color: #64748b;">പെരുന്നാൾ സമിതി</div>
        </div>
        <div>
          <div style="height: 36px; border-bottom: 1px dotted #94a3b8; width: 110px; margin: 0 auto 6px;"></div>
          <div style="font-weight: 800; color: #0f172a;">ട്രഷറർ</div>
          <div style="font-size: 9px; color: #64748b;">പെരുന്നാൾ ഫണ്ട്</div>
        </div>
        <div>
          <div style="height: 36px; border-bottom: 1px dotted #94a3b8; width: 110px; margin: 0 auto 6px;"></div>
          <div style="font-weight: 800; color: #0f172a;">ഇടവക ട്രസ്റ്റിമാർ</div>
          <div style="font-size: 9px; color: #64748b;">പരിശോധിച്ച് സാക്ഷ്യപ്പെടുത്തി</div>
        </div>
        <div>
          <div style="height: 36px; border-bottom: 1px dotted #94a3b8; width: 110px; margin: 0 auto 6px;"></div>
          <div style="font-weight: 800; color: #0f172a;">വികാരി</div>
          <div style="font-size: 9px; color: #64748b;">പള്ളി സീൽ & അംഗീകാരം</div>
        </div>
      </div>

      <!-- Footer certification note -->
      <div style="margin-top: 24px; text-align: center; font-size: 10px; color: #64748b; font-style: italic; border-top: 1px solid #f1f5f9; padding-top: 8px;">
        ഈ കണക്ക് പുസ്തകം മഞ്ഞക്കാല മാർ ശെമവൂൻ ദെസ്തൂനി പള്ളി 2026 പെരുന്നാൾ സമിതിയുടെ ഔദ്യോഗിക രേഖയാണ്.
      </div>
    </div>
  `;
}

let colorConverterCanvasCtx: CanvasRenderingContext2D | null = null;

/**
 * Safely converts any modern CSS color string (oklab, oklch) to standard sRGB rgb(...)
 * using a Canvas 2D context or hex fallbacks. Prevents html2canvas color parsing crashes.
 */
export function safeColorToRgb(colorStr: string): string {
  if (typeof colorStr !== 'string') return colorStr;
  if (!colorStr.includes('oklab') && !colorStr.includes('oklch')) {
    return colorStr;
  }
  try {
    if (!colorConverterCanvasCtx && typeof document !== 'undefined') {
      const c = document.createElement('canvas');
      c.width = 1;
      c.height = 1;
      colorConverterCanvasCtx = c.getContext('2d', { willReadFrequently: true });
    }
    if (colorConverterCanvasCtx) {
      colorConverterCanvasCtx.fillStyle = '#ffffff';
      colorConverterCanvasCtx.fillStyle = colorStr;
      const converted = colorConverterCanvasCtx.fillStyle;
      if (converted && !converted.includes('oklab') && !converted.includes('oklch')) {
        return converted;
      }
    }
  } catch (e) {
    // fallback
  }

  // Safe semantic color fallbacks
  if (
    colorStr.includes('bg') ||
    colorStr.includes('background') ||
    colorStr.includes('fef') ||
    colorStr.includes('ecf') ||
    colorStr.includes('fff')
  ) {
    return 'rgb(255, 255, 255)';
  }
  return 'rgb(15, 23, 42)';
}

/**
 * Creates a Proxy around CSSStyleDeclaration to ensure all color-related property accesses
 * return standard rgb(...) values instead of oklab/oklch.
 */
function createStyleProxy(realStyle: CSSStyleDeclaration): CSSStyleDeclaration {
  return new Proxy(realStyle, {
    get(target, prop, receiver) {
      const val = Reflect.get(target, prop, receiver);
      if (typeof val === 'string') {
        return safeColorToRgb(val);
      }
      if (typeof val === 'function') {
        return function (...args: any[]) {
          const res = val.apply(target, args);
          if (typeof res === 'string') {
            return safeColorToRgb(res);
          }
          return res;
        };
      }
      return val;
    },
  });
}

/**
 * Verifies that a generated canvas contains actual rendered graphical/text content
 * rather than all-white or transparent pixels.
 */
function verifyCanvasHasContent(canvas: HTMLCanvasElement): boolean {
  try {
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx || canvas.width === 0 || canvas.height === 0) return false;

    const samplePointsY = [
      Math.floor(canvas.height * 0.05),
      Math.floor(canvas.height * 0.15),
      Math.floor(canvas.height * 0.3),
      Math.floor(canvas.height * 0.5),
      Math.floor(canvas.height * 0.7),
      Math.floor(canvas.height * 0.85),
    ];

    let nonWhitePixels = 0;
    for (const y of samplePointsY) {
      if (y <= 0 || y >= canvas.height) continue;
      for (let x = 60; x < canvas.width - 60; x += 40) {
        const pixel = ctx.getImageData(x, y, 1, 1).data;
        // pixel: [R, G, B, A]. If alpha > 0 and not pure white, it is real content
        if (pixel[3] > 0 && (pixel[0] < 245 || pixel[1] < 245 || pixel[2] < 245)) {
          nonWhitePixels++;
          if (nonWhitePixels >= 5) {
            return true;
          }
        }
      }
    }
    return nonWhitePixels >= 5;
  } catch (e) {
    // If CORS prevents pixel inspection, assume valid if dimensions are realistic
    return canvas.width > 200 && canvas.height > 200;
  }
}

/**
 * Generates and downloads a multi-page A4 PDF file using html2canvas & jsPDF.
 * Preserves Malayalam text rendering 100% cleanly without broken ligatures.
 * Completely immune to Android blank canvas optimizations and modern CSS color parsing issues.
 */
export async function generateAndDownloadPdf(
  options: PdfExportOptions
): Promise<{ success: boolean; fileName: string; blobUrl?: string; error?: string }> {
  // 1. Await global font loading so Noto Sans Malayalam renders glyphs accurately
  if (typeof document !== 'undefined' && 'fonts' in document) {
    try {
      await (document as any).fonts.ready;
    } catch (e) {
      // Continue gracefully
    }
  }

  // 2. Create the rendering stage directly in document.body
  // CRITICAL for Android: Opacity MUST be 1 and visibility MUST be visible so Chromium's
  // raster pipeline computes full layout, shapes Malayalam fonts, and paints real pixels!
  const stage = document.createElement('div');
  stage.id = 'pdf-export-stage';
  stage.style.position = 'absolute';
  stage.style.top = '0px';
  stage.style.left = '0px';
  stage.style.width = '800px';
  stage.style.margin = '0px';
  stage.style.padding = '0px';
  stage.style.backgroundColor = '#ffffff';
  stage.style.color = '#0f172a';
  stage.style.opacity = '1';
  stage.style.visibility = 'visible';
  stage.style.zIndex = '99990';
  stage.style.pointerEvents = 'none';

  stage.innerHTML = buildReportHtml(options);
  document.body.appendChild(stage);

  // 3. Mount user-facing loading overlay at z-index 99999 to shield the stage and provide feedback
  const overlay = document.createElement('div');
  overlay.id = 'pdf-render-overlay';
  overlay.style.position = 'fixed';
  overlay.style.inset = '0px';
  overlay.style.backgroundColor = 'rgba(15, 23, 42, 0.75)';
  overlay.style.backdropFilter = 'blur(4px)';
  overlay.style.zIndex = '99999';
  overlay.style.display = 'flex';
  overlay.style.flexDirection = 'column';
  overlay.style.alignItems = 'center';
  overlay.style.justifyContent = 'center';
  overlay.style.color = '#ffffff';
  overlay.innerHTML = `
    <div style="background: #ffffff; color: #0f172a; padding: 28px 36px; border-radius: 20px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.4); text-align: center; max-width: 90vw; font-family: 'Noto Sans Malayalam', system-ui, sans-serif;">
      <div style="width: 44px; height: 44px; border: 4px solid #fde68a; border-top-color: #b45309; border-radius: 50%; margin: 0 auto 16px; animation: pdfSpinAnim 0.8s linear infinite;"></div>
      <div style="font-weight: 800; font-size: 16px; color: #78350f; margin-bottom: 6px;">റിപ്പോർട്ട് PDF തയ്യാറാക്കുന്നു...</div>
      <div style="font-size: 13px; color: #64748b; font-weight: 500;">പേജുകൾ ക്രോഡീകരിക്കുന്നു, ദയവായി കാത്തിരിക്കുക</div>
    </div>
    <style>@keyframes pdfSpinAnim { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }</style>
  `;
  document.body.appendChild(overlay);

  // Intercept window.getComputedStyle to sanitize oklab/oklch colors during html2canvas
  const origGetComputedStyle = window.getComputedStyle;
  window.getComputedStyle = function (elt: Element, pseudo?: string | null) {
    const real = origGetComputedStyle.call(window, elt, pseudo);
    return createStyleProxy(real);
  };

  try {
    // 4. Pre-load images inside stage before capturing
    const images = Array.from(stage.querySelectorAll('img'));
    await Promise.all(
      images.map(
        (img) =>
          new Promise<void>((resolve) => {
            if (img.complete) {
              resolve();
            } else {
              img.onload = () => resolve();
              img.onerror = () => resolve();
              setTimeout(resolve, 1500);
            }
          })
      )
    );

    // 5. Wait for layout and reflow passes
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    await new Promise((r) => setTimeout(r, 200));

    // Measure actual rendered dimensions
    const contentWidth = 800;
    const contentHeight = Math.max(stage.scrollHeight, stage.offsetHeight, 600);

    // 6. Capture canvas with scale: 2 for crisp 300 DPI text
    const canvas = await html2canvas(stage, {
      scale: 2,
      useCORS: true,
      allowTaint: true,
      logging: false,
      backgroundColor: '#ffffff',
      width: contentWidth,
      height: contentHeight,
      windowWidth: contentWidth,
      windowHeight: contentHeight,
      scrollX: 0,
      scrollY: 0,
      x: 0,
      y: 0,
      onclone: (clonedDoc) => {
        // Proxy getComputedStyle on clonedDoc window if present
        if (clonedDoc.defaultView) {
          const clonedOrig = clonedDoc.defaultView.getComputedStyle;
          clonedDoc.defaultView.getComputedStyle = function (elt: Element, pseudo?: string | null) {
            return createStyleProxy(clonedOrig.call(clonedDoc.defaultView, elt, pseudo));
          };
        }

        // Force root backgrounds to pure white
        if (clonedDoc.documentElement) clonedDoc.documentElement.style.backgroundColor = '#ffffff';
        if (clonedDoc.body) {
          clonedDoc.body.style.backgroundColor = '#ffffff';
          clonedDoc.body.style.color = '#0f172a';
        }

        // Strip external stylesheets that contain oklab/oklch to prevent parser crashes
        const styles = Array.from(clonedDoc.querySelectorAll('style, link[rel="stylesheet"]'));
        styles.forEach((s) => {
          if (s.textContent && (s.textContent.includes('oklab') || s.textContent.includes('oklch'))) {
            s.remove();
          }
        });
      },
    });

    // 7. Verify canvas actually contains rendered pixels and text
    const hasRenderedContent = verifyCanvasHasContent(canvas);
    if (!hasRenderedContent) {
      console.warn('Canvas verification failed (canvas is blank). Falling back to native print-to-PDF.');
      openNativePrintToPdf(options);
      return {
        success: true,
        fileName: 'Print_Dialog_Opened',
        error: undefined,
      };
    }

    // 8. Multi-page slicing into jsPDF A4 pages
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
      compress: true,
    });

    const pageWidth = 210;
    const pageHeight = 297;
    const margin = 10;
    const printWidth = pageWidth - margin * 2; // 190 mm
    const printHeight = pageHeight - margin * 2; // 277 mm

    const totalPdfHeight = (canvas.height * printWidth) / canvas.width;

    if (totalPdfHeight <= printHeight) {
      // Single page document
      const imgData = canvas.toDataURL('image/jpeg', 0.95);
      pdf.addImage(imgData, 'JPEG', margin, margin, printWidth, totalPdfHeight);
    } else {
      // Multi-page document: slice canvas cleanly
      const canvasPageHeight = Math.floor((canvas.width * printHeight) / printWidth);
      let yOffset = 0;
      let pageNum = 0;
      const totalPages = Math.ceil(canvas.height / canvasPageHeight);

      while (yOffset < canvas.height) {
        const sliceHeight = Math.min(canvasPageHeight, canvas.height - yOffset);

        const pageCanvas = document.createElement('canvas');
        pageCanvas.width = canvas.width;
        pageCanvas.height = sliceHeight;
        const pageCtx = pageCanvas.getContext('2d');

        if (pageCtx) {
          pageCtx.fillStyle = '#ffffff';
          pageCtx.fillRect(0, 0, pageCanvas.width, pageCanvas.height);
          pageCtx.drawImage(
            canvas,
            0,
            yOffset,
            canvas.width,
            sliceHeight,
            0,
            0,
            canvas.width,
            sliceHeight
          );

          const pageImgData = pageCanvas.toDataURL('image/jpeg', 0.95);
          const currentPdfSliceHeight = (sliceHeight * printWidth) / canvas.width;

          if (pageNum > 0) {
            pdf.addPage();
          }

          pdf.addImage(pageImgData, 'JPEG', margin, margin, printWidth, currentPdfSliceHeight);

          // Add page number at bottom margin
          pdf.setFontSize(8);
          pdf.setTextColor(148, 163, 184);
          pdf.text(`പേജ് ${pageNum + 1} / ${totalPages}`, pageWidth - margin - 22, pageHeight - 4);
        }

        yOffset += canvasPageHeight;
        pageNum++;
      }
    }

    const reportCode = options.reportType.toLowerCase();
    const dateStamp = new Date().toISOString().split('T')[0];
    const fileName = `Manjankal_Church_2026_Festival_Accounts_${reportCode}_${dateStamp}.pdf`;

    const blob = pdf.output('blob');
    const { url } = downloadPdfBlob(blob, fileName);

    return {
      success: true,
      fileName,
      blobUrl: url,
    };
  } catch (err: any) {
    console.error('PDF generation error:', err);
    // On unexpected error, trigger the browser native print fallback as safety net
    try {
      openNativePrintToPdf(options);
    } catch (printErr) {
      // ignore
    }
    return {
      success: false,
      fileName: '',
      error: err?.message || 'PDF തയ്യാറാക്കുന്നതിൽ അപ്രതീക്ഷിത തടസ്സം നേരിട്ടു.',
    };
  } finally {
    // Restore window.getComputedStyle
    window.getComputedStyle = origGetComputedStyle;

    // Clean up DOM elements
    if (stage.parentNode) {
      document.body.removeChild(stage);
    }
    if (overlay.parentNode) {
      document.body.removeChild(overlay);
    }
  }
}

/**
 * Browser-native print-to-PDF window fallback.
 * Formats report strictly for A4 portrait paper and triggers the system/browser print-to-PDF dialog.
 */
export function openNativePrintToPdf(options: PdfExportOptions): void {
  const htmlContent = `
    <!DOCTYPE html>
    <html lang="ml">
      <head>
        <meta charset="utf-8">
        <title>Manjankal_Church_Festival_2026_Report</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;600;700;800&family=Noto+Sans+Malayalam:wght@400;600;700;800;900&display=swap" rel="stylesheet">
        <style>
          @page { size: A4 portrait; margin: 10mm; }
          body { margin: 0; padding: 0; background: #fff; font-family: 'Noto Sans Malayalam', sans-serif; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
          table { page-break-inside: auto; }
          tr { page-break-inside: avoid; }
        </style>
      </head>
      <body>
        ${buildReportHtml(options)}
        <script>
          window.onload = function() {
            setTimeout(function() {
              window.focus();
              window.print();
            }, 500);
          };
        </script>
      </body>
    </html>
  `;

  const printWindow = window.open('', '_blank');
  if (printWindow) {
    printWindow.document.open();
    printWindow.document.write(htmlContent);
    printWindow.document.close();
  } else {
    window.print();
  }
}
