import * as XLSX from 'xlsx';
import { YearAccountingData, FestivalYear } from '../types/festival';
import { CHURCH_DETAILS } from './storage';

export function exportFestivalToExcel(
  year: FestivalYear,
  data: YearAccountingData
) {
  const wb = XLSX.utils.book_new();

  // 1. Calculate Summary
  const totalIncome = data.incomes.reduce((acc, i) => acc + i.amount, 0);
  const totalExpense = data.expenses.reduce((acc, e) => acc + e.amount, 0);
  const netBalance = totalIncome - totalExpense;

  const incomeHeadingTotals: Record<string, number> = {};
  data.incomes.forEach((i) => {
    incomeHeadingTotals[i.headingName] = (incomeHeadingTotals[i.headingName] || 0) + i.amount;
  });

  const expenseHeadingTotals: Record<string, number> = {};
  data.expenses.forEach((e) => {
    expenseHeadingTotals[e.headingName] = (expenseHeadingTotals[e.headingName] || 0) + e.amount;
  });

  // Sheet 1: സംഗ്രഹം (Summary)
  const summaryRows = [
    [CHURCH_DETAILS.nameMl],
    [CHURCH_DETAILS.subMl],
    [`പെരുന്നാൾ കാലാവധി: 22-11-2026 to 10-12-2026`],
    [],
    ['പ്രധാന സംഗ്രഹം', 'തുക (രൂപ)'],
    ['ആകെ പെരുന്നാൾ വരവ് (Total Income)', totalIncome],
    ['ആകെ പെരുന്നാൾ ചിലവ് (Total Expense)', totalExpense],
    ['അന്തിമ നീക്കിയിരിപ്പ് / ബാക്കി (Net Festival Balance)', netBalance],
    [],
    ['--- വരവ് ശീർഷകം തിരിച്ചുള്ള കണക്ക് ---', 'തുക (രൂപ)'],
    ...Object.entries(incomeHeadingTotals).map(([name, sum]) => [name, sum]),
    ['ആകെ വരവ് തുക', totalIncome],
    [],
    ['--- ചിലവ് ശീർഷകം തിരിച്ചുള്ള കണക്ക് ---', 'തുക (രൂപ)'],
    ...Object.entries(expenseHeadingTotals).map(([name, sum]) => [name, sum]),
    ['ആകെ ചിലവ് തുക', totalExpense],
  ];
  const wsSummary = XLSX.utils.aoa_to_sheet(summaryRows);
  XLSX.utils.book_append_sheet(wb, wsSummary, 'സംഗ്രഹം');

  // Sheet 2: വരവുകൾ (Incomes)
  const incomeHeaders = [
    'രസീത് നമ്പർ',
    'തീയതി',
    'Name of Donor / Contributor (ദാതാവിന്റെ പേര്)',
    'മേൽവിലാസം / ഫോൺ',
    'വരവ് ശീർഷകം',
    'തുക (രൂപ)',
    'പെയ്മെന്റ് രീതി',
    'വിവരണം / റഫറൻസ്',
    'പിരിവെടുത്തയാൾ',
  ];
  const incomeRows = data.incomes.map((i) => [
    i.receiptNumber,
    i.date,
    i.donorName || '-',
    i.donorAddress || '-',
    i.headingName,
    i.amount,
    i.paymentMode === 'CASH'
      ? 'പണം (Cash)'
      : i.paymentMode === 'UPI'
      ? 'UPI / GPay'
      : i.paymentMode === 'BANK'
      ? 'ബാങ്ക് (Bank)'
      : 'ചെക്ക് (Cheque)',
    i.description + (i.referenceNumber ? ` (${i.referenceNumber})` : ''),
    i.collectedBy || '-',
  ]);
  const wsIncome = XLSX.utils.aoa_to_sheet([
    [`${CHURCH_DETAILS.nameMl} - ${year.yearName} - വരവ് രജിസ്റ്റർ`],
    [],
    incomeHeaders,
    ...incomeRows,
    [],
    ['', '', '', '', 'ആകെ വരവ് തുക (രൂപ):', totalIncome],
  ]);
  XLSX.utils.book_append_sheet(wb, wsIncome, 'വരവ് രജിസ്റ്റർ');

  // Sheet 3: ചിലവുകൾ (Expenses)
  const expenseHeaders = [
    'വൗച്ചർ നമ്പർ',
    'തീയതി',
    'തുക നൽകിയ വ്യക്തി / സ്ഥാപനം',
    'ചിലവ് ശീർഷകം',
    'തുക (രൂപ)',
    'പെയ്മെന്റ് രീതി',
    'റഫറൻസ് / ബിൽ നമ്പർ',
    'ചിലവിന്റെ വിവരണം',
    'അംഗീകരിച്ചത്',
  ];
  const expenseRows = data.expenses.map((e) => [
    e.voucherNumber,
    e.date,
    e.paidTo,
    e.headingName,
    e.amount,
    e.paymentMode === 'CASH'
      ? 'പണം (Cash)'
      : e.paymentMode === 'UPI'
      ? 'UPI / GPay'
      : e.paymentMode === 'BANK'
      ? 'ബാങ്ക് (Bank)'
      : 'ചെക്ക് (Cheque)',
    e.referenceNumber || '-',
    e.description,
    e.authorizedBy || '-',
  ]);
  const wsExpense = XLSX.utils.aoa_to_sheet([
    [`${CHURCH_DETAILS.nameMl} - ${year.yearName} - ചിലവ് രജിസ്റ്റർ`],
    [],
    expenseHeaders,
    ...expenseRows,
    [],
    ['', '', '', '', 'ആകെ ചിലവ് തുക (രൂപ):', totalExpense],
  ]);
  XLSX.utils.book_append_sheet(wb, wsExpense, 'ചിലവ് രജിസ്റ്റർ');

  // Sheet 4: ദിവസേനയുള്ള വിവരണം (Daily breakdown)
  const allDates = Array.from(
    new Set([...data.incomes.map((i) => i.date), ...data.expenses.map((e) => e.date)])
  ).sort();

  const dailyRows = allDates.map((date) => {
    const dayInc = data.incomes.filter((i) => i.date === date).reduce((acc, i) => acc + i.amount, 0);
    const dayExp = data.expenses.filter((e) => e.date === date).reduce((acc, e) => acc + e.amount, 0);
    return [date, dayInc, dayExp, dayInc - dayExp];
  });

  const wsDaily = XLSX.utils.aoa_to_sheet([
    [`${CHURCH_DETAILS.nameMl} - ദിവസേനയുള്ള കണക്കുകൾ`],
    [],
    ['തീയതി', 'ദിവസ വരവ് (₹)', 'ദിവസ ചിലവ് (₹)', 'നീക്കിയിരിപ്പ് (₹)'],
    ...dailyRows,
    [],
    ['ആകെ', totalIncome, totalExpense, netBalance],
  ]);
  XLSX.utils.book_append_sheet(wb, wsDaily, 'ദിവസേനയുള്ള കണക്ക്');

  // Download XLSX file
  const fileName = `Manjakala_Church_Festival_Accounts_${year.id}.xlsx`;
  XLSX.writeFile(wb, fileName);
}
