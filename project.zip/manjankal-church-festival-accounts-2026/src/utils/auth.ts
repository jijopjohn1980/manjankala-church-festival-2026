/**
 * Security and Authentication Module for Manjankal Church Festival Accounts
 * Sole Super Admin: jijopjohn@gmail.com
 * No other user accounts or Treasurer roles permitted.
 */

export const SUPER_ADMIN_EMAIL = 'jijopjohn@gmail.com';
const AUTH_STORAGE_KEY = 'manjakala_superadmin_auth_v1';
const CREDENTIALS_STORAGE_KEY = 'manjakala_superadmin_cred_v1';
const SESSION_TIMEOUT_MS = 30 * 60 * 1000; // 30 minutes
const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_DURATION_MS = 5 * 60 * 1000; // 5 minutes

// Default initial PIN: 221126 (matches 22-11-2026 festival start date)
const DEFAULT_INITIAL_PIN = '221126';
const SALT = 'ManjakalaMarShemavoonChurch2026FestivalSalt';

export interface AuthSession {
  userEmail: string;
  role: 'SUPER_ADMIN';
  loginTime: number;
  expiresAt: number;
  token: string;
}

export interface SecurityStatus {
  isLocked: boolean;
  lockoutRemainingSeconds: number;
  failedAttempts: number;
  hasCustomPin: boolean;
}

// Compute SHA-256 hash using browser native Web Crypto API
export async function hashPin(pin: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(`${SALT}:${pin.trim()}`);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

// Load or initialize stored password hash
async function getStoredHash(): Promise<string> {
  const existing = localStorage.getItem(CREDENTIALS_STORAGE_KEY);
  if (existing) {
    try {
      const parsed = JSON.parse(existing);
      if (parsed.hash) return parsed.hash;
    } catch {
      // fallback
    }
  }
  // Initialize with default PIN
  const defaultHash = await hashPin(DEFAULT_INITIAL_PIN);
  localStorage.setItem(
    CREDENTIALS_STORAGE_KEY,
    JSON.stringify({
      email: SUPER_ADMIN_EMAIL,
      hash: defaultHash,
      isCustom: false,
      updatedAt: new Date().toISOString(),
    })
  );
  return defaultHash;
}

// Get current lockout state
export function getSecurityStatus(): SecurityStatus {
  try {
    const rawAttempts = localStorage.getItem(`${CREDENTIALS_STORAGE_KEY}_attempts`);
    const attemptsData = rawAttempts ? JSON.parse(rawAttempts) : { count: 0, lockedUntil: 0 };
    const now = Date.now();
    const isLocked = attemptsData.lockedUntil > now;
    const lockoutRemainingSeconds = isLocked ? Math.ceil((attemptsData.lockedUntil - now) / 1000) : 0;

    const credRaw = localStorage.getItem(CREDENTIALS_STORAGE_KEY);
    const hasCustomPin = credRaw ? JSON.parse(credRaw).isCustom === true : false;

    return {
      isLocked,
      lockoutRemainingSeconds,
      failedAttempts: attemptsData.count || 0,
      hasCustomPin,
    };
  } catch {
    return {
      isLocked: false,
      lockoutRemainingSeconds: 0,
      failedAttempts: 0,
      hasCustomPin: false,
    };
  }
}

// Record a failed login attempt
function recordFailedAttempt(): SecurityStatus {
  try {
    const rawAttempts = localStorage.getItem(`${CREDENTIALS_STORAGE_KEY}_attempts`);
    const attemptsData = rawAttempts ? JSON.parse(rawAttempts) : { count: 0, lockedUntil: 0 };
    attemptsData.count = (attemptsData.count || 0) + 1;
    if (attemptsData.count >= MAX_FAILED_ATTEMPTS) {
      attemptsData.lockedUntil = Date.now() + LOCKOUT_DURATION_MS;
    }
    localStorage.setItem(`${CREDENTIALS_STORAGE_KEY}_attempts`, JSON.stringify(attemptsData));
  } catch (err) {
    console.error('Failed to record attempt:', err);
  }
  return getSecurityStatus();
}

// Clear failed attempts upon successful login
function clearFailedAttempts(): void {
  try {
    localStorage.removeItem(`${CREDENTIALS_STORAGE_KEY}_attempts`);
  } catch {
    // ignore
  }
}

// Verify credentials and create session
export async function authenticateSuperAdmin(
  email: string,
  pin: string
): Promise<{ success: boolean; error?: string; session?: AuthSession }> {
  const status = getSecurityStatus();
  if (status.isLocked) {
    return {
      success: false,
      error: `സുരക്ഷാ കാരണങ്ങളാൽ അക്കൗണ്ട് താൽക്കാലികമായി ലോക്ക് ചെയ്തിരിക്കുന്നു. ${status.lockoutRemainingSeconds} സെക്കൻഡുകൾക്ക് ശേഷം വീണ്ടും ശ്രമിക്കുക.`,
    };
  }

  // Strict email authorization
  if (email.trim().toLowerCase() !== SUPER_ADMIN_EMAIL.toLowerCase()) {
    recordFailedAttempt();
    return {
      success: false,
      error: `അനധികൃത ഇമെയിൽ വിലാസം. ${SUPER_ADMIN_EMAIL} എന്ന സൂപ്പർ അഡ്മിൻ ഇമെയിലിന് മാത്രമേ പ്രവേശനമുള്ളൂ.`,
    };
  }

  const storedHash = await getStoredHash();
  const inputHash = await hashPin(pin);

  if (storedHash !== inputHash) {
    const updatedStatus = recordFailedAttempt();
    const remaining = MAX_FAILED_ATTEMPTS - updatedStatus.failedAttempts;
    if (updatedStatus.isLocked) {
      return {
        success: false,
        error: `തെറ്റായ സെക്യൂരിറ്റി പിൻ! 5 തെറ്റായ ശ്രമങ്ങൾ പൂർത്തിയായി. അക്കൗണ്ട് 5 മിനിറ്റ് നേരത്തേക്ക് ലോക്ക് ചെയ്യപ്പെട്ടു.`,
      };
    }
    return {
      success: false,
      error: `തെറ്റായ സെക്യൂരിറ്റി പിൻ! വീണ്ടും ശ്രമിക്കാവുന്ന അവസരങ്ങൾ: ${Math.max(0, remaining)}.`,
    };
  }

  // Successful login
  clearFailedAttempts();
  const session: AuthSession = {
    userEmail: SUPER_ADMIN_EMAIL,
    role: 'SUPER_ADMIN',
    loginTime: Date.now(),
    expiresAt: Date.now() + SESSION_TIMEOUT_MS,
    token: `sa_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`,
  };

  saveSession(session);
  return { success: true, session };
}

// Session persistence
export function saveSession(session: AuthSession): void {
  try {
    sessionStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(session));
  } catch {
    // ignore
  }
}

export function getActiveSession(): AuthSession | null {
  try {
    const raw = sessionStorage.getItem(AUTH_STORAGE_KEY);
    if (!raw) return null;
    const session = JSON.parse(raw) as AuthSession;
    if (Date.now() > session.expiresAt) {
      clearSession();
      return null;
    }
    // Strict email check on existing session
    if (session.userEmail.toLowerCase() !== SUPER_ADMIN_EMAIL.toLowerCase()) {
      clearSession();
      return null;
    }
    return session;
  } catch {
    return null;
  }
}

export function refreshSession(): void {
  const session = getActiveSession();
  if (session) {
    session.expiresAt = Date.now() + SESSION_TIMEOUT_MS;
    saveSession(session);
  }
}

export function clearSession(): void {
  try {
    sessionStorage.removeItem(AUTH_STORAGE_KEY);
  } catch {
    // ignore
  }
}

// Change Super Admin PIN
export async function changeSuperAdminPin(
  currentPin: string,
  newPin: string
): Promise<{ success: boolean; error?: string }> {
  if (!newPin || newPin.trim().length < 4) {
    return { success: false, error: 'പുതിയ പിൻ കുറഞ്ഞത് 4 അക്കങ്ങൾ / ക്യാരക്ടറുകൾ ഉണ്ടായിരിക്കണം.' };
  }

  const storedHash = await getStoredHash();
  const inputHash = await hashPin(currentPin);

  if (storedHash !== inputHash) {
    return { success: false, error: 'നിലവിലെ സെക്യൂരിറ്റി പിൻ തെറ്റാണ്!' };
  }

  const newHash = await hashPin(newPin.trim());
  localStorage.setItem(
    CREDENTIALS_STORAGE_KEY,
    JSON.stringify({
      email: SUPER_ADMIN_EMAIL,
      hash: newHash,
      isCustom: true,
      updatedAt: new Date().toISOString(),
    })
  );

  return { success: true };
}
