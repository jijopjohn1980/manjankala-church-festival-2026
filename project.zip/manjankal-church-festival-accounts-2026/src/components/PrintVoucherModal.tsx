import React from 'react';
import { ExpenseTransaction, FestivalYear } from '../types/festival';
import { CHURCH_DETAILS } from '../utils/storage';
import { formatINR, numberToMalayalamWords } from '../utils/numberToMalayalamWords';
import { Printer, X } from 'lucide-react';

interface PrintVoucherModalProps {
  transaction: ExpenseTransaction | null;
  year: FestivalYear;
  onClose: () => void;
}

export const PrintVoucherModal: React.FC<PrintVoucherModalProps> = ({
  transaction,
  year,
  onClose,
}) => {
  if (!transaction) return null;

  const handlePrint = () => {
    window.print();
  };

  const amountWords = numberToMalayalamWords(transaction.amount);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-rose-300 relative my-6">
        
        {/* Action bar (hidden in print) */}
        <div className="no-print flex items-center justify-between pb-4 mb-4 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-600 animate-pulse" />
            <h3 className="text-base font-bold text-slate-800">
              ഔദ്യോഗിക പെരുന്നാൾ ചിലവ് വൗച്ചർ (Payment Voucher Preview)
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 bg-rose-800 hover:bg-rose-900 text-white text-xs font-bold px-4 py-2 rounded-xl transition shadow-sm cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>വൗച്ചർ പ്രിന്റ് ചെയ്യുക / PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Voucher Paper */}
        <div
          id="printable-voucher"
          className="border-2 border-rose-900/70 rounded-2xl p-6 bg-linear-to-b from-rose-50/30 via-white to-amber-50/20 text-slate-800 relative shadow-inner"
        >
          {/* Subtle watermarked emblem in background */}
          <div className="absolute inset-0 flex items-center justify-center opacity-4 pointer-events-none">
            <img
              src={CHURCH_DETAILS.logoUrl}
              alt="Church Seal Watermark"
              className="w-80 h-80 object-contain"
            />
          </div>

          {/* Header */}
          <div className="flex items-center justify-between gap-4 border-b-2 border-rose-900/30 pb-4 mb-4">
            <img
              src={CHURCH_DETAILS.logoUrl}
              alt="Logo"
              className="w-16 h-16 sm:w-20 sm:h-20 object-contain rounded-full border border-amber-500/40 p-0.5 bg-white shadow-xs"
            />
            <div className="text-center flex-1">
              <div className="text-[11px] font-bold text-amber-900 tracking-wide">
                കൊല്ലം ഭദ്രാസനം (സ്ഥാപിതം 1909)
              </div>
              <h2 className="text-lg sm:text-xl font-extrabold text-red-950 leading-tight">
                {CHURCH_DETAILS.nameMl}
              </h2>
              <div className="text-xs sm:text-sm font-bold text-rose-900 mt-0.5">
                {year.yearName} - ഔദ്യോഗിക പെയ്മെന്റ് വൗച്ചർ (Payment Voucher)
              </div>
              <div className="text-[11px] text-slate-600">
                {year.theme || 'വാർഷിക പെരുന്നാൾ മഹോത്സവം'}
              </div>
            </div>
            <div className="w-16 text-right sm:w-20">
              <span className="inline-block text-[10px] font-bold px-2 py-1 bg-rose-100 text-rose-900 border border-rose-300 rounded-md">
                VOUCHER
              </span>
            </div>
          </div>

          {/* Voucher Meta (Voucher No & Date) */}
          <div className="flex items-center justify-between text-xs sm:text-sm font-semibold mb-4 bg-rose-100/60 p-2.5 rounded-xl border border-rose-200">
            <div>
              <span className="text-slate-600">വൗച്ചർ നമ്പർ: </span>
              <span className="font-extrabold text-red-950 text-base">
                {transaction.voucherNumber}
              </span>
            </div>
            <div>
              <span className="text-slate-600">തീയതി: </span>
              <span className="font-bold text-slate-900">{transaction.date}</span>
            </div>
          </div>

          {/* Details Table */}
          <div className="space-y-3 text-sm">
            <div className="flex flex-col sm:flex-row sm:items-baseline gap-1 border-b border-dashed border-slate-300 pb-2">
              <span className="text-xs text-slate-500 sm:w-44 shrink-0 font-bold">
                തുക നൽകിയത് (Paid To):
              </span>
              <span className="font-extrabold text-slate-950 text-base">
                {transaction.paidTo}
              </span>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-baseline gap-1 border-b border-dashed border-slate-300 pb-2">
              <span className="text-xs text-slate-500 sm:w-44 shrink-0 font-bold">
                ചിലവ് ശീർഷകം (Heading):
              </span>
              <span className="font-bold text-rose-800">
                {transaction.headingName}
              </span>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-baseline gap-1 border-b border-dashed border-slate-300 pb-2">
              <span className="text-xs text-slate-500 sm:w-44 shrink-0 font-bold">
                ചിലവിന്റെ വിവരണം (Purpose):
              </span>
              <span className="text-slate-800 font-medium">
                {transaction.description}
              </span>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-baseline gap-1 border-b border-dashed border-slate-300 pb-2">
              <span className="text-xs text-slate-500 sm:w-44 shrink-0 font-bold">
                പെയ്മെന്റ് രീതി / റഫറൻസ്:
              </span>
              <span className="text-slate-800 font-medium">
                {transaction.paymentMode === 'CASH'
                  ? 'പണമായി (Cash)'
                  : transaction.paymentMode === 'UPI'
                  ? 'UPI / ഓൺലൈൻ'
                  : transaction.paymentMode === 'BANK'
                  ? 'ബാങ്ക് ട്രാൻസ്ഫർ'
                  : 'ചെക്ക്'}
                {transaction.referenceNumber && ` (ബിൽ / Ref: ${transaction.referenceNumber})`}
              </span>
            </div>

            {/* Amount Box */}
            <div className="mt-4 p-4 rounded-xl bg-linear-to-r from-rose-50 via-amber-50 to-rose-50 border-2 border-rose-700/60 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div>
                <div className="text-[11px] font-bold text-slate-600 uppercase">
                  നൽകിയ തുക (Amount in Words):
                </div>
                <div className="text-xs sm:text-sm font-extrabold text-rose-950 mt-0.5">
                  {amountWords}
                </div>
              </div>
              <div className="text-xl sm:text-2xl font-black text-rose-900 shrink-0 bg-white px-4 py-1.5 rounded-lg border border-rose-400 shadow-xs">
                {formatINR(transaction.amount)}
              </div>
            </div>
          </div>

          {/* Signatures & Approvals */}
          <div className="mt-8 pt-6 border-t border-slate-300 grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="h-10 border-b border-dotted border-slate-400 mx-auto w-28 sm:w-36 flex items-end justify-center">
                {transaction.authorizedBy && (
                  <span className="text-[10px] text-slate-600 font-semibold mb-1">
                    {transaction.authorizedBy}
                  </span>
                )}
              </div>
              <p className="text-[11px] font-bold text-slate-700 mt-1">കൺവീനർ</p>
              <p className="text-[9px] text-slate-400">അംഗീകരിച്ചു</p>
            </div>
            <div>
              <div className="h-10 border-b border-dotted border-slate-400 mx-auto w-28 sm:w-36" />
              <p className="text-[11px] font-bold text-slate-700 mt-1">ട്രഷറർ</p>
              <p className="text-[9px] text-slate-400">തുക വിതരണം ചെയ്തു</p>
            </div>
            <div>
              <div className="h-10 border-b border-dotted border-slate-400 mx-auto w-28 sm:w-36" />
              <p className="text-[11px] font-bold text-slate-700 mt-1">കൈപ്പറ്റിയയാളുടെ ഒപ്പ്</p>
              <p className="text-[9px] text-slate-400">റസീപ്റ്റ് ഒപ്പ്</p>
            </div>
          </div>

          <div className="mt-4 text-center text-[10px] text-slate-400 italic">
            * ഈ വൗച്ചർ മഞ്ഞക്കാല മാർ ശെമവൂൻ ദെസ്തൂനി പള്ളി വാർഷിക പെരുന്നാൾ അക്കൗണ്ട്സ് സിസ്റ്റം വഴി ജനറേറ്റ് ചെയ്തതാണ്.
          </div>
        </div>

      </div>
    </div>
  );
};
