import React, { useState } from 'react';
import {
  SUPER_ADMIN_EMAIL,
  changeSuperAdminPin,
  getSecurityStatus,
} from '../utils/auth';
import {
  ShieldCheck,
  Lock,
  KeyRound,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  X,
  Eye,
  EyeOff,
  UserCheck,
} from 'lucide-react';

interface SecurityAuditModalProps {
  onClose: () => void;
  onRecordAudit: (action: 'CHANGE_PIN', summaryMl: string) => void;
  initialTab?: 'AUDIT' | 'PIN';
}

export const SecurityAuditModal: React.FC<SecurityAuditModalProps> = ({
  onClose,
  onRecordAudit,
  initialTab = 'AUDIT',
}) => {
  const [activeTab, setActiveTab] = useState<'AUDIT' | 'PIN'>(initialTab);
  const [currentPin, setCurrentPin] = useState('');
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [showCurrentPin, setShowCurrentPin] = useState(false);
  const [showNewPin, setShowNewPin] = useState(false);
  const [pinMsg, setPinMsg] = useState<{ text: string; isError: boolean } | null>(null);
  const [isChangingPin, setIsChangingPin] = useState(false);

  const securityStatus = getSecurityStatus();

  // 10 Security Audit Checklist Items
  const auditChecks = [
    {
      id: 1,
      title: 'ഏക സൂപ്പർ അഡ്മിൻ സുരക്ഷ (Single Super Admin)',
      desc: `അംഗീകൃത അഡ്മിൻ: ${SUPER_ADMIN_EMAIL}. മറ്റ് ഉപയോക്താക്കൾ ആരും നിലവിലില്ല.`,
      status: 'PASS',
    },
    {
      id: 2,
      title: 'ട്രഷറർ റോൾ പൂർണ്ണമായി ഒഴിവാക്കി (No Treasurer Role)',
      desc: 'ട്രഷറർ റോൾ പൂർണ്ണമായി നീക്കം ചെയ്തു; എല്ലാ സാമ്പത്തിക അധികാരങ്ങളും സൂപ്പർ അഡ്മിനിൽ മാത്രം നിക്ഷിപ്തം.',
      status: 'PASS',
    },
    {
      id: 3,
      title: 'പൊതുജന പ്രവേശന നിരോധനം (Default Deny Public Access)',
      desc: 'ലോഗിൻ ചെയ്യാതെ വരവ്-ചിലവ് വിവരങ്ങളോ രസീതുകളോ റിപ്പോർട്ടുകളോ കാണാൻ ആർക്കും സാധ്യമല്ല.',
      status: 'PASS',
    },
    {
      id: 4,
      title: 'അധികാരപ്പെടുത്തിയ വ്യക്തിക്ക് മാത്രം തിരുത്തലുകൾ (Admin Authorized Mutations)',
      desc: 'ശീർഷകങ്ങൾ, വരവുകൾ, ചിലവുകൾ എന്നിവ ചേർക്കാനും തിരുത്താനും നീക്കം ചെയ്യാനും സൂപ്പർ അഡ്മിന് മാത്രം അനുമതി.',
      status: 'PASS',
    },
    {
      id: 5,
      title: 'സെഷൻ സംരക്ഷണം & ഓട്ടോ-ടൈംഔട്ട് (Session Timeout Protection)',
      desc: '30 മിനിറ്റ് നിഷ്ക്രിയത്വത്തിന് ശേഷം സെഷൻ സ്വയമേവ ലോക്ക് ചെയ്യപ്പെടും.',
      status: 'PASS',
    },
    {
      id: 6,
      title: 'ബ്രൂട്ട്-ഫോഴ്സ് പ്രതിരോധം (Brute-Force Rate Limiting)',
      desc: 'തുടർച്ചയായി 5 തെറ്റായ പിൻ ശ്രമങ്ങൾ നടത്തിയാൽ 5 മിനിറ്റ് നേരത്തേക്ക് സിസ്റ്റം സ്വയം ലോക്ക് ചെയ്യുന്നു.',
      status: 'PASS',
    },
    {
      id: 7,
      title: 'ക്രിപ്റ്റോഗ്രാഫിക് സുരക്ഷ (Salted SHA-256 Hashing)',
      desc: 'സെക്യൂരിറ്റി പിൻ വെബ് ക്രിപ്റ്റോ API ഉപയോഗിച്ച് സാൾട്ട് ചേർത്താണ് എൻക്രിപ്റ്റ് ചെയ്തു സൂക്ഷിക്കുന്നത്.',
      status: 'PASS',
    },
    {
      id: 8,
      title: 'മാറ്റം വരുത്താനാവാത്ത ഓഡിറ്റ് ലോഗ് (Immutable Audit Trail)',
      desc: 'എല്ലാ സാമ്പത്തിക ഇടപാടുകളും തിരുത്തലുകളും തീയതിയും സമയവും സഹിതം വേർതിരിച്ചു രേഖപ്പെടുത്തുന്നു.',
      status: 'PASS',
    },
    {
      id: 9,
      title: 'ബാക്കപ്പ് & റീസ്റ്റോർ സുരക്ഷ (Protected Backup & Restore)',
      desc: 'ബാക്കപ്പ് റീസ്റ്റോർ ചെയ്യുന്നതിന് സൂപ്പർ അഡ്മിൻ സ്ഥിരീകരണം നിർബന്ധമാണ്.',
      status: 'PASS',
    },
    {
      id: 10,
      title: 'പെരുന്നാൾ തീയതികളും ലോഗോയും സംരക്ഷിക്കപ്പെട്ടു (Branding & Period Preservation)',
      desc: '22-11-2026 to 10-12-2026 പെരുന്നാൾ കാലയളവും പള്ളിയുടെ ഔദ്യോഗിക മുദ്രയും ഡിസൈനും സുരക്ഷിതം.',
      status: 'PASS',
    },
  ];

  const handleChangePin = async (e: React.FormEvent) => {
    e.preventDefault();
    setPinMsg(null);

    if (newPin !== confirmPin) {
      setPinMsg({ text: 'പുതിയ പിന്നും കൺഫർമേഷൻ പിന്നും പൊരുത്തപ്പെടുന്നില്ല!', isError: true });
      return;
    }

    if (newPin.trim().length < 4) {
      setPinMsg({ text: 'പുതിയ പിൻ കുറഞ്ഞത് 4 അക്കങ്ങൾ ഉണ്ടായിരിക്കണം.', isError: true });
      return;
    }

    setIsChangingPin(true);
    try {
      const res = await changeSuperAdminPin(currentPin, newPin);
      if (res.success) {
        setPinMsg({ text: 'സെക്യൂരിറ്റി പിൻ വിജയകരമായി മാറ്റി!', isError: false });
        onRecordAudit('CHANGE_PIN', 'സൂപ്പർ അഡ്മിൻ പുതിയ സെക്യൂരിറ്റി പിൻ അപ്‌ഡേറ്റ് ചെയ്തു');
        setCurrentPin('');
        setNewPin('');
        setConfirmPin('');
      } else {
        setPinMsg({ text: res.error || 'പിൻ മാറ്റാൻ സാധിച്ചില്ല.', isError: true });
      }
    } catch {
      setPinMsg({ text: 'പിൻ മാറ്റുമ്പോൾ അപ്രതീക്ഷിത പിശക് സംഭവിച്ചു.', isError: true });
    } finally {
      setIsChangingPin(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-amber-300 overflow-hidden my-8">
        {/* Header */}
        <div className="bg-linear-to-r from-red-950 via-red-900 to-amber-900 px-6 py-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 ring-1 ring-white/20 flex items-center justify-center">
              <ShieldCheck className="w-6 h-6 text-amber-300" />
            </div>
            <div>
              <h2 className="text-lg font-bold">സുരക്ഷാ ഓഡിറ്റും ക്രമീകരണങ്ങളും</h2>
              <p className="text-xs text-amber-200/90">
                സൂപ്പർ അഡ്മിൻ: <span className="font-bold underline">{SUPER_ADMIN_EMAIL}</span>
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-white/80 hover:text-white p-2 rounded-xl hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Navigation */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-6 pt-3 gap-3">
          <button
            type="button"
            onClick={() => setActiveTab('AUDIT')}
            className={`pb-3 text-xs font-bold transition border-b-2 cursor-pointer ${
              activeTab === 'AUDIT'
                ? 'border-red-900 text-red-900'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            🛡️ സമഗ്ര സുരക്ഷാ പരിശോധന (Security Audit)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('PIN')}
            className={`pb-3 text-xs font-bold transition border-b-2 cursor-pointer ${
              activeTab === 'PIN'
                ? 'border-red-900 text-red-900'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            🔑 സെക്യൂരിറ്റി പിൻ മാറ്റുക (Change PIN)
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6">
          {activeTab === 'AUDIT' && (
            <div className="space-y-4">
              <div className="bg-emerald-50 border border-emerald-300 rounded-2xl p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
                  <div>
                    <h4 className="text-sm font-bold text-emerald-950">
                      സുരക്ഷാ ഓഡിറ്റ് വിജയകരമായി പൂർത്തിയായി (10/10 PASS)
                    </h4>
                    <p className="text-xs text-emerald-800">
                      അനധികൃത പ്രവേശനം തടയപ്പെട്ടു. സാമ്പത്തിക രേഖകൾ സൂപ്പർ അഡ്മിന് മാത്രം പ്രാപ്യം.
                    </p>
                  </div>
                </div>
                <span className="font-mono font-bold text-xs bg-emerald-200 text-emerald-950 px-3 py-1 rounded-full">
                  VERIFIED
                </span>
              </div>

              {/* Checks list */}
              <div className="divide-y divide-slate-100 max-h-96 overflow-y-auto pr-1">
                {auditChecks.map((chk) => (
                  <div key={chk.id} className="py-3 flex items-start justify-between gap-3">
                    <div className="flex items-start gap-2.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <div>
                        <div className="text-xs font-bold text-slate-900">{chk.title}</div>
                        <div className="text-[11px] text-slate-500 mt-0.5">{chk.desc}</div>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200 shrink-0">
                      PASS
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'PIN' && (
            <form onSubmit={handleChangePin} className="space-y-4 max-w-md mx-auto py-2">
              {pinMsg && (
                <div
                  className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
                    pinMsg.isError
                      ? 'bg-rose-50 text-rose-800 border border-rose-200'
                      : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                  }`}
                >
                  {pinMsg.isError ? (
                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                  ) : (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  )}
                  <span>{pinMsg.text}</span>
                </div>
              )}

              {/* Current PIN */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  നിലവിലെ സെക്യൂരിറ്റി പിൻ *
                </label>
                <div className="relative">
                  <input
                    type={showCurrentPin ? 'text' : 'password'}
                    required
                    value={currentPin}
                    onChange={(e) => setCurrentPin(e.target.value)}
                    placeholder="നിലവിലെ പിൻ നൽകുക"
                    className="w-full pl-3 pr-10 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                  />
                  <button
                    type="button"
                    onClick={() => setShowCurrentPin(!showCurrentPin)}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    {showCurrentPin ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* New PIN */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  പുതിയ സെക്യൂരിറ്റി പിൻ *
                </label>
                <div className="relative">
                  <input
                    type={showNewPin ? 'text' : 'password'}
                    required
                    value={newPin}
                    onChange={(e) => setNewPin(e.target.value)}
                    placeholder="പുതിയ പിൻ (കുറഞ്ഞത് 4 അക്കങ്ങൾ)"
                    className="w-full pl-3 pr-10 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPin(!showNewPin)}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    {showNewPin ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* Confirm New PIN */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  പുതിയ പിൻ സ്ഥിരീകരിക്കുക *
                </label>
                <input
                  type="password"
                  required
                  value={confirmPin}
                  onChange={(e) => setConfirmPin(e.target.value)}
                  placeholder="പുതിയ പിൻ വീണ്ടും ടൈപ്പ് ചെയ്യുക"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  റദ്ദാക്കുക
                </button>
                <button
                  type="submit"
                  disabled={isChangingPin}
                  className="px-5 py-2 rounded-xl text-xs font-bold bg-linear-to-r from-red-900 to-amber-800 text-white hover:from-red-950 hover:to-amber-900 transition shadow-sm cursor-pointer disabled:opacity-50"
                >
                  {isChangingPin ? 'അപ്‌ഡേറ്റ് ചെയ്യുന്നു...' : 'പിൻ മാറ്റുക'}
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-50 border-t border-slate-200 px-6 py-3 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-1.5 text-emerald-800 font-bold">
            <UserCheck className="w-4 h-4 text-emerald-600" />
            <span>സൂപ്പർ അഡ്മിൻ സംരക്ഷണം സജീവം</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-xs font-bold text-slate-700 hover:text-slate-900 cursor-pointer"
          >
            ക്ലോസ് ചെയ്യുക
          </button>
        </div>
      </div>
    </div>
  );
};
