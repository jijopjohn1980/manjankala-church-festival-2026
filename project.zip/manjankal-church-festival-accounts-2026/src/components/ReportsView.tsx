import React, { useState } from 'react';
import { YearAccountingData, FestivalYear } from '../types/festival';
import { CHURCH_DETAILS } from '../utils/storage';
import { formatINR, numberToMalayalamWords } from '../utils/numberToMalayalamWords';
import { exportFestivalToExcel } from '../utils/exportExcel';
import { generateAndDownloadPdf, openNativePrintToPdf } from '../utils/exportPdf';
import {
  FileSpreadsheet,
  Printer,
  Calendar,
  Layers,
  ArrowRight,
  TrendingUp,
  TrendingDown,
  Scale,
  Sparkles,
  Download,
  CheckCircle,
  AlertCircle,
  Loader2,
  FileText,
} from 'lucide-react';

interface ReportsViewProps {
  data: YearAccountingData;
  year: FestivalYear;
}

export const ReportsView: React.FC<ReportsViewProps> = ({ data, year }) => {
  const [activeSubTab, setActiveSubTab] = useState<'COMPLETE' | 'DAILY' | 'MONTHLY' | 'HEADINGS'>('COMPLETE');
  const [selectedDay, setSelectedDay] = useState('');
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [pdfFeedback, setPdfFeedback] = useState<{
    type: 'success' | 'error';
    message: string;
    blobUrl?: string;
    fileName?: string;
  } | null>(null);

  // Calculations
  const totalIncome = data.incomes.reduce((acc, i) => acc + i.amount, 0);
  const totalExpense = data.expenses.reduce((acc, e) => acc + e.amount, 0);
  const netBalance = totalIncome - totalExpense;

  // Heading-wise income
  const incomeHeadingsMap: Record<string, { name: string; amount: number; count: number }> = {};
  data.headings
    .filter((h) => h.type === 'INCOME')
    .forEach((h) => {
      incomeHeadingsMap[h.name] = { name: h.name, amount: 0, count: 0 };
    });
  data.incomes.forEach((i) => {
    if (!incomeHeadingsMap[i.headingName]) {
      incomeHeadingsMap[i.headingName] = { name: i.headingName, amount: 0, count: 0 };
    }
    incomeHeadingsMap[i.headingName].amount += i.amount;
    incomeHeadingsMap[i.headingName].count += 1;
  });

  // Heading-wise expense
  const expenseHeadingsMap: Record<string, { name: string; amount: number; count: number }> = {};
  data.headings
    .filter((h) => h.type === 'EXPENSE')
    .forEach((h) => {
      expenseHeadingsMap[h.name] = { name: h.name, amount: 0, count: 0 };
    });
  data.expenses.forEach((e) => {
    if (!expenseHeadingsMap[e.headingName]) {
      expenseHeadingsMap[e.headingName] = { name: e.headingName, amount: 0, count: 0 };
    }
    expenseHeadingsMap[e.headingName].amount += e.amount;
    expenseHeadingsMap[e.headingName].count += 1;
  });

  // Daily Breakdown
  const allDates = Array.from(
    new Set([...data.incomes.map((i) => i.date), ...data.expenses.map((e) => e.date)])
  ).sort();

  const dailyData = allDates.map((date) => {
    const dayIncomes = data.incomes.filter((i) => i.date === date);
    const dayExpenses = data.expenses.filter((e) => e.date === date);
    const dayIncTotal = dayIncomes.reduce((sum, i) => sum + i.amount, 0);
    const dayExpTotal = dayExpenses.reduce((sum, e) => sum + e.amount, 0);
    return {
      date,
      incomes: dayIncomes,
      expenses: dayExpenses,
      incomeTotal: dayIncTotal,
      expenseTotal: dayExpTotal,
      balance: dayIncTotal - dayExpTotal,
    };
  });

  // Monthly Breakdown
  const monthMap: Record<string, { monthStr: string; income: number; expense: number }> = {};
  data.incomes.forEach((i) => {
    const m = i.date.substring(0, 7); // YYYY-MM
    if (!monthMap[m]) monthMap[m] = { monthStr: m, income: 0, expense: 0 };
    monthMap[m].income += i.amount;
  });
  data.expenses.forEach((e) => {
    const m = e.date.substring(0, 7);
    if (!monthMap[m]) monthMap[m] = { monthStr: m, income: 0, expense: 0 };
    monthMap[m].expense += e.amount;
  });
  const monthlyList = Object.values(monthMap).sort((a, b) => a.monthStr.localeCompare(b.monthStr));

  const handleExcelExport = () => {
    exportFestivalToExcel(year, data);
  };

  const handlePrintReport = () => {
    openNativePrintToPdf({
      year,
      data,
      reportType: activeSubTab,
      selectedDay,
    });
  };

  const handleDownloadPdf = async (fullDetails: boolean = false) => {
    setIsGeneratingPdf(true);
    setPdfFeedback(null);
    try {
      const res = await generateAndDownloadPdf({
        year,
        data,
        reportType: fullDetails ? 'ALL_DETAILS' : activeSubTab,
        selectedDay,
      });

      if (res.success) {
        setPdfFeedback({
          type: 'success',
          message: `PDF വിജയകരമായി തയ്യാറാക്കി: "${res.fileName}". ഡൗൺലോഡ് ആരംഭിച്ചില്ലെങ്കിൽ നേരിട്ട് സേവ് ചെയ്യാൻ താഴെയുള്ള ബട്ടൺ ക്ലിക്ക് ചെയ്യുക.`,
          blobUrl: res.blobUrl,
          fileName: res.fileName,
        });
      } else {
        setPdfFeedback({
          type: 'error',
          message: res.error || 'PDF തയ്യാറാക്കുന്നതിൽ തടസ്സം നേരിട്ടു.',
        });
      }
    } catch (err: any) {
      setPdfFeedback({
        type: 'error',
        message: 'PDF നിർമ്മാണത്തിൽ അപ്രതീക്ഷിത തകരാർ നേരിട്ടു.',
      });
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner (hidden in print) */}
      <div className="no-print bg-white rounded-3xl p-6 shadow-sm border border-indigo-100 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-100 text-indigo-950 mb-2">
            <Scale className="w-3.5 h-3.5 text-indigo-700" />
            <span>പെരുന്നാൾ വരവ് ചിലവ് റിപ്പോർട്ടുകൾ & ഓഡിറ്റ്</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900">
            {year.yearName} - ഔദ്യോഗിക കണക്ക് പുസ്തകം
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            ദിവസേനയുള്ള കണക്ക്, മാസ റിപ്പോർട്ട്, ശീർഷക സംഗ്രഹം, സമ്പൂർണ്ണ ഓഡിറ്റ് സ്റ്റേറ്റ്‌മെന്റ്.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Excel Export Button */}
          <button
            type="button"
            onClick={handleExcelExport}
            className="inline-flex items-center gap-2 bg-emerald-700 hover:bg-emerald-800 text-white px-4 py-2.5 rounded-2xl text-xs font-bold shadow-sm transition cursor-pointer"
            title="എക്സൽ സ്പ്രെഡ്ഷീറ്റ് ഡൗൺലോഡ് ചെയ്യുക"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
            <span>എക്സൽ ഡൗൺലോഡ് (Excel)</span>
          </button>

          {/* PDF Download Button (Current View) */}
          <button
            type="button"
            disabled={isGeneratingPdf}
            onClick={() => handleDownloadPdf(false)}
            className="inline-flex items-center gap-2 bg-indigo-700 hover:bg-indigo-800 disabled:bg-indigo-400 text-white px-4 py-2.5 rounded-2xl text-xs font-bold shadow-sm transition cursor-pointer"
            title="തിരഞ്ഞെടുത്ത റിപ്പോർട്ട് PDF ആയി ഡൗൺലോഡ് ചെയ്യുക"
          >
            {isGeneratingPdf ? (
              <Loader2 className="w-4 h-4 text-indigo-200 animate-spin" />
            ) : (
              <Download className="w-4 h-4 text-indigo-200" />
            )}
            <span>{isGeneratingPdf ? 'PDF തയ്യാറാക്കുന്നു...' : 'PDF ഡൗൺലോഡ് ചെയ്യുക'}</span>
          </button>

          {/* Full Detailed Register PDF Download Button */}
          <button
            type="button"
            disabled={isGeneratingPdf}
            onClick={() => handleDownloadPdf(true)}
            className="inline-flex items-center gap-2 bg-amber-800 hover:bg-amber-900 disabled:bg-amber-500 text-white px-3.5 py-2.5 rounded-2xl text-xs font-bold shadow-sm transition cursor-pointer"
            title="എല്ലാ ഇടപാടുകളും ഉൾപ്പെടുത്തിയ സമ്പൂർണ്ണ കണക്ക് പുസ്തകം PDF"
          >
            <FileText className="w-4 h-4 text-amber-200" />
            <span>സമ്പൂർണ്ണ കണക്ക് പുസ്തകം (PDF)</span>
          </button>

          {/* Print / System Preview Button */}
          <button
            type="button"
            onClick={handlePrintReport}
            className="inline-flex items-center gap-2 bg-slate-800 hover:bg-slate-900 text-white px-3.5 py-2.5 rounded-2xl text-xs font-bold shadow-sm transition cursor-pointer"
            title="പ്രിന്ററിലേക്ക് നേരിട്ട് പ്രിന്റ് ചെയ്യുക / പ്രിവ്യൂ"
          >
            <Printer className="w-4 h-4 text-slate-300" />
            <span>പ്രിന്റ് / പ്രിവ്യൂ</span>
          </button>
        </div>
      </div>

      {/* PDF Download Feedback Message */}
      {pdfFeedback && (
        <div
          className={`no-print p-4 rounded-2xl border text-xs flex items-center justify-between gap-3 shadow-xs transition-all ${
            pdfFeedback.type === 'success'
              ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
              : 'bg-rose-50 border-rose-300 text-rose-950'
          }`}
        >
          <div className="flex items-start gap-2.5">
            {pdfFeedback.type === 'success' ? (
              <CheckCircle className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-5 h-5 text-rose-700 shrink-0 mt-0.5" />
            )}
            <div>
              <span className="font-semibold leading-relaxed block">{pdfFeedback.message}</span>
              {pdfFeedback.blobUrl && (
                <div className="mt-2 flex items-center gap-2">
                  <a
                    href={pdfFeedback.blobUrl}
                    download={pdfFeedback.fileName || 'report.pdf'}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 bg-emerald-700 hover:bg-emerald-800 text-white px-3 py-1.5 rounded-xl text-xs font-bold shadow-2xs transition"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>ഫയൽ നേരിട്ട് സേവ് ചെയ്യുക / തുറക്കുക</span>
                  </a>
                </div>
              )}
            </div>
          </div>
          <button
            type="button"
            onClick={() => setPdfFeedback(null)}
            className="text-slate-500 hover:text-slate-800 font-bold px-2 py-1 rounded-md text-xs cursor-pointer shrink-0"
          >
            ✕
          </button>
        </div>
      )}

      {/* Sub Tabs (hidden in print) */}
      <div className="no-print flex border-b border-slate-200 overflow-x-auto">
        <button
          onClick={() => setActiveSubTab('COMPLETE')}
          className={`pb-3 px-5 text-xs font-bold border-b-2 transition cursor-pointer shrink-0 ${
            activeSubTab === 'COMPLETE'
              ? 'border-indigo-600 text-indigo-900 bg-indigo-50/60 rounded-t-xl'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          📜 സമ്പൂർണ്ണ പെരുന്നാൾ സ്റ്റേറ്റ്‌മെന്റ്
        </button>
        <button
          onClick={() => setActiveSubTab('DAILY')}
          className={`pb-3 px-5 text-xs font-bold border-b-2 transition cursor-pointer shrink-0 ${
            activeSubTab === 'DAILY'
              ? 'border-indigo-600 text-indigo-900 bg-indigo-50/60 rounded-t-xl'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          📅 ദിവസേനയുള്ള കണക്കുകൾ (Daily)
        </button>
        <button
          onClick={() => setActiveSubTab('MONTHLY')}
          className={`pb-3 px-5 text-xs font-bold border-b-2 transition cursor-pointer shrink-0 ${
            activeSubTab === 'MONTHLY'
              ? 'border-indigo-600 text-indigo-900 bg-indigo-50/60 rounded-t-xl'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          🗓️ മാസ തിരിച്ചുള്ള കണക്കുകൾ (Monthly)
        </button>
        <button
          onClick={() => setActiveSubTab('HEADINGS')}
          className={`pb-3 px-5 text-xs font-bold border-b-2 transition cursor-pointer shrink-0 ${
            activeSubTab === 'HEADINGS'
              ? 'border-indigo-600 text-indigo-900 bg-indigo-50/60 rounded-t-xl'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          🏷️ ശീർഷക സംഗ്രഹം (Heading-wise)
        </button>
      </div>

      {/* 1. Complete Festival Statement (Printable & Viewable) */}
      {activeSubTab === 'COMPLETE' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200">
          
          {/* Printable Report Header */}
          <div className="text-center pb-6 border-b-2 border-red-950/20 mb-6 relative">
            <div className="flex items-center justify-center gap-4 mb-2">
              <img
                src={CHURCH_DETAILS.logoUrl}
                alt="Church Logo"
                className="w-16 h-16 sm:w-20 sm:h-20 object-contain rounded-full border border-amber-400 p-0.5 bg-white shadow-xs"
              />
              <div className="text-left">
                <div className="text-xs font-bold text-amber-900">
                  {CHURCH_DETAILS.subMl}
                </div>
                <h1 className="text-lg sm:text-2xl font-black text-red-950">
                  {CHURCH_DETAILS.nameMl}
                </h1>
                <div className="text-xs sm:text-sm font-extrabold text-amber-800">
                  {year.yearName} - സമ്പൂർണ്ണ വരവ് ചിലവ് കണക്കുകൾ (Income & Expenditure Statement)
                </div>
              </div>
            </div>
            <div className="text-xs text-slate-700 font-bold bg-amber-50 inline-block px-3 py-1 rounded-full border border-amber-200 mt-1">
              പെരുന്നാൾ കാലാവധി: <span className="text-amber-900 font-extrabold">22-11-2026 to 10-12-2026</span>
            </div>
          </div>

          {/* Side by Side Ledger: Income vs Expense */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Left: Income Ledger */}
            <div className="border border-emerald-200 rounded-2xl overflow-hidden">
              <div className="bg-emerald-800 text-white p-3.5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-emerald-300" />
                  <span className="font-bold text-sm">വരവുകൾ (Income)</span>
                </div>
                <span className="text-xs bg-emerald-700 px-2 py-0.5 rounded-full font-bold">
                  {data.incomes.length} രസീതുകൾ
                </span>
              </div>

              <div className="p-4 space-y-2.5 max-h-[460px] overflow-y-auto">
                {Object.values(incomeHeadingsMap).map((h, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between text-xs py-1.5 border-b border-slate-100"
                  >
                    <span className="text-slate-800 font-medium">
                      {i + 1}. {h.name} ({h.count})
                    </span>
                    <span className="font-bold text-emerald-800 text-sm">
                      {formatINR(h.amount)}
                    </span>
                  </div>
                ))}
              </div>

              <div className="bg-emerald-50 p-3.5 border-t border-emerald-200 flex items-center justify-between font-extrabold text-sm text-emerald-950">
                <span>ആകെ വരവ് (Total Income):</span>
                <span className="text-base text-emerald-800">{formatINR(totalIncome)}</span>
              </div>
            </div>

            {/* Right: Expense Ledger */}
            <div className="border border-rose-200 rounded-2xl overflow-hidden">
              <div className="bg-rose-900 text-white p-3.5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <TrendingDown className="w-4 h-4 text-rose-300" />
                  <span className="font-bold text-sm">ചിലവുകൾ (Expenditure)</span>
                </div>
                <span className="text-xs bg-rose-800 px-2 py-0.5 rounded-full font-bold">
                  {data.expenses.length} വൗച്ചറുകൾ
                </span>
              </div>

              <div className="p-4 space-y-2.5 max-h-[460px] overflow-y-auto">
                {Object.values(expenseHeadingsMap).map((h, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between text-xs py-1.5 border-b border-slate-100"
                  >
                    <span className="text-slate-800 font-medium">
                      {i + 1}. {h.name} ({h.count})
                    </span>
                    <span className="font-bold text-rose-800 text-sm">
                      {formatINR(h.amount)}
                    </span>
                  </div>
                ))}
              </div>

              <div className="bg-rose-50 p-3.5 border-t border-rose-200 flex items-center justify-between font-extrabold text-sm text-rose-950">
                <span>ആകെ ചിലവ് (Total Expenditure):</span>
                <span className="text-base text-rose-800">{formatINR(totalExpense)}</span>
              </div>
            </div>

          </div>

          {/* Final Festival Balance Highlight Box */}
          <div className="mt-6 p-5 rounded-2xl bg-linear-to-r from-amber-50 via-white to-amber-50 border-2 border-amber-600/60 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <div className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                അന്തിമ പെരുന്നാൾ നീക്കിയിരിപ്പ് / ബാക്കി (Net Festival Surplus / Balance)
              </div>
              <div className="text-xs text-slate-700 font-medium mt-1">
                {numberToMalayalamWords(netBalance)}
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-black text-amber-950 bg-amber-200/60 px-5 py-2 rounded-xl border border-amber-300 shrink-0">
              {formatINR(netBalance)}
            </div>
          </div>

          {/* Official Signatures & Verification Area */}
          <div className="mt-12 pt-8 border-t border-slate-300 grid grid-cols-2 sm:grid-cols-4 gap-6 text-center text-xs">
            <div>
              <div className="h-12 border-b border-dotted border-slate-400 mx-auto w-32" />
              <p className="font-bold text-slate-800 mt-2">ജനറൽ കൺവീനർ</p>
              <p className="text-[10px] text-slate-500">പെരുന്നാൾ സമിതി</p>
            </div>
            <div>
              <div className="h-12 border-b border-dotted border-slate-400 mx-auto w-32" />
              <p className="font-bold text-slate-800 mt-2">ട്രഷറർ</p>
              <p className="text-[10px] text-slate-500">പെരുന്നാൾ ഫണ്ട്</p>
            </div>
            <div>
              <div className="h-12 border-b border-dotted border-slate-400 mx-auto w-32" />
              <p className="font-bold text-slate-800 mt-2">ഇടവക ട്രസ്റ്റിമാർ</p>
              <p className="text-[10px] text-slate-500">പരിശോധിച്ച് സാക്ഷ്യപ്പെടുത്തി</p>
            </div>
            <div>
              <div className="h-12 border-b border-dotted border-slate-400 mx-auto w-32" />
              <p className="font-bold text-slate-800 mt-2">വികാരി</p>
              <p className="text-[10px] text-slate-500">പള്ളി സീൽ & അംഗീകാരം</p>
            </div>
          </div>

          <div className="mt-8 text-center text-[11px] text-slate-400 italic">
            സ്ഥലം: മഞ്ഞക്കാല • തീയതി: {new Date().toLocaleDateString('en-GB')}
          </div>
        </div>
      )}

      {/* 2. Daily Report View */}
      {activeSubTab === 'DAILY' && (
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200 space-y-4">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h3 className="font-bold text-slate-900 text-base">
                ദിവസേനയുള്ള വരവ് - ചിലവ് കണക്കുകൾ (Daily Log)
              </h3>
              <p className="text-xs text-slate-500">
                ഓരോ പെരുന്നാൾ ദിവസത്തെയും വരവും ചിലവും നീക്കിയിരിപ്പും.
              </p>
            </div>
            <span className="text-xs font-bold text-slate-600 bg-slate-100 px-3 py-1 rounded-full">
              ആകെ {dailyData.length} ദിവസങ്ങൾ
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 text-[11px] font-bold text-slate-600 uppercase border-b border-slate-200">
                  <th className="py-3 px-4">തീയതി</th>
                  <th className="py-3 px-4 text-right">ദിവസ വരവ് (₹)</th>
                  <th className="py-3 px-4 text-right">ദിവസ ചിലവ് (₹)</th>
                  <th className="py-3 px-4 text-right">ദിവസ നീക്കിയിരിപ്പ് (₹)</th>
                  <th className="py-3 px-4 text-center">വിശദാംശങ്ങൾ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {dailyData.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-slate-400">
                      ഇടപാടുകൾ ഒന്നും രേഖപ്പെടുത്തിയിട്ടില്ല.
                    </td>
                  </tr>
                ) : (
                  dailyData.map((d) => (
                    <tr key={d.date} className="hover:bg-slate-50">
                      <td className="py-3 px-4 font-bold text-slate-800">{d.date}</td>
                      <td className="py-3 px-4 text-right font-bold text-emerald-700">
                        {formatINR(d.incomeTotal)}
                      </td>
                      <td className="py-3 px-4 text-right font-bold text-rose-700">
                        {formatINR(d.expenseTotal)}
                      </td>
                      <td className="py-3 px-4 text-right font-extrabold text-slate-900">
                        {formatINR(d.balance)}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <button
                          onClick={() => setSelectedDay(selectedDay === d.date ? '' : d.date)}
                          className="text-[11px] font-bold text-indigo-700 hover:underline cursor-pointer"
                        >
                          {selectedDay === d.date ? 'മറയ്ക്കുക' : 'ഇടപാടുകൾ കാണുക'}
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Expanded Selected Day Detail */}
          {selectedDay && (
            <div className="mt-4 p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
              <h4 className="font-bold text-slate-900 mb-2">
                {selectedDay} തീയതിയിലെ വിശദമായ വിവരങ്ങൾ:
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <div className="font-bold text-emerald-800 mb-1">വരവുകൾ:</div>
                  {data.incomes.filter((i) => i.date === selectedDay).map((i) => (
                    <div key={i.id} className="py-1 border-b border-slate-200 flex justify-between">
                      <span>{i.receiptNumber}{i.donorName ? ` - ${i.donorName}` : ''} ({i.headingName})</span>
                      <strong className="text-emerald-700">{formatINR(i.amount)}</strong>
                    </div>
                  ))}
                  {data.incomes.filter((i) => i.date === selectedDay).length === 0 && (
                    <span className="text-slate-400 italic">വരവുകൾ ഇല്ല</span>
                  )}
                </div>
                <div>
                  <div className="font-bold text-rose-800 mb-1">ചിലവുകൾ:</div>
                  {data.expenses.filter((e) => e.date === selectedDay).map((e) => (
                    <div key={e.id} className="py-1 border-b border-slate-200 flex justify-between">
                      <span>{e.voucherNumber} - {e.paidTo} ({e.headingName})</span>
                      <strong className="text-rose-700">{formatINR(e.amount)}</strong>
                    </div>
                  ))}
                  {data.expenses.filter((e) => e.date === selectedDay).length === 0 && (
                    <span className="text-slate-400 italic">ചിലവുകൾ ഇല്ല</span>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 3. Monthly Report View */}
      {activeSubTab === 'MONTHLY' && (
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200 space-y-4">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h3 className="font-bold text-slate-900 text-base">
                മാസ തിരിച്ചുള്ള പെരുന്നാൾ റിപ്പോർട്ട് (Monthly Statement)
              </h3>
              <p className="text-xs text-slate-500">
                പെരുന്നാൾ മുന്നൊരുക്ക മാസങ്ങളിലെയും പെരുന്നാൾ മാസങ്ങളിലെയും വരവ് ചിലവ് താരതമ്യം.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {monthlyList.map((m) => {
              const diff = m.income - m.expense;
              return (
                <div
                  key={m.monthStr}
                  className="p-5 rounded-2xl border border-slate-200 bg-slate-50/60 space-y-3"
                >
                  <div className="font-bold text-sm text-slate-900 pb-2 border-b border-slate-200 flex items-center justify-between">
                    <span>മാസം: {m.monthStr}</span>
                    <span className="text-xs font-semibold text-slate-500">ക്യാഷ് ഫ്ലോ</span>
                  </div>
                  <div className="space-y-1.5 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-600">ആകെ വരവ്:</span>
                      <span className="font-bold text-emerald-700">{formatINR(m.income)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-600">ആകെ ചിലവ്:</span>
                      <span className="font-bold text-rose-700">{formatINR(m.expense)}</span>
                    </div>
                    <div className="flex justify-between pt-2 border-t border-slate-200 font-extrabold text-slate-900">
                      <span>നീക്കിയിരിപ്പ്:</span>
                      <span className={diff >= 0 ? 'text-emerald-800' : 'text-red-700'}>
                        {formatINR(diff)}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 4. Heading-wise Breakdown */}
      {activeSubTab === 'HEADINGS' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Income Headings */}
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-emerald-100">
            <h3 className="font-bold text-base text-slate-900 mb-4 pb-2 border-b border-slate-100 flex items-center justify-between">
              <span>വരവ് ശീർഷക സംഗ്രഹം</span>
              <span className="text-xs font-bold text-emerald-800">{formatINR(totalIncome)}</span>
            </h3>
            <div className="space-y-2">
              {Object.values(incomeHeadingsMap).map((h, i) => (
                <div key={i} className="flex justify-between text-xs py-1.5 border-b border-slate-50">
                  <span className="text-slate-700 font-medium">{h.name}</span>
                  <span className="font-bold text-emerald-800">{formatINR(h.amount)}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Expense Headings */}
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-rose-100">
            <h3 className="font-bold text-base text-slate-900 mb-4 pb-2 border-b border-slate-100 flex items-center justify-between">
              <span>ചിലവ് ശീർഷക സംഗ്രഹം</span>
              <span className="text-xs font-bold text-rose-800">{formatINR(totalExpense)}</span>
            </h3>
            <div className="space-y-2">
              {Object.values(expenseHeadingsMap).map((h, i) => (
                <div key={i} className="flex justify-between text-xs py-1.5 border-b border-slate-50">
                  <span className="text-slate-700 font-medium">{h.name}</span>
                  <span className="font-bold text-rose-800">{formatINR(h.amount)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
