import React, { useState } from 'react';
import {
  Heading,
  IncomeTransaction,
  ExpenseTransaction,
  FestivalYear,
} from '../types/festival';
import { formatINR, numberToMalayalamWords } from '../utils/numberToMalayalamWords';
import { PrintReceiptModal } from './PrintReceiptModal';
import { PrintVoucherModal } from './PrintVoucherModal';
import {
  X,
  Printer,
  Search,
  Calendar,
  Layers,
  TrendingUp,
  TrendingDown,
  ArrowRight,
  FileText,
  Receipt,
} from 'lucide-react';

interface HeadingTransactionsModalProps {
  heading: Heading;
  incomes: IncomeTransaction[];
  expenses: ExpenseTransaction[];
  year: FestivalYear;
  onClose: () => void;
  filterLabel?: string;
  headings?: Heading[];
}

export const HeadingTransactionsModal: React.FC<HeadingTransactionsModalProps> = ({
  heading,
  incomes,
  expenses,
  year,
  onClose,
  filterLabel,
  headings = [],
}) => {
  const isIncome = heading.type === 'INCOME';
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPrintIncome, setSelectedPrintIncome] = useState<IncomeTransaction | null>(null);
  const [selectedPrintExpense, setSelectedPrintExpense] = useState<ExpenseTransaction | null>(null);

  // Filter items under this heading (including uncategorized group)
  const relevantIncomes = isIncome
    ? (heading.id === 'uncategorized-income'
        ? incomes.filter(
            (i) =>
              !headings.some(
                (h) => h.type === 'INCOME' && (h.id === i.headingId || h.name === i.headingName)
              )
          )
        : incomes.filter((i) => i.headingId === heading.id || i.headingName === heading.name))
    : [];

  const relevantExpenses = !isIncome
    ? (heading.id === 'uncategorized-expense'
        ? expenses.filter(
            (e) =>
              !headings.some(
                (h) => h.type === 'EXPENSE' && (h.id === e.headingId || h.name === e.headingName)
              )
          )
        : expenses.filter((e) => e.headingId === heading.id || e.headingName === heading.name))
    : [];

  const totalAmount = isIncome
    ? relevantIncomes.reduce((sum, i) => sum + i.amount, 0)
    : relevantExpenses.reduce((sum, e) => sum + e.amount, 0);

  const totalCount = isIncome ? relevantIncomes.length : relevantExpenses.length;

  // Search filtered items
  const filteredIncomes = relevantIncomes.filter(
    (i) =>
      (i.donorName && i.donorName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      i.receiptNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      i.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (i.donorAddress && i.donorAddress.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const filteredExpenses = relevantExpenses.filter(
    (e) =>
      e.paidTo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.voucherNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (e.referenceNumber && e.referenceNumber.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-4xl w-full p-6 shadow-2xl border border-amber-300 relative my-6 max-h-[90vh] flex flex-col">
        {/* Modal Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-200">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span
                className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold ${
                  isIncome
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-rose-100 text-rose-800'
                }`}
              >
                {isIncome ? (
                  <>
                    <TrendingUp className="w-3.5 h-3.5" /> വരവ് ശീർഷകം (Income Heading)
                  </>
                ) : (
                  <>
                    <TrendingDown className="w-3.5 h-3.5" /> ചിലവ് ശീർഷകം (Expense Heading)
                  </>
                )}
              </span>
              {filterLabel && (
                <span className="text-[11px] font-medium text-amber-900 bg-amber-100 px-2.5 py-0.5 rounded-full">
                  ഫിൽട്ടർ: {filterLabel}
                </span>
              )}
            </div>
            <h3 className="text-xl font-black text-slate-900">{heading.name}</h3>
            {heading.description && (
              <p className="text-xs text-slate-500 mt-0.5">{heading.description}</p>
            )}
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Amount Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 my-4">
          <div
            className={`p-4 rounded-2xl border ${
              isIncome
                ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
                : 'bg-rose-50/70 border-rose-200 text-rose-950'
            }`}
          >
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block">
              {isIncome ? 'ആകെ ശേഖരിച്ച തുക' : 'ആകെ ചിലവായ തുക'}
            </span>
            <span
              className={`text-2xl font-black ${
                isIncome ? 'text-emerald-800' : 'text-rose-800'
              }`}
            >
              {formatINR(totalAmount)}
            </span>
          </div>

          <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50/70 text-slate-800">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block">
              {isIncome ? 'ആകെ രസീതുകൾ' : 'ആകെ വൗച്ചറുകൾ'}
            </span>
            <span className="text-2xl font-black text-slate-900">
              {totalCount} <span className="text-sm font-semibold text-slate-500">എണ്ണം</span>
            </span>
          </div>

          <div className="p-4 rounded-2xl border border-amber-200 bg-amber-50/60 text-amber-950 flex flex-col justify-center">
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-900 block">
              തുക അക്ഷരങ്ങളിൽ
            </span>
            <span className="text-xs font-bold text-amber-900 mt-0.5 line-clamp-2">
              {numberToMalayalamWords(totalAmount)}
            </span>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative mb-3">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder={
              isIncome
                ? 'ദാതാവിന്റെ പേര്, രസീത് നമ്പർ, വിവരണം തിരയുക...'
                : 'വ്യക്തി / സ്ഥാപനം, വൗച്ചർ നമ്പർ, ചിലവ് തിരയുക...'
            }
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
          />
        </div>

        {/* Scrollable Transaction List */}
        <div className="flex-1 overflow-y-auto border border-slate-200 rounded-2xl">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 text-[11px] font-bold text-slate-600 uppercase tracking-wider border-b border-slate-200 sticky top-0">
                <th className="py-2.5 px-3">നമ്പർ</th>
                <th className="py-2.5 px-3">തീയതി</th>
                <th className="py-2.5 px-3">
                  {isIncome ? 'Name of Donor / Contributor' : 'തുക നൽകിയ വ്യക്തി / സ്ഥാപനം'}
                </th>
                <th className="py-2.5 px-3">വിവരണം / രീതി</th>
                <th className="py-2.5 px-3 text-right">തുക (രൂപ)</th>
                <th className="py-2.5 px-3 text-center">പ്രിന്റ്</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {isIncome ? (
                filteredIncomes.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-400">
                      ഈ ശീർഷകത്തിൽ വരവുകൾ ഒന്നും കണ്ടെത്തിയില്ല.
                    </td>
                  </tr>
                ) : (
                  filteredIncomes.map((item) => (
                    <tr key={item.id} className="hover:bg-emerald-50/30 transition">
                      <td className="py-3 px-3 font-mono font-bold text-slate-900">
                        {item.receiptNumber}
                      </td>
                      <td className="py-3 px-3 text-slate-600 whitespace-nowrap">{item.date}</td>
                      <td className="py-3 px-3">
                        <div className="font-bold text-slate-900">{item.donorName || '-'}</div>
                        {item.donorAddress && (
                          <div className="text-[10px] text-slate-500">{item.donorAddress}</div>
                        )}
                      </td>
                      <td className="py-3 px-3 max-w-xs">
                        <div className="line-clamp-1">{item.description || '-'}</div>
                        <div className="text-[10px] text-slate-400">
                          {item.paymentMode === 'CASH'
                            ? 'പണമായി'
                            : item.paymentMode === 'UPI'
                            ? 'UPI'
                            : item.paymentMode === 'BANK'
                            ? 'ബാങ്ക്'
                            : 'ചെക്ക്'}
                          {item.referenceNumber && ` (${item.referenceNumber})`}
                        </div>
                      </td>
                      <td className="py-3 px-3 text-right font-black text-emerald-800 text-sm whitespace-nowrap">
                        {formatINR(item.amount)}
                      </td>
                      <td className="py-3 px-3 text-center">
                        <button
                          onClick={() => setSelectedPrintIncome(item)}
                          className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-bold bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-lg transition cursor-pointer"
                          title="രസീത് പ്രിന്റ് ചെയ്യുക"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>രസീത്</span>
                        </button>
                      </td>
                    </tr>
                  ))
                )
              ) : filteredExpenses.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400">
                    ഈ ശീർഷകത്തിൽ ചിലവുകൾ ഒന്നും കണ്ടെത്തിയില്ല.
                  </td>
                </tr>
              ) : (
                filteredExpenses.map((item) => (
                  <tr key={item.id} className="hover:bg-rose-50/30 transition">
                    <td className="py-3 px-3 font-mono font-bold text-slate-900">
                      {item.voucherNumber}
                    </td>
                    <td className="py-3 px-3 text-slate-600 whitespace-nowrap">{item.date}</td>
                    <td className="py-3 px-3 font-bold text-slate-900">{item.paidTo}</td>
                    <td className="py-3 px-3 max-w-xs">
                      <div className="line-clamp-1">{item.description}</div>
                      <div className="text-[10px] text-slate-400">
                        {item.paymentMode === 'CASH'
                          ? 'പണമായി'
                          : item.paymentMode === 'UPI'
                          ? 'UPI'
                          : item.paymentMode === 'BANK'
                          ? 'ബാങ്ക്'
                          : 'ചെക്ക്'}
                        {item.referenceNumber && ` (ബിൽ/Ref: ${item.referenceNumber})`}
                      </div>
                    </td>
                    <td className="py-3 px-3 text-right font-black text-rose-800 text-sm whitespace-nowrap">
                      {formatINR(item.amount)}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <button
                        onClick={() => setSelectedPrintExpense(item)}
                        className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-bold bg-rose-100 hover:bg-rose-200 text-rose-800 rounded-lg transition cursor-pointer"
                        title="വൗച്ചർ പ്രിന്റ് ചെയ്യുക"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>വൗച്ചർ</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-4 mt-3 border-t border-slate-100">
          <div className="text-xs text-slate-500 font-medium">
            കണ്ടെത്തിയ ഇടപാടുകൾ: {isIncome ? filteredIncomes.length : filteredExpenses.length} എണ്ണം
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-900 text-white cursor-pointer transition shadow-xs"
          >
            അടയ്ക്കുക
          </button>
        </div>
      </div>

      {/* Print Modals if triggered from here */}
      {selectedPrintIncome && (
        <PrintReceiptModal
          transaction={selectedPrintIncome}
          year={year}
          onClose={() => setSelectedPrintIncome(null)}
        />
      )}
      {selectedPrintExpense && (
        <PrintVoucherModal
          transaction={selectedPrintExpense}
          year={year}
          onClose={() => setSelectedPrintExpense(null)}
        />
      )}
    </div>
  );
};
