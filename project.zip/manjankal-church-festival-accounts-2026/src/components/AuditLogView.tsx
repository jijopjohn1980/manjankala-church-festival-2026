import React, { useState, useMemo } from 'react';
import { AuditLog } from '../types/festival';
import { ShieldCheck, Search, Filter, Download, Clock, User, AlertCircle, FileText } from 'lucide-react';
import * as XLSX from 'xlsx';

interface AuditLogViewProps {
  logs: AuditLog[];
}

export const AuditLogView: React.FC<AuditLogViewProps> = ({ logs = [] }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState<'ALL' | 'INCOME' | 'EXPENSE' | 'HEADING' | 'SECURITY'>('ALL');

  const filteredLogs = useMemo(() => {
    return logs
      .filter((log) => {
        // Category filter
        if (filterCategory === 'INCOME') {
          if (!log.action.includes('INCOME')) return false;
        } else if (filterCategory === 'EXPENSE') {
          if (!log.action.includes('EXPENSE')) return false;
        } else if (filterCategory === 'HEADING') {
          if (!log.action.includes('HEADING')) return false;
        } else if (filterCategory === 'SECURITY') {
          if (
            !log.action.includes('LOGIN') &&
            !log.action.includes('PIN') &&
            !log.action.includes('BACKUP')
          ) {
            return false;
          }
        }

        // Search term
        if (!searchTerm.trim()) return true;
        const q = searchTerm.toLowerCase();
        return (
          log.summaryMl.toLowerCase().includes(q) ||
          log.action.toLowerCase().includes(q) ||
          (log.userEmail && log.userEmail.toLowerCase().includes(q)) ||
          (log.amount && log.amount.toString().includes(q))
        );
      })
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [logs, filterCategory, searchTerm]);

  // Export Audit Logs to Excel
  const handleExportExcel = () => {
    const rows = filteredLogs.map((l, index) => ({
      'ക്രമ നമ്പർ': index + 1,
      'തീയതിയും സമയവും': new Date(l.timestamp).toLocaleString('en-IN'),
      'പ്രവർത്തനം (Action)': l.action,
      'വിവരണം (Summary)': l.summaryMl,
      'തുക (Amount ₹)': l.amount || '',
      'സൂപ്പർ അഡ്മിൻ (User)': l.userEmail,
    }));

    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'AuditLog');
    XLSX.writeFile(wb, `Audit_Log_Manjakala_Church_2026_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  const getActionBadge = (action: AuditLog['action']) => {
    if (action.includes('INCOME')) {
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
          📥 വരവ് (Income)
        </span>
      );
    }
    if (action.includes('EXPENSE')) {
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-100 text-rose-800 border border-rose-300">
          📤 ചിലവ് (Expense)
        </span>
      );
    }
    if (action.includes('HEADING')) {
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300">
          🏷️ ശീർഷകം (Heading)
        </span>
      );
    }
    if (action === 'LOGIN') {
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800 border border-blue-300">
          🔑 ലോഗിൻ (Login)
        </span>
      );
    }
    if (action === 'FAILED_LOGIN') {
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-red-100 text-red-900 border border-red-300">
          ⚠️ തെറ്റായ ലോഗിൻ ശ്രമം
        </span>
      );
    }
    return (
      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-100 text-slate-800 border border-slate-300">
        🛡️ സുരക്ഷ / ബാക്കപ്പ്
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Audit Integrity Header */}
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-amber-200 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-indigo-50 text-indigo-800 border border-indigo-200 mb-2">
            <ShieldCheck className="w-4 h-4 text-indigo-600" />
            <span>മാറ്റം വരുത്താനാവാത്ത ഓഡിറ്റ് ലോഗ് (Immutable Financial Audit Trail)</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900">
            സാമ്പത്തിക പ്രവർത്തനങ്ങളുടെ സമഗ്ര ഓഡിറ്റ് ലോഗ്
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            വരവുകൾ, ചിലവുകൾ, ശീർഷകങ്ങൾ, ബാക്കപ്പുകൾ, ലോഗിൻ തുടങ്ങിയ എല്ലാ മാറ്റങ്ങളും തീയതിയും സമയവും സഹിതം രേഖപ്പെടുത്തിയിരിക്കുന്നു.
          </p>
        </div>

        <button
          type="button"
          onClick={handleExportExcel}
          disabled={filteredLogs.length === 0}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs bg-emerald-700 hover:bg-emerald-800 text-white transition shadow-sm cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Download className="w-4 h-4" />
          <span>Excel-ലേക്ക് ഡൗൺലോഡ് ചെയ്യുക</span>
        </button>
      </div>

      {/* Filters and Search Bar */}
      <div className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Search */}
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="ലോഗ് വിവരണം, തുക, തീയതി..."
            className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
          />
        </div>

        {/* Categories */}
        <div className="flex flex-wrap items-center gap-1.5 w-full sm:w-auto">
          <button
            type="button"
            onClick={() => setFilterCategory('ALL')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              filterCategory === 'ALL'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            എല്ലാം ({logs.length})
          </button>
          <button
            type="button"
            onClick={() => setFilterCategory('INCOME')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              filterCategory === 'INCOME'
                ? 'bg-emerald-700 text-white'
                : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
            }`}
          >
            വരവ്
          </button>
          <button
            type="button"
            onClick={() => setFilterCategory('EXPENSE')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              filterCategory === 'EXPENSE'
                ? 'bg-rose-700 text-white'
                : 'bg-rose-50 text-rose-700 hover:bg-rose-100'
            }`}
          >
            ചിലവ്
          </button>
          <button
            type="button"
            onClick={() => setFilterCategory('HEADING')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              filterCategory === 'HEADING'
                ? 'bg-amber-700 text-white'
                : 'bg-amber-50 text-amber-800 hover:bg-amber-100'
            }`}
          >
            ശീർഷകങ്ങൾ
          </button>
          <button
            type="button"
            onClick={() => setFilterCategory('SECURITY')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              filterCategory === 'SECURITY'
                ? 'bg-indigo-700 text-white'
                : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100'
            }`}
          >
            സുരക്ഷ & ലോഗിൻ
          </button>
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
        {filteredLogs.length === 0 ? (
          <div className="text-center py-16 px-4">
            <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-700">ഓഡിറ്റ് ലോഗുകൾ ഒന്നും കണ്ടെത്തിയില്ല</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              വരവുകളോ ചിലവുകളോ ശീർഷകങ്ങളോ രേഖപ്പെടുത്തുകയോ ലോഗിൻ ചെയ്യുകയോ ചെയ്യുമ്പോൾ സ്വയമേവ ഇവിടെ രേഖപ്പെടുത്തപ്പെടും.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
                  <th className="py-3.5 px-4 w-12 text-center">#</th>
                  <th className="py-3.5 px-4 w-44">തീയതി & സമയം</th>
                  <th className="py-3.5 px-4 w-36">പ്രവർത്തനം</th>
                  <th className="py-3.5 px-4">വിവരണം (Details)</th>
                  <th className="py-3.5 px-4 w-32 text-right">തുക</th>
                  <th className="py-3.5 px-4 w-48 text-right">ഉപയോക്താവ്</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {filteredLogs.map((log, index) => {
                  const logDate = new Date(log.timestamp);
                  return (
                    <tr key={log.id} className="hover:bg-amber-50/40 transition">
                      <td className="py-3 px-4 text-center text-slate-400 font-mono">
                        {index + 1}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-1.5 text-slate-800 font-semibold">
                          <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span>{logDate.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}</span>
                        </div>
                        <div className="text-[10px] text-slate-400 pl-5">
                          {logDate.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                        </div>
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        {getActionBadge(log.action)}
                      </td>
                      <td className="py-3 px-4 font-medium text-slate-900">
                        {log.summaryMl}
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        {log.amount !== undefined ? (
                          <span className="font-bold text-slate-900 font-mono">
                            ₹{log.amount.toLocaleString('en-IN')}
                          </span>
                        ) : (
                          <span className="text-slate-300">-</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1 text-[11px] font-bold text-indigo-900 bg-indigo-50 px-2.5 py-1 rounded-full border border-indigo-200">
                          <User className="w-3 h-3 text-indigo-600" />
                          <span>{log.userEmail}</span>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
