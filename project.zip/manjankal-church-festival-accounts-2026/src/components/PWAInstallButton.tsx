import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Smartphone, Download, X } from 'lucide-react';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // If already running inside standalone PWA, hide install trigger
  if (isInstalled) {
    return null;
  }

  // Chromium / Android / Desktop Chrome PWA Install Flow
  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={install}
        className="inline-flex items-center gap-1.5 text-xs font-bold bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 px-3 py-2 rounded-xl transition border border-amber-400/40 cursor-pointer shadow-xs active:scale-95"
        title="ഫോണിൽ ഇൻസ്റ്റാൾ ചെയ്യുക"
      >
        <Download className="w-3.5 h-3.5 text-amber-300" />
        <span>ആപ്പ് ഇൻസ്റ്റാൾ</span>
      </button>
    );
  }

  // iOS Safari Flow
  if (isIOS) {
    return (
      <>
        <button
          type="button"
          onClick={() => setShowIOSGuide(true)}
          className="inline-flex items-center gap-1.5 text-xs font-bold bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 px-3 py-2 rounded-xl transition border border-amber-400/40 cursor-pointer shadow-xs active:scale-95"
          title="ഐഫോണിൽ ഇൻസ്റ്റാൾ ചെയ്യുക"
        >
          <Smartphone className="w-3.5 h-3.5 text-amber-300" />
          <span>ആപ്പ് ഇൻസ്റ്റാൾ</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
            <div className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-2xl border border-amber-200 text-slate-800">
              <div className="flex items-center justify-between pb-3 border-b border-amber-100">
                <div className="flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-red-900" />
                  <h3 className="text-base font-bold text-red-950">ഐഫോൺ / ഐപാഡ് ഇൻസ്റ്റാളേഷൻ</h3>
                </div>
                <button
                  type="button"
                  onClick={() => setShowIOSGuide(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="mt-4 space-y-3 text-xs leading-relaxed text-slate-600">
                <div className="flex items-start gap-2.5 bg-amber-50 p-2.5 rounded-xl border border-amber-200/60">
                  <span className="font-bold text-red-900 shrink-0">1.</span>
                  <p>സഫാരി ബ്രൗസറിന്റെ അടിയിലുള്ള <strong>'Share' (പങ്കുവെക്കുക)</strong> ബട്ടൺ അമർത്തുക.</p>
                </div>
                <div className="flex items-start gap-2.5 bg-amber-50 p-2.5 rounded-xl border border-amber-200/60">
                  <span className="font-bold text-red-900 shrink-0">2.</span>
                  <p>താഴേക്ക് സ്ക്രോൾ ചെയ്ത് <strong>'Add to Home Screen' (ഹോം സ്ക്രീനിലേക്ക് ചേർക്കുക)</strong> തിരഞ്ഞെടുക്കുക.</p>
                </div>
                <div className="flex items-start gap-2.5 bg-amber-50 p-2.5 rounded-xl border border-amber-200/60">
                  <span className="font-bold text-red-900 shrink-0">3.</span>
                  <p>മുകളിൽ വലതുവശത്തുള്ള <strong>'Add'</strong> അമർത്തുക. ആപ്പ് നിങ്ങളുടെ ഹോം സ്ക്രീനിൽ ലഭ്യമാകും.</p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="mt-5 w-full rounded-xl bg-red-950 py-2.5 text-xs font-bold text-white hover:bg-red-900 transition shadow-sm"
              >
                ശരി, മനസ്സിലായി
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
