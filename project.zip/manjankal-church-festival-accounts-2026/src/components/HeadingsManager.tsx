import React, { useState } from 'react';
import { Heading, TransactionType, YearAccountingData } from '../types/festival';
import { Plus, Edit2, Trash2, Layers, AlertCircle, ShieldAlert } from 'lucide-react';

interface HeadingsManagerProps {
  data: YearAccountingData;
  onAddHeading: (heading: Omit<Heading, 'id'>) => void;
  onUpdateHeading: (heading: Heading) => void;
  onDeleteHeading: (id: string) => void;
}

export const HeadingsManager: React.FC<HeadingsManagerProps> = ({
  data,
  onAddHeading,
  onUpdateHeading,
  onDeleteHeading,
}) => {
  const [activeType, setActiveType] = useState<TransactionType>('INCOME');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingHeading, setEditingHeading] = useState<Heading | null>(null);

  const [formName, setFormName] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formType, setFormType] = useState<TransactionType>('INCOME');
  const [alertError, setAlertError] = useState<string | null>(null);

  const filteredHeadings = data.headings.filter((h) => h.type === activeType);

  const handleOpenAdd = (type: TransactionType) => {
    setEditingHeading(null);
    setFormType(type);
    setFormName('');
    setFormDesc('');
    setAlertError(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (h: Heading) => {
    setEditingHeading(h);
    setFormType(h.type);
    setFormName(h.name);
    setFormDesc(h.description || '');
    setAlertError(null);
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) return;

    if (editingHeading) {
      onUpdateHeading({
        ...editingHeading,
        name: formName.trim(),
        description: formDesc.trim(),
        type: formType,
      });
    } else {
      onAddHeading({
        name: formName.trim(),
        description: formDesc.trim(),
        type: formType,
      });
    }

    setIsModalOpen(false);
  };

  const [blockedHeading, setBlockedHeading] = useState<Heading | null>(null);
  const [headingToDelete, setHeadingToDelete] = useState<Heading | null>(null);

  const handleDelete = (h: Heading) => {
    // Check if transactions exist under this heading
    const hasIncome = data.incomes.some((i) => i.headingId === h.id || i.headingName === h.name);
    const hasExpense = data.expenses.some((e) => e.headingId === h.id || e.headingName === h.name);

    if (hasIncome || hasExpense) {
      // In-app modal alert: Only delete a heading if it has NO transactions!
      setBlockedHeading(h);
      return;
    }

    // In-app confirmation dialog
    setHeadingToDelete(h);
  };

  const confirmDeleteHeading = () => {
    if (headingToDelete) {
      onDeleteHeading(headingToDelete.id);
      setHeadingToDelete(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-amber-200 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900 mb-2">
            <Layers className="w-3.5 h-3.5 text-amber-700" />
            <span>കസ്റ്റം ശീർഷകങ്ങൾ (Custom Headings)</span>
          </div>
          <h2 className="text-xl font-black text-slate-900">
            2026 പെരുന്നാൾ ശീർഷക മാനേജ്‌മെന്റ്
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            യാതൊരു ഡിഫോൾട്ട് കാറ്റഗറികളും ഇല്ലാതെ, നിങ്ങൾ നൽകുന്ന വരവ് - ചിലവ് ശീർഷകങ്ങൾ മാത്രമാണ് ഇവിടെ സൂക്ഷിക്കപ്പെടുന്നത്.
          </p>
        </div>

        <button
          type="button"
          onClick={() => handleOpenAdd(activeType)}
          className="inline-flex items-center gap-2 bg-amber-700 hover:bg-amber-800 text-white px-5 py-2.5 rounded-2xl text-xs font-bold shadow-sm transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>
            {activeType === 'INCOME' ? '+ പുതിയ വരവ് ശീർഷകം ചേർക്കുക' : '+ പുതിയ ചിലവ് ശീർഷകം ചേർക്കുക'}
          </span>
        </button>
      </div>

      {/* Tabs between Income Headings and Expense Headings */}
      <div className="flex border-b border-slate-200">
        <button
          onClick={() => setActiveType('INCOME')}
          className={`pb-3 px-6 text-sm font-bold border-b-2 transition cursor-pointer ${
            activeType === 'INCOME'
              ? 'border-emerald-600 text-emerald-800 bg-emerald-50/50 rounded-t-xl'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          📥 വരവ് ശീർഷകങ്ങൾ (Income Headings) (
          {data.headings.filter((h) => h.type === 'INCOME').length})
        </button>
        <button
          onClick={() => setActiveType('EXPENSE')}
          className={`pb-3 px-6 text-sm font-bold border-b-2 transition cursor-pointer ${
            activeType === 'EXPENSE'
              ? 'border-rose-600 text-rose-800 bg-rose-50/50 rounded-t-xl'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          📤 ചിലവ് ശീർഷകങ്ങൾ (Expense Headings) (
          {data.headings.filter((h) => h.type === 'EXPENSE').length})
        </button>
      </div>

      {/* Headings Grid or Empty State */}
      {filteredHeadings.length === 0 ? (
        <div className="bg-white rounded-3xl p-10 text-center border-2 border-dashed border-slate-200">
          <div className="w-12 h-12 bg-amber-100 text-amber-800 rounded-full flex items-center justify-center mx-auto mb-3">
            <Plus className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-800 mb-1">
            {activeType === 'INCOME' ? 'വരവ് ശീർഷകങ്ങൾ ഒന്നും ചേർത്തിട്ടില്ല' : 'ചിലവ് ശീർഷകങ്ങൾ ഒന്നും ചേർത്തിട്ടില്ല'}
          </h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto mb-4">
            {activeType === 'INCOME'
              ? 'നിങ്ങളുടെ ആദ്യത്തെ വരവ് ശീർഷകം (ഉദാ: നേർച്ച, ലേലം, വഴിപാട്, സ്പോൺസർഷിപ്പ്...) ഇവിടെ ചേർക്കുക.'
              : 'നിങ്ങളുടെ ആദ്യത്തെ ചിലവ് ശീർഷകം (ഉദാ: പന്തൽ, ലൈറ്റ് & സൗണ്ട്, അന്നദാനം, വെടിക്കെട്ട്...) ഇവിടെ ചേർക്കുക.'}
          </p>
          <button
            type="button"
            onClick={() => handleOpenAdd(activeType)}
            className="inline-flex items-center gap-2 bg-amber-700 hover:bg-amber-800 text-white px-5 py-2.5 rounded-2xl text-xs font-bold shadow-sm transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>
              {activeType === 'INCOME' ? '+ പുതിയ വരവ് ശീർഷകം ചേർക്കുക' : '+ പുതിയ ചിലവ് ശീർഷകം ചേർക്കുക'}
            </span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredHeadings.map((h, idx) => {
            const txCount =
              h.type === 'INCOME'
                ? data.incomes.filter((i) => i.headingId === h.id || i.headingName === h.name).length
                : data.expenses.filter((e) => e.headingId === h.id || e.headingName === h.name).length;

            const totalAmount =
              h.type === 'INCOME'
                ? data.incomes
                    .filter((i) => i.headingId === h.id || i.headingName === h.name)
                    .reduce((sum, i) => sum + i.amount, 0)
                : data.expenses
                    .filter((e) => e.headingId === h.id || e.headingName === h.name)
                    .reduce((sum, e) => sum + e.amount, 0);

            return (
              <div
                key={h.id}
                className={`bg-white rounded-2xl p-5 border shadow-xs transition hover:shadow-md flex flex-col justify-between ${
                  h.type === 'INCOME' ? 'border-emerald-200 hover:border-emerald-300' : 'border-rose-200 hover:border-rose-300'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <span
                        className={`w-6 h-6 flex items-center justify-center rounded-lg text-xs font-black ${
                          h.type === 'INCOME'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {idx + 1}
                      </span>
                      <h3 className="font-black text-slate-900 text-sm">{h.name}</h3>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleOpenEdit(h)}
                        className="p-1.5 text-slate-400 hover:text-amber-700 hover:bg-amber-50 rounded-lg transition cursor-pointer"
                        title="ശീർഷകം തിരുത്തുക"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(h)}
                        className="p-1.5 text-slate-400 hover:text-red-700 hover:bg-red-50 rounded-lg transition cursor-pointer"
                        title={txCount > 0 ? 'ഇടപാടുകൾ ഉള്ളതിനാൽ നീക്കം ചെയ്യാൻ സാധിക്കില്ല' : 'ശീർഷകം നീക്കം ചെയ്യുക'}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {h.description && (
                    <p className="text-xs text-slate-500 mb-3">{h.description}</p>
                  )}
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-slate-500 font-medium">
                    {h.type === 'INCOME' ? 'രസീതുകൾ:' : 'വൗച്ചറുകൾ:'} <strong>{txCount} എണ്ണം</strong>
                  </span>
                  <span
                    className={`font-black ${
                      h.type === 'INCOME' ? 'text-emerald-700' : 'text-rose-700'
                    }`}
                  >
                    ₹ {totalAmount.toLocaleString('en-IN')}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add / Edit Heading Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-amber-200">
            <h3 className="text-base font-bold text-slate-900 mb-1">
              {editingHeading ? 'ശീർഷകം തിരുത്തുക' : 'പുതിയ ശീർഷകം ചേർക്കുക'}
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              2026 പെരുന്നാൾ വരവ്-ചിലവ് കണക്കുകൾക്കായി നിങ്ങൾ നിശ്ചയിക്കുന്ന ശീർഷകം.
            </p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ഇനം (Type) *
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setFormType('INCOME')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition cursor-pointer ${
                      formType === 'INCOME'
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'border-slate-300 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    📥 വരവ് (Income)
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormType('EXPENSE')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition cursor-pointer ${
                      formType === 'EXPENSE'
                        ? 'bg-rose-600 text-white border-rose-600'
                        : 'border-slate-300 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    📤 ചിലവ് (Expense)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ശീർഷകത്തിന്റെ പേര് *
                </label>
                <input
                  type="text"
                  required
                  placeholder={
                    formType === 'INCOME'
                      ? 'ഉദാ: നേർച്ച പിരിവ് / ലേലം / സംഭാവന'
                      : 'ഉദാ: പന്തൽ / ലൈറ്റ് & സൗണ്ട് / അന്നദാനം'
                  }
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-amber-500 focus:outline-hidden font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  വിവരണം (ഓപ്ഷണൽ)
                </label>
                <textarea
                  rows={2}
                  placeholder="ശീർഷകത്തെക്കുറിച്ചുള്ള ചെറിയ കുറിപ്പ്..."
                  value={formDesc}
                  onChange={(e) => setFormDesc(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  റദ്ദാക്കുക
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-amber-700 hover:bg-amber-800 text-white cursor-pointer shadow-sm"
                >
                  {editingHeading ? 'മാറ്റങ്ങൾ സംരക്ഷിക്കുക' : 'ശീർഷകം ചേർക്കുക'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* In-App Blocked Deletion Modal */}
      {blockedHeading && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-rose-200">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-700 flex items-center justify-center mb-4">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-black text-slate-900 mb-2">
              ശീർഷകം നീക്കം ചെയ്യാൻ സാധിക്കില്ല
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed mb-6">
              <strong className="text-slate-900">"{blockedHeading.name}"</strong> എന്ന ശീർഷകത്തിൽ നിലവിൽ ഇടപാടുകൾ രേഖപ്പെടുത്തിയിട്ടുള്ളതിനാൽ ഇത് നീക്കം ചെയ്യാൻ സാധിക്കില്ല.
              ആദ്യം ഇതിന്റെ കീഴിലുള്ള രസീതുകൾ അല്ലെങ്കിൽ വൗച്ചറുകൾ നീക്കം ചെയ്യുകയോ മറ്റ് ശീർഷകത്തിലേക്ക് മാറ്റുകയോ ചെയ്യേണ്ടതാണ്.
            </p>
            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setBlockedHeading(null)}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold transition cursor-pointer"
              >
                മനസ്സിലായി (Close)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* In-App Delete Confirmation Modal */}
      {headingToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-amber-300">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center mb-4">
              <AlertCircle className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-black text-slate-900 mb-2">
              ശീർഷകം നീക്കം ചെയ്യൽ സ്ഥിരീകരിക്കുക
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed mb-6">
              <strong className="text-slate-900">"{headingToDelete.name}"</strong> ({headingToDelete.type === 'INCOME' ? 'വരവ്' : 'ചിലവ്'}) എന്ന ശീർഷകം നീക്കം ചെയ്യണമെന്ന് ഉറപ്പാണോ?
              ഈ ശീർഷകത്തിൽ നിലവിൽ മറ്റ് ഇടപാടുകൾ ഒന്നും തന്നെയില്ല.
            </p>
            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setHeadingToDelete(null)}
                className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition cursor-pointer"
              >
                റദ്ദാക്കുക (Cancel)
              </button>
              <button
                type="button"
                onClick={confirmDeleteHeading}
                className="px-5 py-2.5 rounded-xl bg-rose-700 hover:bg-rose-800 text-white text-xs font-bold shadow-sm transition cursor-pointer"
              >
                ശരി, നീക്കം ചെയ്യുക (Delete)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
