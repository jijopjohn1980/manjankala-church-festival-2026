import React, { useRef, useState } from 'react';
import { AppState } from '../types/festival';
import { isValidAppStateSchema } from '../utils/storage';
import {
  Download,
  Upload,
  RefreshCw,
  X,
  ShieldCheck,
  AlertCircle,
  KeyRound,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Copy,
  Archive,
} from 'lucide-react';
import { authenticateSuperAdmin, SUPER_ADMIN_EMAIL } from '../utils/auth';

interface BackupRestoreModalProps {
  appState: AppState;
  onRestoreState: (state: AppState) => void;
  onResetSample: () => void;
  onClose: () => void;
  onRecordAudit: (action: 'BACKUP_EXPORT' | 'BACKUP_RESTORE', summaryMl: string) => void;
}

export const BackupRestoreModal: React.FC<BackupRestoreModalProps> = ({
  appState,
  onRestoreState,
  onResetSample,
  onClose,
  onRecordAudit,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [isError, setIsError] = useState(false);

  // Verification state for restore
  const [pendingRestoreData, setPendingRestoreData] = useState<AppState | null>(null);
  const [pinPrompt, setPinPrompt] = useState(false);
  const [actionType, setActionType] = useState<'RESTORE' | 'RESET' | null>(null);
  const [pin, setPin] = useState('');
  const [pinError, setPinError] = useState<string | null>(null);
  const [acknowledgeOverwrite, setAcknowledgeOverwrite] = useState(false);

  // Check if a verified safety snapshot is available in localStorage
  const hasSafetySnapshot = Boolean(
    localStorage.getItem('church_festival_pre_restore_safety_snapshot')
  );

  // Current System Record Counts & Totals
  const currentYearsCount = appState.years.length;
  let currentReceipts = 0;
  let currentIncomeTotal = 0;
  let currentVouchers = 0;
  let currentExpenseTotal = 0;
  let currentHeadingsCount = 0;

  Object.values(appState.dataByYear).forEach((d) => {
    currentReceipts += d.incomes.length;
    currentIncomeTotal += d.incomes.reduce((sum, inc) => sum + inc.amount, 0);
    currentVouchers += d.expenses.length;
    currentExpenseTotal += d.expenses.reduce((sum, exp) => sum + exp.amount, 0);
    currentHeadingsCount += d.headings.length;
  });

  // Uploaded Backup Record Counts & Totals
  let backupYearsCount = 0;
  let backupReceipts = 0;
  let backupIncomeTotal = 0;
  let backupVouchers = 0;
  let backupExpenseTotal = 0;
  let backupHeadingsCount = 0;

  if (pendingRestoreData) {
    backupYearsCount = pendingRestoreData.years?.length || 0;
    if (pendingRestoreData.dataByYear) {
      Object.values(pendingRestoreData.dataByYear).forEach((d) => {
        backupReceipts += d.incomes?.length || 0;
        backupIncomeTotal += (d.incomes || []).reduce((sum, inc) => sum + inc.amount, 0);
        backupVouchers += d.expenses?.length || 0;
        backupExpenseTotal += (d.expenses || []).reduce((sum, exp) => sum + exp.amount, 0);
        backupHeadingsCount += d.headings?.length || 0;
      });
    }
  }

  // Backup Download
  const handleDownloadBackup = () => {
    try {
      const dataStr = JSON.stringify(appState, null, 2);
      const blob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      const timestamp = new Date().toISOString().split('T')[0];
      link.href = url;
      link.download = `Manjakala_Church_Festival_Backup_${timestamp}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      // ANDROID CHROME FIX: Defer URL revocation so the mobile download manager has time to stream the blob
      setTimeout(() => {
        URL.revokeObjectURL(url);
      }, 60000);

      onRecordAudit('BACKUP_EXPORT', 'സൂപ്പർ അഡ്മിൻ സമ്പൂർണ്ണ ഡാറ്റ ബാക്കപ്പ് JSON ഫയലായി ഡൗൺലോഡ് ചെയ്യാൻ അഭ്യർത്ഥിച്ചു');
      setStatusMessage(
        'ബാക്കപ്പ് ഫയൽ ഡൗൺലോഡ് പ്രക്രിയ ആരംഭിച്ചു (Download Dispatched). നിങ്ങളുടെ ഡൗൺലോഡ്സ് ഫോൾഡറിലോ നോട്ടിഫിക്കേഷനിലോ ഫയൽ വന്നിട്ടുണ്ടോ എന്ന് പരിശോധിക്കുക. ഈ ഫയൽ ഗൂഗിൾ ഡ്രൈവിലോ പെൻഡ്രൈവിലോ ബാഹ്യ പകർപ്പായി സൂക്ഷിക്കുക!'
      );
      setIsError(false);
    } catch (err: any) {
      console.error('Download dispatch failure:', err);
      setStatusMessage(`ബാക്കപ്പ് ഡൗൺലോഡ് ചെയ്യുന്നതിൽ തടസ്സം നേരിട്ടു: ${err.message}`);
      setIsError(true);
    }
  };

  // Foolproof Backup Alternative: Direct Clipboard Copy (Essential for restricted mobile browsers)
  const handleCopyBackupToClipboard = async () => {
    try {
      const dataStr = JSON.stringify(appState, null, 2);
      await navigator.clipboard.writeText(dataStr);
      setStatusMessage('ബാക്കപ്പ് ഡാറ്റ ക്ലിപ്പ്ബോർഡിലേക്ക് കോപ്പി ചെയ്തു (Copied to Clipboard). ഇത് വാട്സാപ്പിലോ സുരക്ഷിതമായ ഇമെയിലിലോ സേവ് ചെയ്യാം.');
      setIsError(false);
    } catch (err: any) {
      setStatusMessage(`ക്ലിപ്പ്ബോർഡിലേക്ക് കോപ്പി ചെയ്യാൻ സാധിച്ചില്ല: ${err.message}`);
      setIsError(true);
    }
  };

  // Restore Upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const parsed = JSON.parse(content) as AppState;

        if (!parsed.years || !parsed.dataByYear || !parsed.activeYearId) {
          throw new Error('അസാധുവായ ബാക്കപ്പ് ഫയൽ ഫോർമാറ്റ്');
        }

        setPendingRestoreData(parsed);
        setActionType('RESTORE');
        setPinPrompt(true);
        setPin('');
        setPinError(null);
        setAcknowledgeOverwrite(false);
      } catch (err) {
        console.error(err);
        setStatusMessage('ഫയൽ റീസ്റ്റോർ ചെയ്യാൻ സാധിച്ചില്ല. ശരിയായ JSON ഫയൽ തിരഞ്ഞെടുക്കുക.');
        setIsError(true);
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleResetClick = () => {
    setActionType('RESET');
    setPinPrompt(true);
    setPin('');
    setPinError(null);
    setAcknowledgeOverwrite(false);
  };

  // Rollback to Emergency Safety Snapshot with FULL SCHEMA VALIDATION & PRESERVATION
  const handleRollbackToSnapshot = () => {
    try {
      const raw = localStorage.getItem('church_festival_pre_restore_safety_snapshot');
      if (!raw) {
        setStatusMessage('റോൾബാക്ക് പരാജയപ്പെട്ടു: സുരക്ഷാ സ്നാപ്പ്ഷോട്ട് ലഭ്യമല്ല.');
        setIsError(true);
        return;
      }

      let parsed: any;
      try {
        parsed = JSON.parse(raw);
      } catch (parseErr) {
        setStatusMessage('റോൾബാക്ക് പരാജയപ്പെട്ടു: സുരക്ഷാ സ്നാപ്പ്ഷോട്ട് ഡാറ്റ കേടുവന്നതാണ് (Invalid JSON).');
        setIsError(true);
        return;
      }

      // 1. Explicit check for missing parsed.state
      if (!parsed || typeof parsed !== 'object' || !parsed.state) {
        setStatusMessage('റോൾബാക്ക് പരാജയപ്പെട്ടു: സുരക്ഷാ സ്നാപ്പ്ഷോട്ടിൽ സ്റ്റേറ്റ് വിവരങ്ങൾ കാണാനില്ല (Missing state in snapshot payload).');
        setIsError(true);
        return;
      }

      // 2. Full Schema Validation of the restored state
      if (!isValidAppStateSchema(parsed.state)) {
        setStatusMessage('റോൾബാക്ക് പരാജയപ്പെട്ടു: സുരക്ഷാ സ്നാപ്പ്ഷോട്ടിലെ വിവരങ്ങളുടെ സ്കീമ അസാധുവാണ് (Malformed AppState schema).');
        setIsError(true);
        return;
      }

      // 3. Preserve the snapshot: Archive current state before rollback without overwriting the safety snapshot
      try {
        const archiveKey = `church_festival_archive_before_rollback_${Date.now()}`;
        const archivePayload = JSON.stringify({
          archivedAt: new Date().toISOString(),
          state: appState,
        });
        localStorage.setItem(archiveKey, archivePayload);
        const readBackArchive = localStorage.getItem(archiveKey);
        if (!readBackArchive || readBackArchive !== archivePayload) {
          throw new Error('ആർക്കൈവ് റീഡ്-ബാക്ക് പരിശോധന പരാജയപ്പെട്ടു.');
        }
      } catch (archiveErr: any) {
        setStatusMessage(
          `റോൾബാക്ക് റദ്ദാക്കി: നിലവിലെ ഡാറ്റ സുരക്ഷിതമായി ആർക്കൈവ് ചെയ്യാൻ സാധിച്ചില്ല (${archiveErr.message}). നിലവിലെ കണക്കുകൾ നഷ്ടപ്പെടാതിരിക്കാൻ റോൾബാക്ക് പൂർണ്ണമായും റദ്ദാക്കി.`
        );
        setIsError(true);
        return; // MANDATORY CANCEL: Never proceed to onRestoreState if archive failed
      }

      // 4. Perform the restore ONLY after successful archive
      onRestoreState(parsed.state);

      // Calculate restored totals for transparent confirmation
      let restoredReceipts = 0;
      let restoredVouchers = 0;
      Object.values(parsed.state.dataByYear).forEach((d: any) => {
        restoredReceipts += d.incomes?.length || 0;
        restoredVouchers += d.expenses?.length || 0;
      });

      // 5. Audit log
      onRecordAudit(
        'BACKUP_RESTORE',
        `സൂപ്പർ അഡ്മിൻ മുൻപത്തെ സുരക്ഷാ സ്നാപ്പ്ഷോട്ട് വിജയകരമായി റോൾബാക്ക് ചെയ്തു (${restoredReceipts} രസീതുകൾ, ${restoredVouchers} വൗച്ചറുകൾ വീണ്ടെടുത്തു)`
      );

      // 6. Only report success after complete validation
      setStatusMessage(
        `മുൻപത്തെ സുരക്ഷാ സ്നാപ്പ്ഷോട്ട് വിജയകരമായി റോൾബാക്ക് ചെയ്തു! (${restoredReceipts} രസീതുകൾ, ${restoredVouchers} വൗച്ചറുകൾ കൃത്യമായി വീണ്ടെടുത്തു).`
      );
      setIsError(false);
    } catch (err: any) {
      setStatusMessage(`റോൾബാക്ക് പരാജയപ്പെട്ടു: ${err.message}`);
      setIsError(true);
    }
  };

  // Execute authenticated restore or reset with MANDATORY PRE-RESTORE SAFETY SNAPSHOT VERIFICATION
  const handleVerifyAndProceed = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pin.trim()) {
      setPinError('ദയവായി സൂപ്പർ അഡ്മിൻ സെക്യൂരിറ്റി പിൻ നൽകുക.');
      return;
    }

    if (actionType === 'RESTORE' && !acknowledgeOverwrite) {
      setPinError('റീസ്റ്റോർ ചെയ്യുന്നതിന് മുൻപായി മുന്നറിയിപ്പ് സ്ഥിരീകരിക്കുക.');
      return;
    }

    const authRes = await authenticateSuperAdmin(SUPER_ADMIN_EMAIL, pin);
    if (!authRes.success) {
      setPinError(authRes.error || 'സെക്യൂരിറ്റി പിൻ തെറ്റാണ്!');
      return;
    }

    if (actionType === 'RESTORE' && pendingRestoreData) {
      // 1. Mandatory Pre-Restore Safety Snapshot with READ-BACK VERIFICATION
      let snapshotConfirmed = false;
      let snapshotErrorDetail: string | null = null;
      const snapshotKey = 'church_festival_pre_restore_safety_snapshot';
      const rollbackKey = 'church_festival_emergency_rollback_slot';

      try {
        const snapshotMetadata = {
          savedAt: new Date().toISOString(),
          yearCount: currentYearsCount,
          receiptsCount: currentReceipts,
          vouchersCount: currentVouchers,
          totalIncome: currentIncomeTotal,
          totalExpense: currentExpenseTotal,
          state: appState,
        };
        const snapshotPayload = JSON.stringify(snapshotMetadata);

        // A. Persist snapshot to primary storage slot
        localStorage.setItem(snapshotKey, snapshotPayload);

        // B. Persist snapshot to redundant rollback slot
        localStorage.setItem(rollbackKey, snapshotPayload);

        // C. MANDATORY READ-BACK VERIFICATION: Read back from storage to prove persistence
        const verifyReadBack = localStorage.getItem(snapshotKey);
        if (!verifyReadBack) {
          throw new Error('സുരക്ഷാ സ്നാപ്പ്ഷോട്ട് ബ്രൗസറിൽ സൂക്ഷിച്ച ശേഷം സ്ഥിരീകരിക്കാൻ സാധിച്ചില്ല (Storage read-back verification failed).');
        }

        const parsedVerification = JSON.parse(verifyReadBack);
        if (
          !parsedVerification.state ||
          !Array.isArray(parsedVerification.state.years) ||
          parsedVerification.yearCount !== currentYearsCount ||
          parsedVerification.receiptsCount !== currentReceipts ||
          parsedVerification.vouchersCount !== currentVouchers
        ) {
          throw new Error('സുരക്ഷാ സ്നാപ്പ്ഷോട്ടിലെ വിവരങ്ങളിൽ പൊരുത്തക്കേട് കണ്ടെത്തി (Snapshot payload corrupted or incomplete).');
        }

        snapshotConfirmed = true;

        // D. Trigger browser download of safety file to user device
        try {
          const blob = new Blob([JSON.stringify(appState, null, 2)], { type: 'application/json' });
          const url = URL.createObjectURL(blob);
          const link = document.createElement('a');
          const ts = new Date().toISOString().replace(/[:.]/g, '-');
          link.href = url;
          link.download = `SAFETY_SNAPSHOT_Before_Restore_${ts}.json`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          URL.revokeObjectURL(url);
        } catch (downloadErr) {
          console.warn('Browser auto-download notice:', downloadErr);
        }
      } catch (err: any) {
        snapshotConfirmed = false;
        snapshotErrorDetail = err.message || 'സുരക്ഷാ സ്നാപ്പ്ഷോട്ട് തയ്യാറാക്കാൻ സാധിച്ചില്ല.';
      }

      // CRITICAL FAIL-SAFE: If snapshot failed or could not be verified, CANCEL RESTORE COMPLETELY!
      if (!snapshotConfirmed) {
        setIsError(true);
        setStatusMessage(
          `റീസ്റ്റോർ റദ്ദാക്കി (Restore Aborted): നിർബന്ധിത സുരക്ഷാ സ്നാപ്പ്ഷോട്ട് പരാജയപ്പെട്ടു (${snapshotErrorDetail}). ഡാറ്റ നഷ്ടപ്പെടാതിരിക്കാൻ റീസ്റ്റോർ പൂർണ്ണമായും റദ്ദാക്കി. നിലവിലെ കണക്കുകൾ സുരക്ഷിതമാണ്.`
        );
        setPinPrompt(false);
        setPendingRestoreData(null);
        setActionType(null);
        setPin('');
        setAcknowledgeOverwrite(false);
        return;
      }

      // State replacement ONLY after 100% verified snapshot
      onRestoreState(pendingRestoreData);
      onRecordAudit(
        'BACKUP_RESTORE',
        `സൂപ്പർ അഡ്മിൻ ബാക്കപ്പ് ഫയൽ വിജയകരമായി റീസ്റ്റോർ ചെയ്തു (റീസ്റ്റോറിന് മുൻപുള്ള ${currentReceipts} രസീതുകൾ, ${currentVouchers} വൗച്ചറുകൾ സുരക്ഷാ സ്നാപ്പ്ഷോട്ടിൽ സ്ഥിരീകരിച്ചു)`
      );
      setStatusMessage(
        'ബാക്കപ്പ് ഫയലിൽ നിന്നുള്ള കണക്കുകൾ വിജയകരമായി പുനഃസ്ഥാപിച്ചു! (റീസ്റ്റോർ ചെയ്യുന്നതിന് തൊട്ടുമുൻപുള്ള കണക്കുകൾ സുരക്ഷയ്ക്കായി സ്നാപ്പ്ഷോട്ടായി സൂക്ഷിച്ചിട്ടുണ്ട്).'
      );
      setIsError(false);
    } else if (actionType === 'RESET') {
      try {
        localStorage.setItem(
          'church_festival_pre_reset_safety_snapshot',
          JSON.stringify({
            savedAt: new Date().toISOString(),
            state: appState,
          })
        );
      } catch {
        // ignore
      }
      onResetSample();
      onRecordAudit('BACKUP_RESTORE', 'സൂപ്പർ അഡ്മിൻ കണക്കുകൾ പൂജ്യത്തിലേക്ക് (₹0) റീസെറ്റ് ചെയ്തു');
      setStatusMessage('കണക്കുകൾ വിജയകരമായി പൂജ്യത്തിലേക്ക് (₹0) റീസെറ്റ് ചെയ്തു.');
      setIsError(false);
    }

    setPinPrompt(false);
    setPendingRestoreData(null);
    setActionType(null);
    setPin('');
    setAcknowledgeOverwrite(false);
  };

  const totalYearsCount = appState.years.length;
  let totalReceipts = 0;
  let totalVouchers = 0;
  Object.values(appState.dataByYear).forEach((d) => {
    totalReceipts += d.incomes.length;
    totalVouchers += d.expenses.length;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto overscroll-contain">
      <div className="bg-white rounded-3xl max-w-lg w-full p-4 sm:p-6 shadow-2xl border border-amber-300 relative my-auto max-h-[calc(100dvh-1.5rem)] sm:max-h-[calc(100dvh-2rem)] flex flex-col overflow-hidden">
        {/* Fixed Modal Header */}
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100 shrink-0">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-amber-700 shrink-0" />
            <h3 className="text-base font-bold text-slate-900 truncate">
              പെരുന്നാൾ കണക്കുകൾ ബാക്കപ്പ് & റീസ്റ്റോർ
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {statusMessage && (
          <div
            className={`p-3 rounded-2xl text-xs font-semibold mb-3 flex items-center gap-2 shrink-0 ${
              isError
                ? 'bg-red-50 text-red-800 border border-red-200'
                : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
            }`}
          >
            {isError ? <AlertCircle className="w-4 h-4 shrink-0" /> : <CheckCircle2 className="w-4 h-4 shrink-0" />}
            <span className="leading-relaxed">{statusMessage}</span>
          </div>
        )}

        {/* Security PIN Challenge Modal overlay */}
        {pinPrompt ? (
          <form onSubmit={handleVerifyAndProceed} className="flex flex-col flex-1 min-h-0 overflow-hidden">
            {/* Scrollable content area */}
            <div className="flex-1 overflow-y-auto overscroll-contain space-y-4 pr-1 -mr-1 py-1">
              {actionType === 'RESTORE' && pendingRestoreData ? (
                <div className="space-y-3">
                  {/* 1. Explicit Critical Overwrite Warning Banner */}
                  <div className="bg-rose-50 border-2 border-rose-400 rounded-2xl p-3.5 text-xs text-rose-950">
                    <div className="font-extrabold text-sm flex items-center gap-2 mb-1.5 text-rose-800">
                      <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
                      <span>അതിപ്രധാനം: പഴയ ബാക്കപ്പ് പുതിയ കണക്കുകളെ മാറ്റിസ്ഥാപിക്കും!</span>
                    </div>
                    <p className="font-medium text-rose-900 leading-relaxed">
                      പഴയ ബാക്കപ്പ് ഫയൽ റീസ്റ്റോർ ചെയ്താൽ, നിലവിലുള്ള പുതിയ കണക്കുകൾ പൂർണ്ണമായും മാറ്റിസ്ഥാപിക്കപ്പെടും (Overwritten).
                      നിങ്ങൾ തിരഞ്ഞെടുക്കുന്ന ബാക്കപ്പിൽ ഉൾപ്പെടാത്ത പുതിയ എൻട്രികൾ ഇല്ലാതാകും.
                    </p>
                    <p className="mt-1 text-[11px] text-rose-700 font-bold">
                      🛡️ സുരക്ഷാ മുൻകരുതൽ: റീസ്റ്റോർ ചെയ്യുന്നതിന് മുൻപായി നിലവിലെ എല്ലാ വിവരങ്ങളും ഒരു നിർബന്ധിത സുരക്ഷാ സ്നാപ്പ്ഷോട്ടായി (Safety Snapshot) പരിശോധിച്ച് ഉറപ്പാക്കും. സ്നാപ്പ്ഷോട്ട് പരാജയപ്പെട്ടാൽ റീസ്റ്റോർ പൂർണ്ണമായും റദ്ദാക്കപ്പെടും.
                    </p>
                  </div>

                  {/* 2. Side-by-Side Verification Table */}
                  <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 text-xs">
                    <div className="font-bold text-slate-800 mb-2 flex items-center justify-between">
                      <span>കണക്കുകളുടെ താരതമ്യ വിവരങ്ങൾ (Comparison):</span>
                      <span className="text-[10px] text-slate-500 font-normal">പരിശോധിച്ച് ഉറപ്പാക്കുക</span>
                    </div>
                    {/* touch-pan-x allows horizontal scroll while preserving vertical scrolling on mobile touch */}
                    <div className="overflow-x-auto touch-pan-x border border-slate-200/80 rounded-xl bg-white">
                      <table className="w-full text-left border-collapse text-[11px]">
                        <thead>
                          <tr className="border-b border-slate-200 text-slate-500 font-semibold bg-slate-50">
                            <th className="py-1.5 px-2">വിവരം (Entity)</th>
                            <th className="py-1.5 px-2 text-center bg-amber-50/80 text-amber-900 font-bold border-l border-slate-200/60">
                              നിലവിൽ (Current)
                            </th>
                            <th className="py-1.5 px-2 text-center bg-emerald-50/80 text-emerald-900 font-bold border-l border-slate-200/60">
                              ബാക്കപ്പിൽ (To Restore)
                            </th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-slate-700">
                          <tr>
                            <td className="py-1.5 px-2 font-medium">പെരുന്നാൾ വർഷങ്ങൾ</td>
                            <td className="py-1.5 px-2 text-center font-bold text-amber-900 bg-amber-50/30 border-l border-slate-100">
                              {currentYearsCount}
                            </td>
                            <td className="py-1.5 px-2 text-center font-bold text-emerald-900 bg-emerald-50/30 border-l border-slate-100">
                              {backupYearsCount}
                            </td>
                          </tr>
                          <tr>
                            <td className="py-1.5 px-2 font-medium">ശീർഷകങ്ങൾ (Headings)</td>
                            <td className="py-1.5 px-2 text-center font-bold text-amber-900 bg-amber-50/30 border-l border-slate-100">
                              {currentHeadingsCount}
                            </td>
                            <td className="py-1.5 px-2 text-center font-bold text-emerald-900 bg-emerald-50/30 border-l border-slate-100">
                              {backupHeadingsCount}
                            </td>
                          </tr>
                          <tr>
                            <td className="py-1.5 px-2 font-medium">വരവ് രസീതുകൾ (Receipts)</td>
                            <td className="py-1.5 px-2 text-center font-bold text-amber-900 bg-amber-50/30 border-l border-slate-100">
                              {currentReceipts}
                            </td>
                            <td className="py-1.5 px-2 text-center font-bold text-emerald-900 bg-emerald-50/30 border-l border-slate-100">
                              {backupReceipts}
                            </td>
                          </tr>
                          <tr>
                            <td className="py-1.5 px-2 font-medium">ആകെ വരവ് തുക (Total Income)</td>
                            <td className="py-1.5 px-2 text-center font-bold text-amber-900 bg-amber-50/30 border-l border-slate-100">
                              ₹{currentIncomeTotal.toLocaleString('en-IN')}
                            </td>
                            <td className="py-1.5 px-2 text-center font-bold text-emerald-900 bg-emerald-50/30 border-l border-slate-100">
                              ₹{backupIncomeTotal.toLocaleString('en-IN')}
                            </td>
                          </tr>
                          <tr>
                            <td className="py-1.5 px-2 font-medium">ചിലവ് വൗച്ചറുകൾ (Vouchers)</td>
                            <td className="py-1.5 px-2 text-center font-bold text-amber-900 bg-amber-50/30 border-l border-slate-100">
                              {currentVouchers}
                            </td>
                            <td className="py-1.5 px-2 text-center font-bold text-emerald-900 bg-emerald-50/30 border-l border-slate-100">
                              {backupVouchers}
                            </td>
                          </tr>
                          <tr>
                            <td className="py-1.5 px-2 font-medium">ആകെ ചിലവ് തുക (Total Expense)</td>
                            <td className="py-1.5 px-2 text-center font-bold text-amber-900 bg-amber-50/30 border-l border-slate-100">
                              ₹{currentExpenseTotal.toLocaleString('en-IN')}
                            </td>
                            <td className="py-1.5 px-2 text-center font-bold text-emerald-900 bg-emerald-50/30 border-l border-slate-100">
                              ₹{backupExpenseTotal.toLocaleString('en-IN')}
                            </td>
                          </tr>
                          <tr className="bg-slate-100/80 font-black">
                            <td className="py-1.5 px-2">നെറ്റ് ബാലൻസ് (Net Balance)</td>
                            <td className="py-1.5 px-2 text-center text-amber-950 border-l border-slate-200">
                              ₹{(currentIncomeTotal - currentExpenseTotal).toLocaleString('en-IN')}
                            </td>
                            <td className="py-1.5 px-2 text-center text-emerald-950 border-l border-slate-200">
                              ₹{(backupIncomeTotal - backupExpenseTotal).toLocaleString('en-IN')}
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* 3. Mandatory Acknowledgment Checkbox */}
                  <label className="flex items-start gap-2.5 p-3 rounded-xl bg-amber-50 border border-amber-300 text-xs text-amber-950 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={acknowledgeOverwrite}
                      onChange={(e) => setAcknowledgeOverwrite(e.target.checked)}
                      className="mt-0.5 rounded-sm border-amber-400 text-amber-700 focus:ring-amber-500 cursor-pointer shrink-0"
                    />
                    <span className="font-bold leading-relaxed">
                      പഴയ ബാക്കപ്പ് ഫയൽ റീസ്റ്റോർ ചെയ്യുന്നത് നിലവിലുള്ള പുതിയ കണക്കുകളെ മാറ്റിസ്ഥാപിക്കുമെന്നും (Overwrite), നിർബന്ധിത സുരക്ഷാ സ്നാപ്പ്ഷോട്ട് പരിശോധന പരാജയപ്പെട്ടാൽ റീസ്റ്റോർ റദ്ദാക്കപ്പെടുമെന്നും ഞാൻ മനസ്സിലാക്കുന്നു.
                    </span>
                  </label>
                </div>
              ) : (
                <div className="bg-amber-50 border border-amber-300 rounded-2xl p-4 text-xs text-amber-950">
                  <div className="font-bold text-sm flex items-center gap-2 mb-1">
                    <KeyRound className="w-4 h-4 text-amber-700 shrink-0" />
                    <span>സൂപ്പർ അഡ്മിൻ സുരക്ഷാ സ്ഥിരീകരണം</span>
                  </div>
                  <p>കണക്കുകൾ പൂജ്യത്തിലേക്ക് റീസെറ്റ് ചെയ്യുന്നതിന് സൂപ്പർ അഡ്മിൻ സെക്യൂരിറ്റി പിൻ നൽകുക.</p>
                </div>
              )}

              {pinError && (
                <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 font-semibold flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{pinError}</span>
                </div>
              )}

              <div className="pt-1">
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  സൂപ്പർ അഡ്മിൻ സെക്യൂരിറ്റി പിൻ *
                </label>
                <input
                  type="password"
                  required
                  autoFocus
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  placeholder="പിൻ നൽകുക"
                  className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                />
              </div>
            </div>

            {/* Sticky bottom action buttons footer: always visible and accessible on mobile */}
            <div className="sticky bottom-0 bg-white/95 backdrop-blur-xs pt-3 pb-1 border-t border-slate-100 mt-2 flex justify-end gap-2 shrink-0 z-10">
              <button
                type="button"
                onClick={() => {
                  setPinPrompt(false);
                  setPendingRestoreData(null);
                  setActionType(null);
                  setAcknowledgeOverwrite(false);
                }}
                className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 cursor-pointer active:scale-95 transition"
              >
                റദ്ദാക്കുക
              </button>
              <button
                type="submit"
                disabled={actionType === 'RESTORE' && !acknowledgeOverwrite}
                className={`px-5 py-2.5 rounded-xl text-xs font-bold transition shadow-sm cursor-pointer active:scale-95 ${
                  actionType === 'RESTORE' && !acknowledgeOverwrite
                    ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                    : 'bg-amber-700 hover:bg-amber-800 text-white'
                }`}
              >
                സ്ഥിരീകരിച്ച് റീസ്റ്റോർ ചെയ്യുക
              </button>
            </div>
          </form>
        ) : (
          <div className="flex flex-col flex-1 min-h-0 overflow-hidden">
            {/* Scrollable options body */}
            <div className="flex-1 overflow-y-auto overscroll-contain pr-1 -mr-1 py-1 space-y-3">
              {/* Current status overview */}
              <div className="bg-amber-50/60 p-3.5 rounded-2xl border border-amber-200/80 text-xs text-amber-950">
                <div className="font-bold mb-1">നിലവിൽ സിസ്റ്റത്തിൽ സൂക്ഷിച്ചിട്ടുള്ള വിവരങ്ങൾ:</div>
                <div className="grid grid-cols-3 gap-2 text-center mt-2">
                  <div className="bg-white p-2 rounded-xl border border-amber-200">
                    <span className="block font-black text-amber-900 text-sm">{totalYearsCount}</span>
                    <span className="text-[10px] text-slate-500 font-medium">പെരുന്നാൾ വർഷങ്ങൾ</span>
                  </div>
                  <div className="bg-white p-2 rounded-xl border border-amber-200">
                    <span className="block font-black text-emerald-800 text-sm">{totalReceipts}</span>
                    <span className="text-[10px] text-slate-500 font-medium">വരവ് രസീതുകൾ</span>
                  </div>
                  <div className="bg-white p-2 rounded-xl border border-amber-200">
                    <span className="block font-black text-rose-800 text-sm">{totalVouchers}</span>
                    <span className="text-[10px] text-slate-500 font-medium">ചിലവ് വൗച്ചറുകൾ</span>
                  </div>
                </div>
              </div>

              {/* 4. Mandatory External Backup Warning Banner */}
              <div className="bg-amber-100/90 border-2 border-amber-400 p-3.5 rounded-2xl text-xs text-amber-950 flex items-start gap-2.5 shadow-xs">
                <AlertTriangle className="w-5 h-5 text-amber-800 shrink-0 mt-0.5" />
                <div>
                  <span className="font-extrabold block text-amber-950 mb-0.5">
                    അതീവ പ്രധാനമായ സുരക്ഷാ നിർദ്ദേശം (External Backup Reminder):
                  </span>
                  <p className="leading-relaxed text-[11px] text-amber-900">
                    ബ്രൗസർ കാഷെ ക്ലിയർ ചെയ്താലോ ഫോൺ റീസെറ്റ് ചെയ്താലോ ലോക്കൽ ഡാറ്റ നഷ്ടപ്പെടാം. അതിനാൽ ഡൗൺലോഡ് ചെയ്ത ബാക്കപ്പ് ഫയൽ പെൻഡ്രൈവിലോ, ഗൂഗിൾ ഡ്രൈവിലോ, സുരക്ഷിതമായ ഇമെയിലിലോ ബാഹ്യ പകർപ്പായി നിർബന്ധമായും സൂക്ഷിക്കുക (Keep Backup Outside Browser).
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                {/* 1. Download Backup */}
                <div className="p-4 rounded-2xl border border-slate-200 hover:border-amber-400 transition bg-slate-50/40">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                    <div>
                      <h4 className="font-bold text-xs text-slate-900">
                        1. ബാക്കപ്പ് ഫയൽ ഡൗൺലോഡ് ചെയ്യുക (Download Backup)
                      </h4>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        കമ്പ്യൂട്ടറിലോ ആൻഡ്രോയിഡ് ഫോണിലോ ഫയലായി സേവ് ചെയ്യാം. ക്ലിപ്പ്ബോർഡിലേക്ക് കോപ്പിയും ചെയ്യാം.
                      </p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={handleCopyBackupToClipboard}
                        className="inline-flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold px-3 py-2 rounded-xl transition border border-slate-300 shadow-xs cursor-pointer"
                        title="ബാക്കപ്പ് ഡാറ്റ കോപ്പി ചെയ്യുക"
                      >
                        <Copy className="w-3.5 h-3.5 text-slate-600" />
                        <span>കോപ്പി</span>
                      </button>
                      <button
                        type="button"
                        onClick={handleDownloadBackup}
                        className="inline-flex items-center gap-1.5 bg-amber-700 hover:bg-amber-800 text-white text-xs font-bold px-3.5 py-2 rounded-xl transition shadow-xs cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>ഡൗൺലോഡ്</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* 2. Restore from File */}
                <div className="p-4 rounded-2xl border border-slate-200 hover:border-emerald-400 transition bg-slate-50/40">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h4 className="font-bold text-xs text-slate-900">
                        2. ബാക്കപ്പ് ഫയലിൽ നിന്ന് റീസ്റ്റോർ ചെയ്യുക (Restore)
                      </h4>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        നേരത്തെ ഡൗൺലോഡ് ചെയ്ത ബാക്കപ്പ് JSON ഫയൽ അപ്‌ലോഡ് ചെയ്ത് കണക്കുകൾ പുനഃസ്ഥാപിക്കാം (സെക്യൂരിറ്റി പിൻ ആവശ്യമാണ്).
                      </p>
                    </div>
                    <div>
                      <input
                        type="file"
                        ref={fileInputRef}
                        accept=".json,application/json"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="inline-flex items-center gap-1.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold px-3.5 py-2 rounded-xl transition shadow-xs cursor-pointer shrink-0"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>ഫയൽ തിരഞ്ഞെടുക്കുക</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* 3. Reset to zero */}
                <div className="p-4 rounded-2xl border border-slate-200 hover:border-rose-400 transition bg-slate-50/40">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h4 className="font-bold text-xs text-slate-900">
                        3. കണക്കുകൾ പൂജ്യത്തിലേക്ക് (₹0) റീസെറ്റ് ചെയ്യുക
                      </h4>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        എല്ലാ ഇടപാടുകളും നീക്കം ചെയ്ത് പുതിയ പെരുന്നാളിനായി വരവും ചിലവും പൂജ്യത്തിൽ (₹0) നിന്ന് ആരംഭിക്കുക.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={handleResetClick}
                      className="inline-flex items-center gap-1.5 bg-rose-700 hover:bg-rose-800 text-white text-xs font-bold px-3.5 py-2 rounded-xl transition shadow-xs cursor-pointer shrink-0"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>പൂജ്യത്തിലേക്ക് റീസെറ്റ്</span>
                    </button>
                  </div>
                </div>

                {/* 4. Emergency Rollback if Safety Snapshot Exists */}
                {hasSafetySnapshot && (
                  <div className="p-4 rounded-2xl border-2 border-indigo-200 hover:border-indigo-400 transition bg-indigo-50/50">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-indigo-200 text-indigo-900 text-[10px] font-black uppercase tracking-wider mb-1">
                          <RotateCcw className="w-3 h-3 text-indigo-700" />
                          <span>അടിയന്തിര സുരക്ഷാ സൗകര്യം (Rollback)</span>
                        </div>
                        <h4 className="font-bold text-xs text-indigo-950">
                          4. മുൻപത്തെ സുരക്ഷാ സ്നാപ്പ്ഷോട്ടിലേക്ക് തിരിച്ചെടുക്കുക
                        </h4>
                        <p className="text-[11px] text-indigo-800/80 mt-0.5">
                          അവസാനമായി റീസ്റ്റോർ ചെയ്യുന്നതിന് തൊട്ടുമുൻപ് സിസ്റ്റം ഓട്ടോമാറ്റിക്കായി സുരക്ഷിതമാക്കിയ സ്നാപ്പ്ഷോട്ട് തിരിച്ചെടുക്കാം.
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={handleRollbackToSnapshot}
                        className="inline-flex items-center gap-1.5 bg-indigo-800 hover:bg-indigo-900 text-white text-xs font-bold px-3.5 py-2 rounded-xl transition shadow-xs cursor-pointer shrink-0"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>റോൾബാക്ക് ചെയ്യുക</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* 5. Complete Source Code ZIP Download */}
                <div className="p-4 rounded-2xl border border-blue-200 hover:border-blue-400 transition bg-blue-50/50">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                    <div>
                      <h4 className="font-bold text-xs text-blue-950 flex items-center gap-1.5">
                        <Archive className="w-3.5 h-3.5 text-blue-700 shrink-0" />
                        <span>മുഴുവൻ Source Code ZIP ഡൗൺലോഡ് (Download Full Source Code)</span>
                      </h4>
                      <p className="text-[11px] text-blue-900/80 mt-0.5">
                        React, Firebase, PWA, Capacitor Android, GitHub Actions ഫയലുകൾ അടങ്ങിയ സമ്പൂർണ്ണ സോഴ്സ് കോഡ് ZIP ഡൗൺലോഡ് ചെയ്യാം.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        fetch('/manjankal-church-festival-accounts-2026.zip')
                          .then((res) => {
                            if (!res.ok) throw new Error('Download failed');
                            return res.blob();
                          })
                          .then((blob) => {
                            const url = window.URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = 'manjankal-church-festival-accounts-2026.zip';
                            document.body.appendChild(a);
                            a.click();
                            setTimeout(() => {
                              window.URL.revokeObjectURL(url);
                              document.body.removeChild(a);
                            }, 500);
                          })
                          .catch(() => {
                            window.open('https://ais-dev-5lgvomoatnfhvxd4wt7vrg-52722377901.asia-northeast1.run.app/manjankal-church-festival-accounts-2026.zip', '_blank');
                          });
                      }}
                      className="inline-flex items-center gap-1.5 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold px-3.5 py-2 rounded-xl transition shadow-xs cursor-pointer shrink-0 active:scale-95"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>ZIP ഡൗൺലോഡ് (6.37 MB)</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Sticky bottom close button */}
            <div className="sticky bottom-0 bg-white/95 backdrop-blur-xs pt-3 pb-1 border-t border-slate-100 mt-2 flex justify-end shrink-0 z-10">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 cursor-pointer active:scale-95 transition"
              >
                അടയ്ക്കുക
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
