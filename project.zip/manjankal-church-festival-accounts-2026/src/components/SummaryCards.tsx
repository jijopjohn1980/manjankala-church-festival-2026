import React, { useState, useMemo } from 'react';
import {
  YearAccountingData,
  FestivalYear,
  Heading,
  TransactionType,
} from '../types/festival';
import { formatINR, numberToMalayalamWords } from '../utils/numberToMalayalamWords';
import { HeadingTransactionsModal } from './HeadingTransactionsModal';
import {
  TrendingUp,
  TrendingDown,
  Wallet,
  Receipt,
  FileText,
  PieChart,
  ExternalLink,
  Info,
  Calendar,
  Plus,
  Layers,
  Sparkles,
} from 'lucide-react';

interface SummaryCardsProps {
  data: YearAccountingData;
  year: FestivalYear;
  onNavigateToIncome: () => void;
  onNavigateToExpense: () => void;
  onNavigateToReports: () => void;
  onNavigateToHeadings: () => void;
  onAddHeading: (heading: Omit<Heading, 'id'>) => void;
  onOpenAddIncome: () => void;
}

export const SummaryCards: React.FC<SummaryCardsProps> = ({
  data,
  year,
  onNavigateToIncome,
  onNavigateToExpense,
  onNavigateToReports,
  onNavigateToHeadings,
  onAddHeading,
  onOpenAddIncome,
}) => {
  // Selected Heading for detailed drill-down modal
  const [selectedHeading, setSelectedHeading] = useState<Heading | null>(null);

  // Quick Add Heading Modal state
  const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);
  const [quickAddType, setQuickAddType] = useState<TransactionType>('INCOME');
  const [quickAddName, setQuickAddName] = useState('');
  const [quickAddDesc, setQuickAddDesc] = useState('');

  // Overall Totals based on actual saved transactions (strictly 0 if no transactions)
  const totalIncome = data.incomes.reduce((acc, i) => acc + (i.amount || 0), 0);
  const totalExpense = data.expenses.reduce((acc, e) => acc + (e.amount || 0), 0);
  const balance = totalIncome - totalExpense;
  const isSurplus = balance >= 0;

  // Headings counts
  const incomeHeadingsCount = data.headings.filter((h) => h.type === 'INCOME').length;
  const expenseHeadingsCount = data.headings.filter((h) => h.type === 'EXPENSE').length;

  // SECTION 1: Income Item-wise Totals
  // Includes all user-created custom income headings plus any uncategorized incomes
  // Each heading | Number of receipts | Total amount
  const incomeHeadingsList = useMemo(() => {
    const list = data.headings
      .filter((h) => h.type === 'INCOME')
      .map((h) => {
        const matchingIncomes = data.incomes.filter(
          (i) => i.headingId === h.id || i.headingName === h.name
        );
        const total = matchingIncomes.reduce((sum, i) => sum + (i.amount || 0), 0);
        return {
          heading: h,
          count: matchingIncomes.length,
          total,
        };
      });

    // Reconcile: Include any uncategorized income transactions to guarantee totals reconcile 100%
    const uncategorizedIncomes = data.incomes.filter(
      (i) =>
        !data.headings.some(
          (h) => h.type === 'INCOME' && (h.id === i.headingId || h.name === i.headingName)
        )
    );
    if (uncategorizedIncomes.length > 0) {
      const uncategorizedTotal = uncategorizedIncomes.reduce(
        (sum, i) => sum + (i.amount || 0),
        0
      );
      list.push({
        heading: {
          id: 'uncategorized-income',
          name: 'മറ്റ് വരവുകൾ / ശീർഷകം ഇല്ലാത്തവ (Uncategorized)',
          description: 'ശീർഷകം നീക്കം ചെയ്യപ്പെട്ടതോ വ്യക്തമാക്കാത്തതോ ആയ വരവുകൾ',
          type: 'INCOME',
        },
        count: uncategorizedIncomes.length,
        total: uncategorizedTotal,
      });
    }

    return list.sort((a, b) => b.total - a.total);
  }, [data.headings, data.incomes]);

  // SECTION 2: Expense Item-wise Totals
  // Includes all user-created custom expense headings plus any uncategorized expenses
  // Each heading | Number of vouchers | Total amount
  const expenseHeadingsList = useMemo(() => {
    const list = data.headings
      .filter((h) => h.type === 'EXPENSE')
      .map((h) => {
        const matchingExpenses = data.expenses.filter(
          (e) => e.headingId === h.id || e.headingName === h.name
        );
        const total = matchingExpenses.reduce((sum, e) => sum + (e.amount || 0), 0);
        return {
          heading: h,
          count: matchingExpenses.length,
          total,
        };
      });

    // Reconcile: Include any uncategorized expense transactions to guarantee totals reconcile 100%
    const uncategorizedExpenses = data.expenses.filter(
      (e) =>
        !data.headings.some(
          (h) => h.type === 'EXPENSE' && (h.id === e.headingId || h.name === e.headingName)
        )
    );
    if (uncategorizedExpenses.length > 0) {
      const uncategorizedTotal = uncategorizedExpenses.reduce(
        (sum, e) => sum + (e.amount || 0),
        0
      );
      list.push({
        heading: {
          id: 'uncategorized-expense',
          name: 'മറ്റ് ചിലവുകൾ / ശീർഷകം ഇല്ലാത്തവ (Uncategorized)',
          description: 'ശീർഷകം നീക്കം ചെയ്യപ്പെട്ടതോ വ്യക്തമാക്കാത്തതോ ആയ ചിലവുകൾ',
          type: 'EXPENSE',
        },
        count: uncategorizedExpenses.length,
        total: uncategorizedTotal,
      });
    }

    return list.sort((a, b) => b.total - a.total);
  }, [data.headings, data.expenses]);

  const handleOpenQuickAdd = (type: TransactionType) => {
    setQuickAddType(type);
    setQuickAddName('');
    setQuickAddDesc('');
    setIsQuickAddOpen(true);
  };

  const handleQuickAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickAddName.trim()) return;

    onAddHeading({
      name: quickAddName.trim(),
      description: quickAddDesc.trim(),
      type: quickAddType,
    });

    setIsQuickAddOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* 1. Prominent Festival Period Banner (Requirement 1 & 6) */}
      <div className="bg-linear-to-r from-red-950 via-amber-950 to-red-950 text-white rounded-3xl p-5 shadow-sm border border-amber-400/40 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-500/20 text-amber-300 rounded-2xl border border-amber-400/30">
            <Calendar className="w-6 h-6" />
          </div>
          <div>
            <div className="text-[11px] font-bold text-amber-300 uppercase tracking-wider">
              2026 വാർഷിക പെരുന്നാൾ അക്കൗണ്ടിംഗ് കാലാവധി
            </div>
            <div className="text-xl sm:text-2xl font-black tracking-tight text-white mt-0.5">
              22-11-2026 to 10-12-2026
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-bold text-amber-200 bg-black/40 px-4 py-2 rounded-xl border border-amber-400/30">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>മഞ്ഞക്കാല മാർ ശെമവൂൻ ദെസ്തൂനി പള്ളി</span>
        </div>
      </div>

      {/* 2. Main Dashboard Highlights: 5 Key Metrics (Requirement 6) */}
      {/* Total Income, Total Expenses, Final Balance, Number of Income Headings, Number of Expense Headings */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Total Festival Income */}
        <div className="relative overflow-hidden bg-linear-to-br from-emerald-800 to-emerald-950 text-white rounded-3xl p-6 shadow-md border border-emerald-700/50">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-200">
              ആകെ പെരുന്നാൾ വരവ് (Total Income)
            </span>
            <div className="p-2.5 bg-emerald-700/60 rounded-2xl">
              <TrendingUp className="w-5 h-5 text-emerald-300" />
            </div>
          </div>
          <div className="text-3xl sm:text-4xl font-black tracking-tight text-white mb-2">
            {formatINR(totalIncome)}
          </div>
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-emerald-200/90 pt-3 border-t border-emerald-700/60 font-medium">
            <span className="flex items-center gap-1">
              <Receipt className="w-3.5 h-3.5" />
              രസീതുകൾ: <strong>{data.incomes.length} എണ്ണം</strong>
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onOpenAddIncome}
                className="inline-flex items-center gap-1 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black px-2.5 py-1 rounded-lg text-[11px] transition cursor-pointer shadow-xs"
                title="പുതിയ വരവ് രേഖപ്പെടുത്തുക (Add Income Transaction)"
              >
                <Plus className="w-3.5 h-3.5 text-slate-950" />
                <span>+ പുതിയ വരവ് രേഖപ്പെടുത്തുക</span>
              </button>
              <button
                type="button"
                onClick={onNavigateToIncome}
                className="text-xs font-bold text-amber-300 hover:text-white underline cursor-pointer"
              >
                രസീതുകൾ കാണുക →
              </button>
            </div>
          </div>
        </div>

        {/* Total Festival Expenses */}
        <div className="relative overflow-hidden bg-linear-to-br from-rose-900 to-red-950 text-white rounded-3xl p-6 shadow-md border border-rose-800/50">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-rose-200">
              ആകെ പെരുന്നാൾ ചിലവ് (Total Expenses)
            </span>
            <div className="p-2.5 bg-rose-800/60 rounded-2xl">
              <TrendingDown className="w-5 h-5 text-rose-300" />
            </div>
          </div>
          <div className="text-3xl sm:text-4xl font-black tracking-tight text-white mb-2">
            {formatINR(totalExpense)}
          </div>
          <div className="flex items-center justify-between text-xs text-rose-200/90 pt-3 border-t border-rose-800/60 font-medium">
            <span className="flex items-center gap-1">
              <FileText className="w-3.5 h-3.5" />
              വൗച്ചറുകൾ: <strong>{data.expenses.length} എണ്ണം</strong>
            </span>
            <button
              onClick={onNavigateToExpense}
              className="text-xs font-bold text-amber-300 hover:text-white underline cursor-pointer"
            >
              വൗച്ചറുകൾ കാണുക →
            </button>
          </div>
        </div>

        {/* Final Festival Balance */}
        <div
          className={`relative overflow-hidden rounded-3xl p-6 shadow-md border ${
            isSurplus
              ? 'bg-linear-to-br from-amber-900 via-amber-950 to-amber-950 text-white border-amber-600/40'
              : 'bg-linear-to-br from-red-950 via-slate-900 to-black text-white border-red-500/50'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-200">
              പെരുന്നാൾ നീക്കിയിരിപ്പ് (Final Balance)
            </span>
            <div className="p-2.5 bg-amber-700/40 rounded-2xl">
              <Wallet className="w-5 h-5 text-amber-300" />
            </div>
          </div>
          <div
            className={`text-3xl sm:text-4xl font-black tracking-tight mb-2 ${
              isSurplus ? 'text-amber-300' : 'text-red-400'
            }`}
          >
            {formatINR(balance)}
          </div>
          <div className="flex items-center justify-between text-xs text-amber-200/90 pt-3 border-t border-amber-700/40 font-medium">
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-400/20 text-amber-200">
              {isSurplus ? '✓ നീക്കിയിരിപ്പ് തുക (Surplus)' : '⚠ ചിലവ് കവിഞ്ഞു (Deficit)'}
            </span>
            <button
              onClick={onNavigateToReports}
              className="text-xs font-bold text-amber-300 hover:text-white underline cursor-pointer"
            >
              ഓഡിറ്റ് റിപ്പോർട്ട് →
            </button>
          </div>
        </div>
      </div>

      {/* Headings Counts Sub-strip (Requirement 6) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-white rounded-2xl p-4 border border-emerald-200 shadow-2xs flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-black">
              📥
            </div>
            <div>
              <span className="text-xs text-slate-500 font-medium block">
                വരവ് ശീർഷകങ്ങളുടെ എണ്ണം (Income Headings)
              </span>
              <span className="text-xl font-black text-emerald-900">
                {incomeHeadingsCount} <span className="text-xs font-semibold text-slate-500">ശീർഷകങ്ങൾ</span>
              </span>
            </div>
          </div>
          <button
            onClick={() => handleOpenQuickAdd('INCOME')}
            className="inline-flex items-center gap-1 text-xs font-bold bg-emerald-700 hover:bg-emerald-800 text-white px-3 py-1.5 rounded-xl transition cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ പുതിയത്</span>
          </button>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-rose-200 shadow-2xs flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-800 flex items-center justify-center font-black">
              📤
            </div>
            <div>
              <span className="text-xs text-slate-500 font-medium block">
                ചിലവ് ശീർഷകങ്ങളുടെ എണ്ണം (Expense Headings)
              </span>
              <span className="text-xl font-black text-rose-900">
                {expenseHeadingsCount} <span className="text-xs font-semibold text-slate-500">ശീർഷകങ്ങൾ</span>
              </span>
            </div>
          </div>
          <button
            onClick={() => handleOpenQuickAdd('EXPENSE')}
            className="inline-flex items-center gap-1 text-xs font-bold bg-rose-700 hover:bg-rose-800 text-white px-3 py-1.5 rounded-xl transition cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ പുതിയത്</span>
          </button>
        </div>
      </div>

      {/* =========================================================================
          TWO SEPARATE DETAILED SUMMARY SECTIONS:
          SECTION 1: INCOME ITEM-WISE TOTALS
          SECTION 2: EXPENSE ITEM-WISE TOTALS
          (Requirement 3, 4, 5, 7)
          ========================================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* =========================================================================
            SECTION 1: INCOME ITEM-WISE TOTALS (വരവ് ശീർഷകാടിസ്ഥാനത്തിലുള്ള ആകെത്തുക)
            Each heading | Number of receipts | Total amount
            ========================================================================= */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-emerald-200 flex flex-col justify-between">
          <div>
            {/* Section Header */}
            <div className="flex items-center justify-between mb-3 pb-3 border-b border-emerald-100">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 bg-emerald-100 rounded-2xl text-emerald-800">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[10px] font-black tracking-wider text-emerald-700 uppercase">
                    INCOME ITEM-WISE TOTALS
                  </div>
                  <h2 className="text-base font-black text-slate-900">
                    വരവ് ശീർഷകാടിസ്ഥാനത്തിലുള്ള കണക്ക്
                  </h2>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {/* Existing Add Income Heading Feature - Kept Unchanged */}
                <button
                  type="button"
                  onClick={() => handleOpenQuickAdd('INCOME')}
                  className="inline-flex items-center gap-1 text-xs font-bold bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 px-3 py-1.5 rounded-xl transition cursor-pointer shadow-2xs"
                  title="പുതിയ വരവ് ശീർഷകം ചേർക്കുക (Add Income Heading)"
                >
                  <Layers className="w-3.5 h-3.5 text-emerald-700" />
                  <span>+ വരവ് ശീർഷകം (Add Heading)</span>
                </button>

                {/* Clearly Labelled Button: + Add Income Transaction / + പുതിയ വരവ് രേഖപ്പെടുത്തുക */}
                <button
                  type="button"
                  onClick={onOpenAddIncome}
                  className="inline-flex items-center gap-1.5 text-xs font-black bg-emerald-700 hover:bg-emerald-800 text-white px-3.5 py-1.5 rounded-xl transition cursor-pointer shadow-sm hover:shadow-md"
                  title="പുതിയ വരവ് രേഖപ്പെടുത്തുക (Add Income Transaction)"
                >
                  <Plus className="w-4 h-4 text-emerald-200" />
                  <span>+ Add Income Transaction / + പുതിയ വരവ് രേഖപ്പെടുത്തുക</span>
                </button>
              </div>
            </div>

            <div className="text-[11px] text-emerald-950 bg-emerald-50/70 p-2.5 rounded-xl mb-4 flex items-center justify-between font-medium border border-emerald-200/60">
              <span className="flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                <span>ശീർഷകത്തിൽ ക്ലിക്ക് ചെയ്താൽ അതിന്റെ കീഴിലുള്ള എല്ലാ വരവ് രസീതുകളും കാണാം.</span>
              </span>
              <span className="text-[10px] text-emerald-800 font-bold">ഇടപാടുകൾ</span>
            </div>

            {/* Empty State when user hasn't added custom income headings yet */}
            {incomeHeadingsList.length === 0 ? (
              <div className="p-8 text-center border-2 border-dashed border-emerald-200 rounded-2xl bg-emerald-50/30 my-4">
                <div className="w-10 h-10 bg-emerald-100 text-emerald-800 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Plus className="w-5 h-5" />
                </div>
                <h4 className="font-bold text-slate-800 text-sm mb-1">
                  വരവ് ശീർഷകങ്ങൾ ഒന്നും ചേർത്തിട്ടില്ല
                </h4>
                <p className="text-xs text-slate-500 mb-4 max-w-sm mx-auto">
                  ഡിഫോൾട്ട് കാറ്റഗറികൾ പൂർണ്ണമായി ഒഴിവാക്കിയിരിക്കുന്നു. നിങ്ങളുടെ സ്വന്തം വരവ് ശീർഷകം (ഉദാ: നേർച്ച, ലേലം, വഴിപാടുകൾ, സ്പോൺസർഷിപ്പ്...) ഇവിടെ ചേർക്കുക.
                </p>
                <button
                  type="button"
                  onClick={() => handleOpenQuickAdd('INCOME')}
                  className="inline-flex items-center gap-1.5 text-xs font-bold bg-emerald-700 hover:bg-emerald-800 text-white px-4 py-2 rounded-xl transition cursor-pointer shadow-xs"
                >
                  <Plus className="w-4 h-4" />
                  <span>ആദ്യത്തെ വരവ് ശീർഷകം ചേർക്കുക</span>
                </button>
              </div>
            ) : (
              /* List of Custom Income Headings with: Each heading | Number of receipts | Total amount */
              <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
                {incomeHeadingsList.map((item, idx) => {
                  const pct = totalIncome > 0 ? ((item.total / totalIncome) * 100).toFixed(1) : '0';
                  return (
                    <div
                      key={item.heading.id}
                      onClick={() => setSelectedHeading(item.heading)}
                      className="p-3.5 rounded-2xl bg-slate-50/90 hover:bg-emerald-50/90 transition-all border border-slate-200/80 hover:border-emerald-300 cursor-pointer group shadow-2xs"
                    >
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2.5">
                          <span className="w-6 h-6 flex items-center justify-center rounded-lg bg-emerald-100 text-xs font-black text-emerald-800 group-hover:bg-emerald-600 group-hover:text-white transition">
                            {idx + 1}
                          </span>
                          <div>
                            {/* Heading Name */}
                            <div className="font-black text-slate-900 text-sm group-hover:text-emerald-900 transition flex items-center gap-1.5">
                              <span>{item.heading.name}</span>
                              <ExternalLink className="w-3.5 h-3.5 text-slate-400 group-hover:text-emerald-700 transition" />
                            </div>
                            {/* Number of Receipts */}
                            <div className="text-[11px] text-slate-500 font-medium">
                              രസീതുകളുടെ എണ്ണം:{' '}
                              <strong className="text-slate-800 font-bold">{item.count} എണ്ണം</strong>
                            </div>
                          </div>
                        </div>

                        {/* Total Amount Collected */}
                        <div className="text-right">
                          <div className="font-black text-emerald-800 text-base">
                            {formatINR(item.total)}
                          </div>
                          <div className="text-[10px] text-slate-400 font-semibold">
                            ആകെ വരവിന്റെ {pct}%
                          </div>
                        </div>
                      </div>

                      {/* Progress Bar */}
                      <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-emerald-600 h-full rounded-full transition-all duration-300"
                          style={{ width: `${Math.min(100, Math.max(0, Number(pct)))}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* SECTION 1: Grand Total Footer */}
          <div className="mt-5 pt-4 border-t-2 border-emerald-200 bg-emerald-50/90 -mx-6 -mb-6 p-4 rounded-b-3xl">
            <div className="flex items-center justify-between text-xs font-bold text-emerald-950 mb-1">
              <span className="uppercase tracking-wider">ആകെ രസീതുകൾ (Total Receipts):</span>
              <span className="font-black text-sm text-emerald-900">{data.incomes.length} എണ്ണം</span>
            </div>
            <div className="flex items-center justify-between pt-2 border-t border-emerald-200/80">
              <div>
                <span className="text-sm font-black text-emerald-950 block">
                  ആകെ വരവ് തുക (Grand Total Income):
                </span>
                <span className="text-[10px] text-emerald-800 font-medium">
                  {numberToMalayalamWords(totalIncome)}
                </span>
              </div>
              <span className="text-2xl font-black text-emerald-900 shrink-0">
                {formatINR(totalIncome)}
              </span>
            </div>
          </div>
        </div>

        {/* =========================================================================
            SECTION 2: EXPENSE ITEM-WISE TOTALS (ചിലവ് ശീർഷകാടിസ്ഥാനത്തിലുള്ള ആകെത്തുക)
            Each heading | Number of vouchers | Total amount
            ========================================================================= */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-rose-200 flex flex-col justify-between">
          <div>
            {/* Section Header */}
            <div className="flex items-center justify-between mb-3 pb-3 border-b border-rose-100">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 bg-rose-100 rounded-2xl text-rose-800">
                  <TrendingDown className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[10px] font-black tracking-wider text-rose-700 uppercase">
                    EXPENSE ITEM-WISE TOTALS
                  </div>
                  <h2 className="text-base font-black text-slate-900">
                    ചിലവ് ശീർഷകാടിസ്ഥാനത്തിലുള്ള കണക്ക്
                  </h2>
                </div>
              </div>

              <button
                type="button"
                onClick={() => handleOpenQuickAdd('EXPENSE')}
                className="inline-flex items-center gap-1 text-xs font-bold bg-rose-700 hover:bg-rose-800 text-white px-3 py-1.5 rounded-xl transition cursor-pointer shadow-2xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ ചിലവ് ശീർഷകം</span>
              </button>
            </div>

            <div className="text-[11px] text-rose-950 bg-rose-50/70 p-2.5 rounded-xl mb-4 flex items-center justify-between font-medium border border-rose-200/60">
              <span className="flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-rose-700 shrink-0" />
                <span>ശീർഷകത്തിൽ ക്ലിക്ക് ചെയ്താൽ അതിന്റെ കീഴിലുള്ള എല്ലാ ചിലവ് വൗച്ചറുകളും കാണാം.</span>
              </span>
              <span className="text-[10px] text-rose-800 font-bold">ഇടപാടുകൾ</span>
            </div>

            {/* Empty State when user hasn't added custom expense headings yet */}
            {expenseHeadingsList.length === 0 ? (
              <div className="p-8 text-center border-2 border-dashed border-rose-200 rounded-2xl bg-rose-50/30 my-4">
                <div className="w-10 h-10 bg-rose-100 text-rose-800 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Plus className="w-5 h-5" />
                </div>
                <h4 className="font-bold text-slate-800 text-sm mb-1">
                  ചിലവ് ശീർഷകങ്ങൾ ഒന്നും ചേർത്തിട്ടില്ല
                </h4>
                <p className="text-xs text-slate-500 mb-4 max-w-sm mx-auto">
                  ഡിഫോൾട്ട് കാറ്റഗറികൾ പൂർണ്ണമായി ഒഴിവാക്കിയിരിക്കുന്നു. നിങ്ങളുടെ സ്വന്തം ചിലവ് ശീർഷകം (ഉദാ: പന്തൽ, ലൈറ്റ് & സൗണ്ട്, അന്നദാനം, കരിമരുന്ന്...) ഇവിടെ ചേർക്കുക.
                </p>
                <button
                  type="button"
                  onClick={() => handleOpenQuickAdd('EXPENSE')}
                  className="inline-flex items-center gap-1.5 text-xs font-bold bg-rose-700 hover:bg-rose-800 text-white px-4 py-2 rounded-xl transition cursor-pointer shadow-xs"
                >
                  <Plus className="w-4 h-4" />
                  <span>ആദ്യത്തെ ചിലവ് ശീർഷകം ചേർക്കുക</span>
                </button>
              </div>
            ) : (
              /* List of Custom Expense Headings with: Each heading | Number of vouchers | Total amount */
              <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
                {expenseHeadingsList.map((item, idx) => {
                  const pct = totalExpense > 0 ? ((item.total / totalExpense) * 100).toFixed(1) : '0';
                  return (
                    <div
                      key={item.heading.id}
                      onClick={() => setSelectedHeading(item.heading)}
                      className="p-3.5 rounded-2xl bg-slate-50/90 hover:bg-rose-50/90 transition-all border border-slate-200/80 hover:border-rose-300 cursor-pointer group shadow-2xs"
                    >
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2.5">
                          <span className="w-6 h-6 flex items-center justify-center rounded-lg bg-rose-100 text-xs font-black text-rose-800 group-hover:bg-rose-600 group-hover:text-white transition">
                            {idx + 1}
                          </span>
                          <div>
                            {/* Heading Name */}
                            <div className="font-black text-slate-900 text-sm group-hover:text-rose-900 transition flex items-center gap-1.5">
                              <span>{item.heading.name}</span>
                              <ExternalLink className="w-3.5 h-3.5 text-slate-400 group-hover:text-rose-700 transition" />
                            </div>
                            {/* Number of Vouchers */}
                            <div className="text-[11px] text-slate-500 font-medium">
                              വൗച്ചറുകളുടെ എണ്ണം:{' '}
                              <strong className="text-slate-800 font-bold">{item.count} എണ്ണം</strong>
                            </div>
                          </div>
                        </div>

                        {/* Total Amount Spent */}
                        <div className="text-right">
                          <div className="font-black text-rose-800 text-base">
                            {formatINR(item.total)}
                          </div>
                          <div className="text-[10px] text-slate-400 font-semibold">
                            ആകെ ചിലവിന്റെ {pct}%
                          </div>
                        </div>
                      </div>

                      {/* Progress Bar */}
                      <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-rose-600 h-full rounded-full transition-all duration-300"
                          style={{ width: `${Math.min(100, Math.max(0, Number(pct)))}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* SECTION 2: Grand Total Footer */}
          <div className="mt-5 pt-4 border-t-2 border-rose-200 bg-rose-50/90 -mx-6 -mb-6 p-4 rounded-b-3xl">
            <div className="flex items-center justify-between text-xs font-bold text-rose-950 mb-1">
              <span className="uppercase tracking-wider">ആകെ വൗച്ചറുകൾ (Total Vouchers):</span>
              <span className="font-black text-sm text-rose-900">{data.expenses.length} എണ്ണം</span>
            </div>
            <div className="flex items-center justify-between pt-2 border-t border-rose-200/80">
              <div>
                <span className="text-sm font-black text-rose-950 block">
                  ആകെ ചിലവ് തുക (Grand Total Expenditure):
                </span>
                <span className="text-[10px] text-rose-800 font-medium">
                  {numberToMalayalamWords(totalExpense)}
                </span>
              </div>
              <span className="text-2xl font-black text-rose-900 shrink-0">
                {formatINR(totalExpense)}
              </span>
            </div>
          </div>
        </div>

      </div>

      {/* Quick Festival Status Bar */}
      <div className="bg-amber-100/60 border border-amber-300/80 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-amber-950 font-medium">
        <div className="flex items-center gap-2">
          <PieChart className="w-4 h-4 text-amber-700 shrink-0" />
          <span>
            ഈ കണക്കുകൾ <strong>മഞ്ഞക്കാല മാർ ശെമവൂൻ ദെസ്തൂനി പള്ളി</strong> 2026 വാർഷിക പെരുന്നാൾ സമിതിയുടെ ഔദ്യോഗിക പരിശോധനയ്ക്ക് വിധേയമാണ്.
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span className="bg-white px-2.5 py-1 rounded-lg border border-amber-300 font-bold">
            വരവ്: {formatINR(totalIncome)}
          </span>
          <span className="text-slate-400">-</span>
          <span className="bg-white px-2.5 py-1 rounded-lg border border-amber-300 font-bold">
            ചിലവ്: {formatINR(totalExpense)}
          </span>
          <span className="text-slate-400">=</span>
          <span className="bg-amber-800 text-white px-2.5 py-1 rounded-lg font-bold">
            നീക്കിയിരിപ്പ്: {formatINR(balance)}
          </span>
        </div>
      </div>

      {/* Quick Add Heading Modal */}
      {isQuickAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-amber-200">
            <h3 className="text-base font-bold text-slate-900 mb-1">
              {quickAddType === 'INCOME' ? 'പുതിയ വരവ് ശീർഷകം ചേർക്കുക' : 'പുതിയ ചിലവ് ശീർഷകം ചേർക്കുക'}
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              2026 പെരുന്നാൾ കണക്കുകൾക്കായി നിങ്ങളുടെ സ്വന്തം ശീർഷകം നൽകുക.
            </p>

            <form onSubmit={handleQuickAddSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ഇനം (Type)
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setQuickAddType('INCOME')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition cursor-pointer ${
                      quickAddType === 'INCOME'
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'border-slate-300 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    📥 വരവ് (Income)
                  </button>
                  <button
                    type="button"
                    onClick={() => setQuickAddType('EXPENSE')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition cursor-pointer ${
                      quickAddType === 'EXPENSE'
                        ? 'bg-rose-600 text-white border-rose-600'
                        : 'border-slate-300 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    📤 ചിലവ് (Expense)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ശീർഷകത്തിന്റെ പേര് *
                </label>
                <input
                  type="text"
                  required
                  placeholder={
                    quickAddType === 'INCOME'
                      ? 'ഉദാ: നേർച്ച പിരിവ് / പെരുന്നാൾ ലേലം / സംഭാവന'
                      : 'ഉദാ: പന്തൽ നിർമ്മാണം / ലൈറ്റ് & സൗണ്ട് / അന്നദാനം'
                  }
                  value={quickAddName}
                  onChange={(e) => setQuickAddName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-amber-500 focus:outline-hidden font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  വിവരണം (ഓപ്ഷണൽ)
                </label>
                <textarea
                  rows={2}
                  placeholder="ശീർഷകത്തെക്കുറിച്ചുള്ള കുറിപ്പ്..."
                  value={quickAddDesc}
                  onChange={(e) => setQuickAddDesc(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsQuickAddOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  റദ്ദാക്കുക
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold bg-amber-700 hover:bg-amber-800 text-white cursor-pointer shadow-sm"
                >
                  ശീർഷകം ചേർക്കുക
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Drill-down Modal for Selected Heading */}
      {selectedHeading && (
        <HeadingTransactionsModal
          heading={selectedHeading}
          incomes={data.incomes}
          expenses={data.expenses}
          year={year}
          headings={data.headings}
          onClose={() => setSelectedHeading(null)}
        />
      )}

      {/* Floating Action Button for Add Income Transaction on Dashboard */}
      <div className="fixed bottom-6 right-6 z-40">
        <button
          type="button"
          onClick={onOpenAddIncome}
          className="group flex items-center gap-2.5 bg-emerald-700 hover:bg-emerald-800 text-white px-4 py-3 sm:px-5 sm:py-3.5 rounded-2xl shadow-xl hover:shadow-2xl border-2 border-emerald-400/60 transition-all hover:scale-105 active:scale-95 cursor-pointer"
          title="പുതിയ വരവ് രേഖപ്പെടുത്തുക (Add Income Transaction)"
        >
          <div className="p-1 bg-emerald-600 rounded-lg group-hover:bg-emerald-500 transition">
            <Plus className="w-5 h-5 text-white" />
          </div>
          <div className="text-left">
            <div className="text-xs sm:text-sm font-black tracking-tight leading-tight">
              + Add Income Transaction
            </div>
            <div className="text-[10px] text-emerald-200 font-bold leading-tight">
              + പുതിയ വരവ് രേഖപ്പെടുത്തുക
            </div>
          </div>
        </button>
      </div>
    </div>
  );
};
