import React, { useState } from 'react';
import { FestivalYear, SyncStatus } from '../types/festival';
import { CHURCH_DETAILS } from '../utils/storage';
import {
  Calendar,
  Plus,
  Database,
  Sparkles,
  ShieldCheck,
  LogOut,
  UserCheck,
  HardDrive,
  CloudCheck,
  RefreshCw,
  WifiOff,
  AlertTriangle,
  Download,
} from 'lucide-react';
import { SUPER_ADMIN_EMAIL } from '../utils/auth';
import { PWAInstallButton } from './PWAInstallButton';

interface HeaderProps {
  years: FestivalYear[];
  activeYear: FestivalYear;
  onSelectYear: (yearId: string) => void;
  onAddYear: (year: FestivalYear) => void;
  onOpenBackupModal: () => void;
  onOpenSecurityModal: () => void;
  onLogout: () => void;
  activeTab: 'DASHBOARD' | 'INCOME' | 'EXPENSE' | 'HEADINGS' | 'REPORTS' | 'AUDIT';
  setActiveTab: (tab: 'DASHBOARD' | 'INCOME' | 'EXPENSE' | 'HEADINGS' | 'REPORTS' | 'AUDIT') => void;
  syncStatus: SyncStatus;
  isOnline: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  years,
  activeYear,
  onSelectYear,
  onAddYear,
  onOpenBackupModal,
  onOpenSecurityModal,
  onLogout,
  activeTab,
  setActiveTab,
  syncStatus,
  isOnline,
}) => {
  const [showAddYearModal, setShowAddYearModal] = useState(false);
  const [newYearName, setNewYearName] = useState('');
  const [newYearId, setNewYearId] = useState('');
  const [newStartDate, setNewStartDate] = useState('');
  const [newEndDate, setNewEndDate] = useState('');
  const [newTheme, setNewTheme] = useState('');

  const handleCreateYear = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newYearId.trim() || !newYearName.trim()) return;

    const newYear: FestivalYear = {
      id: newYearId.trim(),
      yearName: newYearName.trim(),
      startDate: newStartDate || `${newYearId}-02-01`,
      endDate: newEndDate || `${newYearId}-02-08`,
      theme: newTheme.trim() || `${newYearName} കണക്കുകൾ`,
    };

    onAddYear(newYear);
    setShowAddYearModal(false);
    setNewYearName('');
    setNewYearId('');
    setNewStartDate('');
    setNewEndDate('');
    setNewTheme('');
  };

  return (
    <header className="bg-white border-b border-amber-200 shadow-sm no-print">
      {/* Top Banner with Church Heritage imagery & Emblem */}
      <div className="relative overflow-hidden bg-linear-to-r from-red-950 via-red-900 to-amber-950 text-white">
        {/* Subtle background church photo with luxury gradient */}
        <div className="absolute inset-0 opacity-20 pointer-events-none mix-blend-overlay">
          <img
            src={CHURCH_DETAILS.photoUrl}
            alt="മഞ്ഞക്കാല പള്ളി"
            className="w-full h-full object-cover object-center"
          />
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-5">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            
            {/* Logo and Church Name */}
            <div className="flex items-center gap-4 text-center md:text-left">
              <div className="relative shrink-0">
                <img
                  src={CHURCH_DETAILS.logoUrl}
                  alt="മാർ ശെമവൂൻ ദെസ്തൂനി പള്ളി മുദ്ര"
                  className="w-20 h-20 sm:w-24 sm:h-24 object-contain rounded-full bg-white/95 p-1 shadow-lg ring-2 ring-amber-400/80"
                />
              </div>
              <div>
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-400/20 text-amber-200 border border-amber-400/40 mb-1">
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>2026 വാർഷിക പെരുന്നാൾ അക്കൗണ്ട്സ് • 22-11-2026 to 10-12-2026</span>
                </div>
                <h1 className="text-xl sm:text-2xl md:text-3xl font-extrabold tracking-tight text-white drop-shadow-xs">
                  {CHURCH_DETAILS.nameMl}
                </h1>
                <p className="text-xs sm:text-sm text-amber-200 font-medium">
                  {CHURCH_DETAILS.subMl} • വാർഷിക പെരുന്നാൾ വരവ് ചിലവ് കണക്കുകൾ
                </p>
              </div>
            </div>

            {/* Actions: Period, Super Admin, Security & Backup */}
            <div className="flex flex-wrap items-center gap-2 bg-black/40 backdrop-blur-md p-2.5 rounded-2xl border border-amber-500/40">
              <div className="flex flex-col text-left px-2 border-r border-amber-500/30 pr-3">
                <span className="text-[10px] uppercase font-bold tracking-wider text-amber-300">
                  പെരുന്നാൾ കാലാവധി
                </span>
                <span className="text-sm font-black text-white tracking-wide flex items-center gap-1">
                  <Calendar className="w-4 h-4 text-amber-400" />
                  22-11-2026 to 10-12-2026
                </span>
              </div>

              {/* Super Admin Badge */}
              <div className="hidden lg:flex flex-col text-left px-2 border-r border-amber-500/30 pr-3">
                <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-300 flex items-center gap-1">
                  <UserCheck className="w-3 h-3" /> സൂപ്പർ അഡ്മിൻ
                </span>
                <span className="text-xs font-bold text-white truncate max-w-[150px]">
                  {SUPER_ADMIN_EMAIL}
                </span>
              </div>

              {/* Security Audit Button */}
              <button
                type="button"
                onClick={onOpenSecurityModal}
                className="inline-flex items-center gap-1.5 text-xs font-bold bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-200 px-3 py-2 rounded-xl transition border border-indigo-400/30 cursor-pointer"
                title="സുരക്ഷാ ഓഡിറ്റും ക്രമീകരണങ്ങളും"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-indigo-300" />
                <span className="hidden sm:inline">സുരക്ഷ</span>
              </button>

              {/* In-App PWA Install Button */}
              <PWAInstallButton />

              {/* Prominent Direct Download Source ZIP Button */}
              <a
                href="/download-zip"
                download="manjankal-church-festival-accounts-2026.zip"
                className="inline-flex items-center gap-1.5 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-2 rounded-xl transition shadow-md border border-emerald-400/50 cursor-pointer active:scale-95"
                title="സമ്പൂർണ്ണ Source Code ZIP ഡൗൺലോഡ് ചെയ്യുക"
              >
                <Download className="w-3.5 h-3.5 text-white animate-bounce" />
                <span>ZIP ഡൗൺലോഡ്</span>
              </a>

              {/* Backup & Restore Button */}
              <button
                type="button"
                onClick={onOpenBackupModal}
                className="inline-flex items-center gap-1.5 text-xs font-bold bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 px-3 py-2 rounded-xl transition border border-amber-400/30 cursor-pointer"
                title="ഡാറ്റ ബാക്കപ്പ് & റീസ്റ്റോർ"
              >
                <Database className="w-3.5 h-3.5 text-amber-300" />
                <span>ബാക്കപ്പ്</span>
              </button>

              {/* Logout Button */}
              <button
                type="button"
                onClick={onLogout}
                className="inline-flex items-center gap-1 text-xs font-bold bg-red-800/40 hover:bg-red-800/70 text-red-200 px-2.5 py-2 rounded-xl transition border border-red-400/30 cursor-pointer"
                title="ലോഗൗട്ട് ചെയ്യുക"
              >
                <LogOut className="w-3.5 h-3.5 text-red-300" />
                <span className="hidden sm:inline">ലോഗൗട്ട്</span>
              </button>
            </div>

          </div>
        </div>

        {/* Current Active Festival Year & Sync Status Sub-bar */}
        <div className="bg-red-950/95 border-t border-amber-500/30 px-4 py-2 text-xs text-amber-100 flex flex-wrap items-center justify-between gap-2 max-w-7xl mx-auto font-medium">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-extrabold text-amber-300 bg-amber-950/80 px-2.5 py-0.5 rounded-lg border border-amber-400/40">
              2026 വാർഷിക പെരുന്നാൾ
            </span>
            <span className="text-amber-400">•</span>
            <span className="font-bold text-white">
              കാലാവധി: <span className="text-amber-300 font-extrabold">22-11-2026 to 10-12-2026</span>
            </span>
          </div>

          {/* Requirement 4: Visible Synchronization Status Badge */}
          <div className="flex items-center gap-2 flex-wrap">
            {!isOnline && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-rose-900/90 text-rose-200 border border-rose-400 text-[10px] font-bold">
                <WifiOff className="w-3 h-3 text-rose-400" />
                <span>ഓഫ്‌ലൈൻ (Offline)</span>
              </span>
            )}

            {syncStatus === 'STORAGE_FAILED' ? (
              <span
                className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-rose-950/90 text-rose-200 border-2 border-rose-500 text-[11px] font-black animate-pulse shadow-sm"
                title="ലോക്കൽ സ്റ്റോറേജ് സംഭരണം പരാജയപ്പെട്ടു! ഉടൻ ബാക്കപ്പ് ഫയൽ ഡൗൺലോഡ് ചെയ്യുക."
              >
                <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                <span>സംഭരണ തകരാർ (Storage Failed • Quota Exceeded)</span>
              </span>
            ) : syncStatus === 'SYNCED_FIREBASE' ? (
              <span
                className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-emerald-950/90 text-emerald-300 border border-emerald-400/80 text-[11px] font-bold shadow-xs"
                title="എല്ലാ കണക്കുകളും മുംബൈ ക്ലൗഡ് ഡാറ്റാബേസിൽ (asia-south1) ഭദ്രമായി സൂക്ഷിച്ചു."
              >
                <CloudCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>ഫയർബേസിലേക്ക് സിങ്ക് ചെയ്തു (Synced to Firebase)</span>
              </span>
            ) : syncStatus === 'SYNC_PENDING' ? (
              <span
                className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-sky-950/90 text-sky-200 border border-sky-400/80 text-[11px] font-bold animate-pulse shadow-xs"
                title="പുതിയ മാറ്റങ്ങൾ ക്ലൗഡിലേക്ക് സിങ്ക് ചെയ്യാനുണ്ട്. ബ്രൗസർ ക്ലോസ് ചെയ്യരുത്."
              >
                <RefreshCw className="w-3.5 h-3.5 text-sky-400 animate-spin" />
                <span>ക്ലൗഡ് സിങ്ക് ബാക്കി (Sync pending)</span>
              </span>
            ) : (
              <span
                className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-black/60 text-amber-300 border border-amber-400/80 text-[11px] font-bold shadow-xs"
                title="കണക്കുകൾ ഈ ബ്രൗസറിൽ പ്രാദേശികമായി സൂക്ഷിച്ചിരിക്കുന്നു. ക്ലൗഡിലേക്ക് അപ്‌ലോഡ് ചെയ്തിട്ടില്ല."
              >
                <HardDrive className="w-3.5 h-3.5 text-amber-400" />
                <span>പ്രാദേശികമായി സൂക്ഷിച്ചു (Saved locally • Not in Cloud)</span>
              </span>
            )}
          </div>

          <div className="text-[11px] text-emerald-300 flex items-center gap-1 font-semibold">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>സൂപ്പർ അഡ്മിൻ സംരക്ഷണം സജീവം ({SUPER_ADMIN_EMAIL})</span>
          </div>
        </div>
      </div>

      {/* Navigation Tabs - Pure Malayalam */}
      <div className="bg-amber-50/80 border-b border-amber-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <nav className="flex space-x-1 sm:space-x-3 overflow-x-auto py-2">
            <button
              onClick={() => setActiveTab('DASHBOARD')}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer shrink-0 ${
                activeTab === 'DASHBOARD'
                  ? 'bg-red-900 text-white shadow-sm'
                  : 'text-slate-700 hover:bg-amber-200/60'
              }`}
            >
              📊 പ്രധാന ഡാഷ്‌ബോർഡ്
            </button>
            <button
              onClick={() => setActiveTab('INCOME')}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer shrink-0 ${
                activeTab === 'INCOME'
                  ? 'bg-emerald-700 text-white shadow-sm'
                  : 'text-slate-700 hover:bg-amber-200/60'
              }`}
            >
              📥 പെരുന്നാൾ വരവുകൾ
            </button>
            <button
              onClick={() => setActiveTab('EXPENSE')}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer shrink-0 ${
                activeTab === 'EXPENSE'
                  ? 'bg-rose-800 text-white shadow-sm'
                  : 'text-slate-700 hover:bg-amber-200/60'
              }`}
            >
              📤 പെരുന്നാൾ ചിലവുകൾ
            </button>
            <button
              onClick={() => setActiveTab('HEADINGS')}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer shrink-0 ${
                activeTab === 'HEADINGS'
                  ? 'bg-amber-800 text-white shadow-sm'
                  : 'text-slate-700 hover:bg-amber-200/60'
              }`}
            >
              🏷️ ശീർഷക മാനേജ്‌മെന്റ്
            </button>
            <button
              onClick={() => setActiveTab('REPORTS')}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer shrink-0 ${
                activeTab === 'REPORTS'
                  ? 'bg-indigo-900 text-white shadow-sm'
                  : 'text-slate-700 hover:bg-amber-200/60'
              }`}
            >
              📑 റിപ്പോർട്ടുകൾ
            </button>
            <button
              onClick={() => setActiveTab('AUDIT')}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer shrink-0 flex items-center gap-1.5 ${
                activeTab === 'AUDIT'
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'text-slate-700 hover:bg-amber-200/60'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-500" />
              <span>📜 ഓഡിറ്റ് ലോഗ്</span>
            </button>
          </nav>
        </div>
      </div>

      {/* Add New Festival Year Modal */}
      {showAddYearModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-amber-200">
            <h3 className="text-lg font-bold text-slate-900 mb-1">
              പുതിയ പെരുന്നാൾ വർഷം ആരംഭിക്കുക
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              ഓരോ പെരുന്നാൾ വർഷത്തിനും പ്രത്യേക വരവ്-ചിലവ് കണക്കുകൾ സൂക്ഷിക്കാവുന്നതാണ്.
            </p>

            <form onSubmit={handleCreateYear} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  വർഷം (ID) *
                </label>
                <input
                  type="text"
                  required
                  placeholder="ഉദാ: 2027"
                  value={newYearId}
                  onChange={(e) => {
                    setNewYearId(e.target.value);
                    if (!newYearName) {
                      setNewYearName(`${e.target.value} വാർഷിക പെരുന്നാൾ`);
                    }
                  }}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  പെരുന്നാൾ പേര് *
                </label>
                <input
                  type="text"
                  required
                  placeholder="ഉദാ: 2027 വാർഷിക പെരുന്നാൾ"
                  value={newYearName}
                  onChange={(e) => setNewYearName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    തുടങ്ങുന്ന തീയതി
                  </label>
                  <input
                    type="date"
                    value={newStartDate}
                    onChange={(e) => setNewStartDate(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    അവസാന തീയതി
                  </label>
                  <input
                    type="date"
                    value={newEndDate}
                    onChange={(e) => setNewEndDate(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  പെരുന്നാൾ വിശേഷം / വിവരണം (ഓപ്ഷണൽ)
                </label>
                <input
                  type="text"
                  placeholder="ഉദാ: 118-ാമത് വാർഷിക പെരുന്നാൾ മഹോത്സവം"
                  value={newTheme}
                  onChange={(e) => setNewTheme(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddYearModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  റദ്ദാക്കുക
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-amber-600 hover:bg-amber-700 text-white cursor-pointer shadow-sm"
                >
                  വർഷം ചേർക്കുക
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </header>
  );
};
