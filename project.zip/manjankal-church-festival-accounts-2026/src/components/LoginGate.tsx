import React, { useState, useEffect } from 'react';
import { CHURCH_DETAILS } from '../utils/storage';
import {
  SUPER_ADMIN_EMAIL,
  authenticateSuperAdmin,
  getSecurityStatus,
  SecurityStatus,
  AuthSession,
} from '../utils/auth';
import { Lock, ShieldCheck, KeyRound, Eye, EyeOff, AlertTriangle, Sparkles, Calendar } from 'lucide-react';
import { signInWithGoogle, checkRedirectAuthResult, isFirebaseClientConfigured, isAndroidNativeEnvironment } from '../services/firebase';

interface LoginGateProps {
  onLoginSuccess: (session: AuthSession) => void;
  onRecordAudit: (action: 'LOGIN' | 'FAILED_LOGIN', summaryMl: string) => void;
}

export const LoginGate: React.FC<LoginGateProps> = ({ onLoginSuccess, onRecordAudit }) => {
  const [email, setEmail] = useState(SUPER_ADMIN_EMAIL);
  const [pin, setPin] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [securityStatus, setSecurityStatus] = useState<SecurityStatus>(() => getSecurityStatus());

  useEffect(() => {
    const timer = setInterval(() => {
      setSecurityStatus(getSecurityStatus());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Handle Capacitor Android redirect authentication return
  useEffect(() => {
    checkRedirectAuthResult().then((res) => {
      if (res.handled && res.success && res.session) {
        onRecordAudit('LOGIN', `സൂപ്പർ അഡ്മിൻ (${SUPER_ADMIN_EMAIL}) ആൻഡ്രോയിഡ് ഗൂഗിൾ റീഡയറക്റ്റ് വഴി ലോഗിൻ ചെയ്തു`);
        onLoginSuccess(res.session);
      } else if (res.handled && res.error) {
        setErrorMsg(res.error);
        onRecordAudit('FAILED_LOGIN', `പരാജയപ്പെട്ട ആൻഡ്രോയിഡ് ഗൂഗിൾ ലോഗിൻ: ${res.error}`);
      }
    });
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pin.trim()) {
      setErrorMsg('ദയവായി സെക്യൂരിറ്റി പിൻ നൽകുക.');
      return;
    }

    setIsLoading(true);
    setErrorMsg(null);

    try {
      const res = await authenticateSuperAdmin(email, pin);
      if (res.success && res.session) {
        onRecordAudit('LOGIN', `സൂപ്പർ അഡ്മിൻ (${SUPER_ADMIN_EMAIL}) വിജയകരമായി ലോഗിൻ ചെയ്തു`);
        onLoginSuccess(res.session);
      } else {
        const err = res.error || 'ലോഗിൻ പരാജയപ്പെട്ടു. വിവരങ്ങൾ പരിശോധിക്കുക.';
        setErrorMsg(err);
        onRecordAudit('FAILED_LOGIN', `പരാജയപ്പെട്ട ലോഗിൻ ശ്രമം: ${email} - ${err}`);
        setSecurityStatus(getSecurityStatus());
      }
    } catch (err: any) {
      setErrorMsg('ലോഗിൻ ചെയ്യുമ്പോൾ അപ്രതീക്ഷിത പിശക് സംഭവിച്ചു.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const res = await signInWithGoogle();
      if (res.isRedirecting) {
        // Redirecting to Google in Android WebView / Capacitor
        setErrorMsg(null);
        return;
      }
      if (res.success && res.session) {
        onRecordAudit('LOGIN', `സൂപ്പർ അഡ്മിൻ (${SUPER_ADMIN_EMAIL}) ഗൂഗിൾ വഴി ലോഗിൻ ചെയ്തു`);
        onLoginSuccess(res.session);
      } else {
        const err = res.error || 'ഗൂഗിൾ ലോഗിൻ പരാജയപ്പെട്ടു.';
        setErrorMsg(err);
        onRecordAudit('FAILED_LOGIN', `പരാജയപ്പെട്ട ഗൂഗിൾ ലോഗിൻ ശ്രമം: ${err}`);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'ഗൂഗിൾ ലോഗിൻ പരാജയപ്പെട്ടു.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-linear-to-b from-amber-50/40 via-red-950/5 to-amber-100/30 text-slate-800">
      {/* Top Banner with Church Heritage imagery & Emblem */}
      <div className="relative overflow-hidden bg-linear-to-r from-red-950 via-red-900 to-amber-950 text-white border-b-2 border-amber-500/40 shadow-md">
        <div className="absolute inset-0 opacity-20 pointer-events-none mix-blend-overlay">
          <img
            src={CHURCH_DETAILS.photoUrl}
            alt="മഞ്ഞക്കാല പള്ളി"
            className="w-full h-full object-cover object-center"
          />
        </div>

        <div className="relative max-w-5xl mx-auto px-4 py-8 text-center flex flex-col items-center">
          <div className="relative mb-3">
            <img
              src={CHURCH_DETAILS.logoUrl}
              alt="മാർ ശെമവൂൻ ദെസ്തൂനി പള്ളി മുദ്ര"
              className="w-24 h-24 sm:w-28 sm:h-28 object-contain rounded-full bg-white/95 p-1.5 shadow-2xl ring-4 ring-amber-400/80 mx-auto"
            />
          </div>

          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-bold bg-amber-400/20 text-amber-200 border border-amber-400/40 mb-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>2026 വാർഷിക പെരുന്നാൾ അക്കൗണ്ട്സ് • 22-11-2026 to 10-12-2026</span>
          </div>

          <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold tracking-tight text-white drop-shadow-sm">
            {CHURCH_DETAILS.nameMl}
          </h1>
          <p className="text-sm sm:text-base text-amber-200 font-medium mt-1">
            {CHURCH_DETAILS.subMl} • വാർഷിക പെരുന്നാൾ വരവ് ചിലവ് കണക്കുകൾ
          </p>
        </div>
      </div>

      {/* Main Login Card Area */}
      <div className="flex-1 flex items-center justify-center px-4 py-10 sm:py-16">
        <div className="max-w-md w-full bg-white rounded-3xl shadow-2xl border border-amber-300/70 overflow-hidden">
          {/* Card Header */}
          <div className="bg-linear-to-r from-red-900 to-amber-900 px-6 py-4 text-white text-center">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-white/10 ring-1 ring-white/20 mb-2">
              <Lock className="w-6 h-6 text-amber-300" />
            </div>
            <h2 className="text-lg font-bold tracking-wide">സൂപ്പർ അഡ്മിൻ ലോഗിൻ</h2>
            <div className="text-[11px] font-semibold text-amber-200 mt-0.5">
              പ്രാദേശിക ഓഫ്ലൈൻ ആക്സസ് ലോക്ക് (Local Offline Access Lock)
            </div>
            <p className="text-[10px] text-amber-100/80 mt-1 max-w-xs mx-auto">
              ഗൂഗിൾ ക്ലൗഡ് പ്രൊവിഷനിംഗിന് ശേഷം ഗൂഗിൾ അക്കൗണ്ട് സൈൻ-ഇൻ സജീവമാകും. ഈ ലോക്കൽ പിൻ ഓഫ്ലൈൻ ഡാറ്റാ സുരക്ഷയ്ക്കുള്ളതാണ്.
            </p>
          </div>

          {/* Form Body */}
          <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-5">
            {/* Security Lockout Banner */}
            {securityStatus.isLocked && (
              <div className="bg-red-50 border border-red-300 rounded-2xl p-4 flex items-start gap-3 text-red-800 text-xs">
                <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="block font-bold">അക്കൗണ്ട് താൽക്കാലികമായി ലോക്ക് ചെയ്യപ്പെട്ടു!</strong>
                  അനധികൃത ശ്രമങ്ങൾ കണ്ടെത്തിയതിനാൽ സിസ്റ്റം സുരക്ഷിതമായി ലോക്ക് ചെയ്തിരിക്കുന്നു. വീണ്ടും ശ്രമിക്കാൻ ബാക്കിയുള്ള സമയം:{' '}
                  <span className="font-bold underline">{securityStatus.lockoutRemainingSeconds} സെക്കൻഡ്</span>.
                </div>
              </div>
            )}

            {/* Error Message */}
            {errorMsg && !securityStatus.isLocked && (
              <div className="bg-rose-50 border border-rose-200 rounded-xl p-3 text-rose-800 text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Super Admin Email Field */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center justify-between">
                <span>അധികൃത സൂപ്പർ അഡ്മിൻ ഇമെയിൽ</span>
                <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                  ഏക സൂപ്പർ അഡ്മിൻ
                </span>
              </label>
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  readOnly
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-semibold text-slate-800 cursor-not-allowed focus:outline-hidden"
                />
                <div className="absolute right-3 top-2.5 text-emerald-600">
                  <ShieldCheck className="w-5 h-5" />
                </div>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                ഈ പെരുന്നാൾ ആപ്പിൽ {SUPER_ADMIN_EMAIL} എന്ന അഡ്മിന് മാത്രമേ പ്രവേശനമുള്ളൂ.
              </p>
            </div>

            {/* Security PIN Field */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                സെക്യൂരിറ്റി പിൻ / പാസ്‌കോഡ് *
              </label>
              <div className="relative">
                <input
                  type={showPin ? 'text' : 'password'}
                  required
                  disabled={securityStatus.isLocked || isLoading}
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  placeholder="സെക്യൂരിറ്റി പിൻ നൽകുക"
                  className="w-full pl-3.5 pr-10 py-2.5 border border-slate-300 rounded-xl text-sm font-semibold text-slate-900 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 focus:outline-hidden disabled:bg-slate-100 disabled:cursor-not-allowed"
                />
                <button
                  type="button"
                  onClick={() => setShowPin(!showPin)}
                  className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 transition cursor-pointer"
                  tabIndex={-1}
                >
                  {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              {/* Initial PIN Quick Hint */}
              <div className="mt-2 p-2.5 rounded-xl bg-amber-50 border border-amber-200/80 text-[11px] text-amber-900 flex items-start gap-2">
                <KeyRound className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold">പ്രാരംഭ സെക്യൂരിറ്റി പിൻ:</span>{' '}
                  <span className="font-mono font-bold bg-amber-200/70 px-1.5 py-0.5 rounded text-amber-950">221126</span>
                  <span className="text-amber-800 ml-1">
                    (പെരുന്നാൾ ആരംഭ തീയതി 22-11-2026 അടിസ്ഥാനമാക്കിയത്).
                  </span>
                  {!securityStatus.hasCustomPin && (
                    <div className="mt-1.5 text-[10px] text-amber-950 font-bold bg-amber-100/90 p-1.5 rounded-lg border border-amber-300">
                      ⚠️ ശ്രദ്ധിക്കുക: ആദ്യ ലോഗിന് ശേഷം യഥാർത്ഥ പെരുന്നാൾ വരവ് ചിലവ് കണക്കുകൾ രേഖപ്പെടുത്തുന്നതിന് മുൻപായി സുരക്ഷാ പിൻ ഉടൻ മാറ്റേണ്ടതാണ്.
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={securityStatus.isLocked || isLoading}
              className="w-full py-3 px-4 rounded-xl font-bold text-sm text-white bg-linear-to-r from-red-900 to-amber-800 hover:from-red-950 hover:to-amber-900 active:scale-[0.99] transition shadow-md disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer flex items-center justify-center gap-2"
            >
              <KeyRound className="w-4 h-4" />
              <span>{isLoading ? 'പരിശോധിക്കുന്നു...' : 'സുരക്ഷിതമായി ലോഗിൻ ചെയ്യുക'}</span>
            </button>

            {/* Google Authentication Option */}
            <div className="relative flex py-2 items-center">
              <div className="grow border-t border-slate-200"></div>
              <span className="shrink mx-3 text-slate-400 text-xs font-semibold">അല്ലെങ്കിൽ</span>
              <div className="grow border-t border-slate-200"></div>
            </div>

            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={isLoading}
              className="w-full py-2.5 px-4 rounded-xl font-bold text-xs text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 active:scale-[0.99] transition shadow-xs flex items-center justify-center gap-2.5 cursor-pointer disabled:opacity-50"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>ഗൂഗിൾ അക്കൗണ്ട് വഴി ലോഗിൻ ചെയ്യുക (Google Sign-In)</span>
            </button>
          </form>

          {/* Footer of Card */}
          <div className="bg-slate-50 border-t border-slate-200 px-6 py-3.5 text-center text-[11px] text-slate-500 flex items-center justify-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>എല്ലാ സാമ്പത്തിക വിവരങ്ങളും രസീതുകളും പൂർണ്ണമായി സംരക്ഷിക്കപ്പെട്ടിരിക്കുന്നു.</span>
          </div>
        </div>
      </div>

      {/* Page Footer */}
      <footer className="bg-white border-t border-amber-200 py-4 text-center text-xs text-slate-500">
        <div className="max-w-5xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span className="font-semibold text-slate-700">{CHURCH_DETAILS.nameMl}</span>
          <span className="text-amber-900 font-bold flex items-center gap-1">
            <Calendar className="w-3.5 h-3.5" /> 22-11-2026 to 10-12-2026
          </span>
        </div>
      </footer>
    </div>
  );
};
