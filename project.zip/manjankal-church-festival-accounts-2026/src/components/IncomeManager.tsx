import React, { useState, useEffect } from 'react';
import { IncomeTransaction, YearAccountingData, FestivalYear } from '../types/festival';
import { formatINR, numberToMalayalamWords } from '../utils/numberToMalayalamWords';
import { PrintReceiptModal } from './PrintReceiptModal';
import {
  Plus,
  Search,
  Filter,
  Printer,
  Edit2,
  Trash2,
  ArrowUpDown,
  Download,
  Calendar,
  Layers,
  CheckCircle,
  AlertCircle,
  AlertTriangle,
} from 'lucide-react';

interface IncomeManagerProps {
  data: YearAccountingData;
  year: FestivalYear;
  onAddIncome: (income: Omit<IncomeTransaction, 'id' | 'createdAt'>) => void;
  onUpdateIncome: (income: IncomeTransaction) => void;
  onDeleteIncome: (id: string) => void;
  onNavigateToHeadings: () => void;
  hasCustomPin?: boolean;
  onRequestChangePin?: () => void;
  autoOpenAdd?: boolean;
  onCloseAutoOpenAdd?: () => void;
}

export const IncomeManager: React.FC<IncomeManagerProps> = ({
  data,
  year,
  onAddIncome,
  onUpdateIncome,
  onDeleteIncome,
  onNavigateToHeadings,
  hasCustomPin = false,
  onRequestChangePin,
  autoOpenAdd = false,
  onCloseAutoOpenAdd,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedHeading, setSelectedHeading] = useState('ALL');
  const [dateFilter, setDateFilter] = useState('');
  const [sortOrder, setSortOrder] = useState<'NEWEST' | 'OLDEST' | 'AMOUNT_HIGH' | 'AMOUNT_LOW'>('NEWEST');

  // Modals state
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<IncomeTransaction | null>(null);
  const [printTransaction, setPrintTransaction] = useState<IncomeTransaction | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [incomeToDelete, setIncomeToDelete] = useState<IncomeTransaction | null>(null);

  // Form Fields
  const nextSeq = (data.lastReceiptSeq || data.incomes.length) + 1;
  const defaultReceiptNo = `R-${year.id}-${String(nextSeq).padStart(3, '0')}`;

  const [formReceiptNo, setFormReceiptNo] = useState(defaultReceiptNo);
  const [formDate, setFormDate] = useState(
    new Date().toISOString().split('T')[0] || year.startDate
  );
  const [formDonorName, setFormDonorName] = useState('');
  const [formDonorAddress, setFormDonorAddress] = useState('');
  const [formHeadingId, setFormHeadingId] = useState(
    data.headings.find((h) => h.type === 'INCOME')?.id || ''
  );
  const [formAmount, setFormAmount] = useState('');
  const [formPaymentMode, setFormPaymentMode] = useState<'CASH' | 'UPI' | 'BANK' | 'CHEQUE'>('CASH');
  const [formReferenceNumber, setFormReferenceNumber] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formCollectedBy, setFormCollectedBy] = useState('');

  const incomeHeadings = data.headings.filter((h) => h.type === 'INCOME');

  const handleOpenAdd = () => {
    if (!hasCustomPin) {
      if (onRequestChangePin) onRequestChangePin();
      return;
    }
    setEditingTransaction(null);
    setFormError(null);
    const generated = `R-${year.id}-${String(nextSeq).padStart(3, '0')}`;
    setFormReceiptNo(generated);
    setFormDate(new Date().toISOString().split('T')[0] || year.startDate);
    setFormDonorName('');
    setFormDonorAddress('');
    setFormHeadingId(incomeHeadings[0]?.id || '');
    setFormAmount('');
    setFormPaymentMode('CASH');
    setFormReferenceNumber('');
    setFormDescription('');
    setFormCollectedBy('');
    setIsFormOpen(true);
  };

  // Automatically open Add Income modal if triggered from Dashboard
  useEffect(() => {
    if (autoOpenAdd) {
      handleOpenAdd();
      if (onCloseAutoOpenAdd) {
        onCloseAutoOpenAdd();
      }
    }
  }, [autoOpenAdd]);

  const handleOpenEdit = (t: IncomeTransaction) => {
    if (!hasCustomPin) {
      if (onRequestChangePin) onRequestChangePin();
      return;
    }
    setEditingTransaction(t);
    setFormError(null);
    setFormReceiptNo(t.receiptNumber);
    setFormDate(t.date);
    setFormDonorName(t.donorName || '');
    setFormDonorAddress(t.donorAddress || '');
    setFormHeadingId(t.headingId);
    setFormAmount(t.amount.toString());
    setFormPaymentMode(t.paymentMode);
    setFormReferenceNumber(t.referenceNumber || '');
    setFormDescription(t.description || '');
    setFormCollectedBy(t.collectedBy || '');
    setIsFormOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!hasCustomPin) {
      if (onRequestChangePin) onRequestChangePin();
      return;
    }
    setFormError(null);

    const trimmedReceiptNo = formReceiptNo.trim();
    if (!trimmedReceiptNo) {
      setFormError('ദയവായി സാധുവായ രസീത് നമ്പർ നൽകുക.');
      return;
    }

    // 1. Prevent duplicate receipt numbers within the festival year (excluding currently edited transaction)
    const isDuplicate = data.incomes.some(
      (i) =>
        i.id !== editingTransaction?.id &&
        i.receiptNumber.trim().toLowerCase() === trimmedReceiptNo.toLowerCase()
    );
    if (isDuplicate) {
      setFormError(`രസീത് നമ്പർ "${trimmedReceiptNo}" ഈ വർഷത്തെ അക്കൗണ്ടിൽ ഇതിനകം നിലവിലുണ്ട്! ദയവായി മറ്റൊരു രസീത് നമ്പർ നൽകുക.`);
      return;
    }

    // 2. Enforce whole-rupee amount validation without silent truncation
    const parsedAmount = Number(formAmount);
    if (isNaN(parsedAmount) || !Number.isInteger(parsedAmount) || parsedAmount <= 0) {
      setFormError('തുക പൂർണ്ണ രൂപയിൽ (Whole Rupees) നൽകുക. പൈസ അനുവദനീയമല്ല (ഉദാ: ₹500).');
      return;
    }

    // Name of Donor / Contributor is optional per requirement
    const trimmedDonorName = formDonorName.trim();

    const selectedH = data.headings.find((h) => h.id === formHeadingId);
    if (!selectedH) {
      setFormError('ദയവായി ഒരു വരവ് ശീർഷകം തിരഞ്ഞെടുക്കുക അല്ലെങ്കിൽ പുതിയ ശീർഷകം ചേർക്കുക.');
      return;
    }
    const headingName = selectedH.name;

    if (editingTransaction) {
      onUpdateIncome({
        ...editingTransaction,
        receiptNumber: trimmedReceiptNo,
        date: formDate,
        donorName: trimmedDonorName,
        donorAddress: formDonorAddress.trim(),
        headingId: formHeadingId,
        headingName,
        amount: parsedAmount,
        paymentMode: formPaymentMode,
        referenceNumber: formReferenceNumber.trim(),
        description: formDescription.trim(),
        collectedBy: formCollectedBy.trim(),
      });
    } else {
      onAddIncome({
        receiptNumber: trimmedReceiptNo,
        date: formDate || new Date().toISOString().split('T')[0],
        donorName: trimmedDonorName,
        donorAddress: formDonorAddress.trim(),
        headingId: formHeadingId,
        headingName,
        amount: parsedAmount,
        paymentMode: formPaymentMode,
        referenceNumber: formReferenceNumber.trim(),
        description: formDescription.trim(),
        collectedBy: formCollectedBy.trim(),
      });
    }

    setIsFormOpen(false);
  };

  const handleDelete = (t: IncomeTransaction) => {
    if (!hasCustomPin) {
      if (onRequestChangePin) onRequestChangePin();
      return;
    }
    // In-app modal confirmation replacing window.confirm
    setIncomeToDelete(t);
  };

  // Filter and sort
  const filteredIncomes = data.incomes.filter((item) => {
    const matchesSearch =
      searchTerm === '' ||
      (item.donorName ? item.donorName.toLowerCase().includes(searchTerm.toLowerCase()) : false) ||
      item.receiptNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.donorAddress && item.donorAddress.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesHeading = selectedHeading === 'ALL' || item.headingId === selectedHeading;
    const matchesDate = !dateFilter || item.date === dateFilter;

    return matchesSearch && matchesHeading && matchesDate;
  });

  const sortedIncomes = [...filteredIncomes].sort((a, b) => {
    if (sortOrder === 'NEWEST') return new Date(b.date).getTime() - new Date(a.date).getTime();
    if (sortOrder === 'OLDEST') return new Date(a.date).getTime() - new Date(b.date).getTime();
    if (sortOrder === 'AMOUNT_HIGH') return b.amount - a.amount;
    if (sortOrder === 'AMOUNT_LOW') return a.amount - b.amount;
    return 0;
  });

  const totalFilteredAmount = sortedIncomes.reduce((sum, item) => sum + item.amount, 0);

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-emerald-100 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-900 mb-2">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-700" />
            <span>വരവ് രജിസ്റ്റർ & രസീതുകൾ</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900">
            {year.yearName} - പെരുന്നാൾ വരവുകൾ
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            നേർച്ച, വഴിപാടുകൾ, ലേലം, സ്പോൺസർഷിപ്പ്, സംഭാവനകൾ എന്നിവ രേഖപ്പെടുത്തി രസീത് പ്രിന്റ് ചെയ്യുക.
          </p>
        </div>

        <button
          type="button"
          onClick={handleOpenAdd}
          className="inline-flex items-center gap-2 bg-emerald-700 hover:bg-emerald-800 text-white px-5 py-2.5 rounded-2xl text-xs font-bold shadow-sm transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>+ പുതിയ വരവ് രേഖപ്പെടുത്തുക (രസീത്)</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="പേര്, രസീത് നമ്പർ, വിവരണം..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
          />
        </div>

        {/* Heading Filter */}
        <div className="flex items-center gap-1.5">
          <Layers className="w-4 h-4 text-slate-400 shrink-0" />
          <select
            value={selectedHeading}
            onChange={(e) => setSelectedHeading(e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
          >
            <option value="ALL">എല്ലാ വരവ് ശീർഷകങ്ങളും</option>
            {incomeHeadings.map((h) => (
              <option key={h.id} value={h.id}>
                {h.name}
              </option>
            ))}
          </select>
        </div>

        {/* Date Filter */}
        <div className="flex items-center gap-1.5">
          <Calendar className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            type="date"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
          />
          {dateFilter && (
            <button
              onClick={() => setDateFilter('')}
              className="text-xs text-slate-500 hover:text-slate-800 px-1"
            >
              മായ്ക്കുക
            </button>
          )}
        </div>

        {/* Sort */}
        <div className="flex items-center gap-1.5">
          <ArrowUpDown className="w-4 h-4 text-slate-400 shrink-0" />
          <select
            value={sortOrder}
            onChange={(e: any) => setSortOrder(e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
          >
            <option value="NEWEST">ഏറ്റവും പുതിയത് ആദ്യം</option>
            <option value="OLDEST">പഴയത് ആദ്യം</option>
            <option value="AMOUNT_HIGH">തുക: കൂടിയതിൽ നിന്ന്</option>
            <option value="AMOUNT_LOW">തുക: കുറഞ്ഞതിൽ നിന്ന്</option>
          </select>
        </div>
      </div>

      {/* Subtotal Banner */}
      <div className="flex flex-col sm:flex-row items-center justify-between bg-emerald-50/70 border border-emerald-200/80 rounded-2xl px-5 py-3 text-xs font-semibold text-emerald-900">
        <div>
          ഫിൽട്ടർ ചെയ്ത രസീതുകൾ: <strong>{sortedIncomes.length} എണ്ണം</strong>
        </div>
        <div className="text-sm">
          ആകെ വരവ് തുക:{' '}
          <strong className="text-emerald-800 text-base">{formatINR(totalFilteredAmount)}</strong>
        </div>
      </div>

      {/* Incomes Table */}
      <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 text-[11px] font-bold text-slate-600 uppercase tracking-wider border-b border-slate-200">
                <th className="py-3 px-4">രസീത് നമ്പർ</th>
                <th className="py-3 px-4">തീയതി</th>
                <th className="py-3 px-4">Name of Donor / Contributor</th>
                <th className="py-3 px-4">വരവ് ശീർഷകം</th>
                <th className="py-3 px-4">വിവരണം / രീതി</th>
                <th className="py-3 px-4 text-right">തുക (രൂപ)</th>
                <th className="py-3 px-4 text-center no-print">നടപടികൾ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
              {sortedIncomes.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    വരവ് രസീതുകൾ ഒന്നും കണ്ടെത്തിയില്ല. "+ പുതിയ വരവ് രേഖപ്പെടുത്തുക" ക്ലിക്ക് ചെയ്യുക.
                  </td>
                </tr>
              ) : (
                sortedIncomes.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/80 transition">
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                      {item.receiptNumber}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600 whitespace-nowrap">
                      {item.date}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900 text-sm">{item.donorName || '-'}</div>
                      {item.donorAddress && (
                        <div className="text-[11px] text-slate-500">{item.donorAddress}</div>
                      )}
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="inline-block px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-100/70 text-emerald-800">
                        {item.headingName}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 max-w-xs">
                      <div className="line-clamp-1">{item.description || '-'}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        {item.paymentMode === 'CASH'
                          ? 'പണമായി'
                          : item.paymentMode === 'UPI'
                          ? 'UPI'
                          : item.paymentMode === 'BANK'
                          ? 'ബാങ്ക്'
                          : 'ചെക്ക്'}
                        {item.referenceNumber && ` (${item.referenceNumber})`}
                        {item.collectedBy && ` • ${item.collectedBy}`}
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-right font-extrabold text-emerald-800 text-sm whitespace-nowrap">
                      {formatINR(item.amount)}
                    </td>
                    <td className="py-3.5 px-4 text-center whitespace-nowrap no-print">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          type="button"
                          onClick={() => setPrintTransaction(item)}
                          className="p-1.5 text-emerald-700 hover:bg-emerald-50 rounded-lg transition cursor-pointer"
                          title="രസീത് പ്രിന്റ് ചെയ്യുക"
                        >
                          <Printer className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleOpenEdit(item)}
                          className="p-1.5 text-amber-700 hover:bg-amber-50 rounded-lg transition cursor-pointer"
                          title="രസീത് വിവരങ്ങൾ തിരുത്തുക"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDelete(item)}
                          className="p-1.5 text-rose-700 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                          title="രസീത് നീക്കം ചെയ്യുക"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Income Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-emerald-200 my-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">
                {editingTransaction ? 'വരവ് രസീത് തിരുത്തുക' : 'പുതിയ വരവ് രേഖപ്പെടുത്തുക (രസീത്)'}
              </h3>
              <span className="text-xs font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                {formReceiptNo}
              </span>
            </div>

            {formError && (
              <div className="mt-3 p-3 rounded-xl bg-rose-50 border border-rose-300 text-rose-800 text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 mt-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    രസീത് നമ്പർ *
                  </label>
                  <input
                    type="text"
                    required
                    value={formReceiptNo}
                    onChange={(e) => setFormReceiptNo(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    തീയതി (ഓപ്ഷണൽ)
                  </label>
                  <input
                    type="date"
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Name of Donor / Contributor
                </label>
                <input
                  type="text"
                  placeholder="Enter the name of the person who made the donation"
                  value={formDonorName}
                  onChange={(e) => setFormDonorName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden text-sm"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  മേൽവിലാസം / കുടുംബപ്പേര് / ഫോൺ (ഓപ്ഷണൽ)
                </label>
                <input
                  type="text"
                  placeholder="ഉദാ: പാലമൂട്ടിൽ, മഞ്ഞക്കാല • Ph: 9447000000"
                  value={formDonorAddress}
                  onChange={(e) => setFormDonorAddress(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block font-bold text-slate-700">
                      വരവ് ശീർഷകം *
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        setIsFormOpen(false);
                        onNavigateToHeadings();
                      }}
                      className="text-[10px] text-amber-700 hover:underline font-bold"
                    >
                      + പുതിയ ശീർഷകം
                    </button>
                  </div>
                  <select
                    value={formHeadingId}
                    onChange={(e) => setFormHeadingId(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden font-medium"
                  >
                    {incomeHeadings.length === 0 ? (
                      <option value="">-- വരവ് ശീർഷകം ചേർത്തിട്ടില്ല --</option>
                    ) : (
                      <>
                        <option value="">-- ശീർഷകം തിരഞ്ഞെടുക്കുക --</option>
                        {incomeHeadings.map((h) => (
                          <option key={h.id} value={h.id}>
                            {h.name}
                          </option>
                        ))}
                      </>
                    )}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    തുക (രൂപ ₹) * [പൂർണ്ണ രൂപ]
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="1"
                    required
                    placeholder="ഉദാ: 5000"
                    value={formAmount}
                    onChange={(e) => setFormAmount(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden font-bold text-sm text-emerald-800"
                  />
                </div>
              </div>

              {/* Amount in Malayalam words preview */}
              {formAmount && Number(formAmount) > 0 && (
                <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-950 font-bold text-[11px]">
                  തുക അക്ഷരങ്ങളിൽ:{' '}
                  <span className="text-emerald-800 font-extrabold">
                    {numberToMalayalamWords(Number(formAmount))}
                  </span>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    പെയ്മെന്റ് രീതി *
                  </label>
                  <select
                    value={formPaymentMode}
                    onChange={(e: any) => setFormPaymentMode(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  >
                    <option value="CASH">പണമായി (Cash)</option>
                    <option value="UPI">UPI / GPay / PhonePe</option>
                    <option value="BANK">ബാങ്ക് ട്രാൻസ്ഫർ (Bank)</option>
                    <option value="CHEQUE">ചെക്ക് (Cheque)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    റഫറൻസ് / ചെക്ക് / ട്രാൻസാക്ഷൻ നമ്പർ
                  </label>
                  <input
                    type="text"
                    placeholder="ഓപ്ഷണൽ..."
                    value={formReferenceNumber}
                    onChange={(e) => setFormReferenceNumber(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  വിവരണം / വഴിപാട് ഉദ്ദേശ്യം
                </label>
                <input
                  type="text"
                  placeholder="ഉദാ: പെരുന്നാൾ സ്നേഹവിരുന്ന് വഴിപാട് / നേർച്ച"
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  പിരിവെടുത്തയാൾ / ശേഖരിച്ചയാൾ (ഓപ്ഷണൽ)
                </label>
                <input
                  type="text"
                  placeholder="ഉദാ: തോമസ് വർഗ്ഗീസ് (ട്രഷറർ)"
                  value={formCollectedBy}
                  onChange={(e) => setFormCollectedBy(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  റദ്ദാക്കുക
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold bg-emerald-700 hover:bg-emerald-800 text-white cursor-pointer shadow-sm"
                >
                  {editingTransaction ? 'മാറ്റങ്ങൾ സംരക്ഷിക്കുക' : 'രസീത് സംരക്ഷിക്കുക'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Print Receipt Modal */}
      {printTransaction && (
        <PrintReceiptModal
          transaction={printTransaction}
          year={year}
          onClose={() => setPrintTransaction(null)}
        />
      )}

      {/* In-App Income Deletion Confirmation Modal */}
      {incomeToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-rose-200">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-700 flex items-center justify-center mb-4">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-black text-slate-900 mb-2">
              വരവ് രസീത് നീക്കം ചെയ്യൽ സ്ഥിരീകരിക്കുക
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed mb-6">
              രസീത് നമ്പർ <strong className="text-slate-900 font-mono">{incomeToDelete.receiptNumber}</strong> (
              <span className="font-semibold text-slate-800">{incomeToDelete.donorName || '-'}</span> -{' '}
              <strong className="text-emerald-700">{formatINR(incomeToDelete.amount)}</strong>) നീക്കം ചെയ്യാൻ ആഗ്രഹിക്കുന്നുവോ?
              ഇത് ഈ വർഷത്തെ ആകെ വരവിൽ നിന്നും ഉടൻ കുറയ്ക്കപ്പെടുന്നതാണ്.
            </p>
            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setIncomeToDelete(null)}
                className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition cursor-pointer"
              >
                റദ്ദാക്കുക (Cancel)
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteIncome(incomeToDelete.id);
                  setIncomeToDelete(null);
                }}
                className="px-5 py-2.5 rounded-xl bg-rose-700 hover:bg-rose-800 text-white text-xs font-bold shadow-sm transition cursor-pointer"
              >
                ശരി, നീക്കം ചെയ്യുക (Delete)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
