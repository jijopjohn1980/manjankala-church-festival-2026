/**
 * Firestore Real-Time Sync & Atomic Transaction Service
 * Manjankal Mar Shemavoon Desthuni Orthodox Syrian Church - 2026 Festival Accounts
 * Enforces atomic four-way binding matching firestore.rules
 */

import {
  doc,
  collection,
  runTransaction,
  onSnapshot,
  setDoc,
  updateDoc,
  Unsubscribe,
} from 'firebase/firestore';
import { db, isFirebaseClientConfigured } from './firebase';
import {
  Heading,
  IncomeTransaction,
  ExpenseTransaction,
  YearAccountingData,
} from '../types/festival';
import {
  formatReceiptNumber,
  formatVoucherNumber,
  canonicalizeIncomePayload,
  canonicalizeExpensePayload,
  computePayloadFingerprint,
} from '../utils/payloadNormalization';
import { SUPER_ADMIN_EMAIL } from '../utils/auth';

// Generate RFC 4122 v4 UUID
export function generateV4Uuid(): string {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

/**
 * 0. ATOMIC FIRST-TIME SEQUENCE INITIALIZATION
 * Enforces firestore.rules lines 93-115:
 * - Fresh: lastReceiptSeq: 0, lastVoucherSeq: 0, status: 'INITIALIZED_EMPTY', lastOperationId: '00000000-0000-4000-8000-000000000000'
 * - Legacy Migration: status: 'BOOTSTRAPPED_FROM_LEGACY' with manifest link
 * - Fully safe against concurrent initialization via Firestore transaction
 */
export async function ensureSequenceInitialized(
  yearId: string,
  legacyMigrationData?: {
    maxHistoricalReceiptSeq: number;
    maxHistoricalVoucherSeq: number;
    checksumSha256: string;
    totalIncomesMigrated?: number;
    totalExpensesMigrated?: number;
    totalIncomeAmount?: number;
    totalExpenseAmount?: number;
  }
): Promise<{
  success: boolean;
  alreadyInitialized: boolean;
  lastReceiptSeq: number;
  lastVoucherSeq: number;
  error?: string;
}> {
  if (!db || !isFirebaseClientConfigured()) {
    return {
      success: false,
      alreadyInitialized: false,
      lastReceiptSeq: 0,
      lastVoucherSeq: 0,
      error: 'Firebase is not configured.',
    };
  }

  const seqRef = doc(db, `festivals/${yearId}/sequences/accounting`);
  const manifestRef = doc(db, `festivals/${yearId}/manifests/legacy_migration_manifest`);
  const nowIso = new Date().toISOString();

  try {
    const result = await runTransaction(db, async (tx) => {
      const snap = await tx.get(seqRef);
      if (snap.exists()) {
        const data = snap.data();
        return {
          success: true,
          alreadyInitialized: true,
          lastReceiptSeq: data.lastReceiptSeq || 0,
          lastVoucherSeq: data.lastVoucherSeq || 0,
        };
      }

      if (legacyMigrationData) {
        // Migration Bootstrap Branch
        tx.set(manifestRef, {
          manifestId: 'legacy_migration_manifest',
          status: 'DRY_RUN_COMPLETED',
          initiatedAt: nowIso,
          adminEmail: SUPER_ADMIN_EMAIL,
          totalIncomesMigrated: legacyMigrationData.totalIncomesMigrated || legacyMigrationData.maxHistoricalReceiptSeq,
          totalExpensesMigrated: legacyMigrationData.totalExpensesMigrated || legacyMigrationData.maxHistoricalVoucherSeq,
          maxHistoricalReceiptSeq: legacyMigrationData.maxHistoricalReceiptSeq,
          maxHistoricalVoucherSeq: legacyMigrationData.maxHistoricalVoucherSeq,
          totalIncomeAmount: legacyMigrationData.totalIncomeAmount || 0,
          totalExpenseAmount: legacyMigrationData.totalExpenseAmount || 0,
          checksumSha256: legacyMigrationData.checksumSha256,
        });

        tx.set(seqRef, {
          yearId,
          lastReceiptSeq: legacyMigrationData.maxHistoricalReceiptSeq,
          lastVoucherSeq: legacyMigrationData.maxHistoricalVoucherSeq,
          lastOperationId: '00000000-0000-4000-8000-000000000000',
          status: 'BOOTSTRAPPED_FROM_LEGACY',
          createdAt: nowIso,
        });

        return {
          success: true,
          alreadyInitialized: false,
          lastReceiptSeq: legacyMigrationData.maxHistoricalReceiptSeq,
          lastVoucherSeq: legacyMigrationData.maxHistoricalVoucherSeq,
        };
      }

      // Clean fresh year initialization
      tx.set(seqRef, {
        yearId,
        lastReceiptSeq: 0,
        lastVoucherSeq: 0,
        lastOperationId: '00000000-0000-4000-8000-000000000000',
        status: 'INITIALIZED_EMPTY',
        createdAt: nowIso,
      });

      return {
        success: true,
        alreadyInitialized: false,
        lastReceiptSeq: 0,
        lastVoucherSeq: 0,
      };
    });

    return result;
  } catch (err: any) {
    console.error('Sequence initialization failed:', err);
    return {
      success: false,
      alreadyInitialized: false,
      lastReceiptSeq: 0,
      lastVoucherSeq: 0,
      error: err.message || 'Sequence counter initialization failed.',
    };
  }
}

/**
 * 1. COMMIT INCOME TRANSACTION (Atomic 4-document transaction)
 */
export async function commitIncomeToFirestore(
  yearId: string,
  payload: {
    date: string;
    headingId: string;
    headingName: string;
    amount: number;
    paymentMode: 'CASH' | 'BANK' | 'UPI' | 'CHEQUE';
    description: string;
    donorName?: string;
    donorAddress?: string;
    referenceNumber?: string;
    collectedBy?: string;
  }
): Promise<{ success: boolean; transaction?: IncomeTransaction; receiptNumber?: string; error?: string }> {
  if (!db || !isFirebaseClientConfigured()) {
    return { success: false, error: 'Firebase is not configured.' };
  }

  // Ensure sequence counter is initialized before live allocation
  const checkInit = await ensureSequenceInitialized(yearId);
  if (!checkInit.success) {
    return { success: false, error: checkInit.error || 'Sequence initialization failed.' };
  }

  const opId = generateV4Uuid();
  const incId = generateV4Uuid();
  const auditId = `audit_${opId}`;
  const nowIso = new Date().toISOString();

  const canonicalStr = canonicalizeIncomePayload(payload);
  const payloadHash = await computePayloadFingerprint(canonicalStr);

  const opRef = doc(db, `festivals/${yearId}/operations/${opId}`);
  const incRef = doc(db, `festivals/${yearId}/incomes/${incId}`);
  const seqRef = doc(db, `festivals/${yearId}/sequences/accounting`);
  const headRef = doc(db, `festivals/${yearId}/headings/${payload.headingId}`);
  const auditRef = doc(db, `festivals/${yearId}/audit_logs/${auditId}`);

  try {
    const res = await runTransaction(db, async (tx) => {
      // 1. Reads
      const opSnap = await tx.get(opRef);
      if (opSnap.exists()) {
        return { status: 'ALREADY_COMMITTED', receiptNumber: opSnap.data().allocatedNumber, nextSeq: opSnap.data().seqNumber };
      }

      const seqSnap = await tx.get(seqRef);
      if (!seqSnap.exists()) {
        throw new Error('Accounting sequence counter not initialized in Firestore.');
      }
      const seqData = seqSnap.data();

      const headSnap = await tx.get(headRef);
      if (!headSnap.exists()) {
        throw new Error(`Heading ${payload.headingId} not found in Firestore.`);
      }

      const nextSeq = seqData.lastReceiptSeq + 1;
      const receiptNumber = formatReceiptNumber(nextSeq, yearId);

      // 2. Writes
      tx.update(seqRef, {
        lastReceiptSeq: nextSeq,
        lastOperationId: opId,
        updatedAt: nowIso,
      });

      tx.set(opRef, {
        operationId: opId,
        type: 'INCOME',
        entityId: incId,
        seqNumber: nextSeq,
        allocatedNumber: receiptNumber,
        payloadHash,
        userEmail: SUPER_ADMIN_EMAIL,
        createdAt: nowIso,
      });

      const incomeDocData = {
        id: incId,
        receiptNumber,
        seqNumber: nextSeq,
        operationId: opId,
        payloadHash,
        date: payload.date,
        headingId: payload.headingId,
        headingName: payload.headingName,
        amount: Math.round(payload.amount),
        paymentMode: payload.paymentMode,
        description: payload.description.trim(),
        donorName: payload.donorName?.trim() || '',
        donorAddress: payload.donorAddress?.trim() || '',
        referenceNumber: payload.referenceNumber?.trim() || '',
        collectedBy: payload.collectedBy?.trim() || '',
        createdAt: nowIso,
      };

      tx.set(incRef, incomeDocData);

      tx.set(auditRef, {
        id: auditId,
        operationId: opId,
        entityId: incId,
        entityType: 'INCOME',
        action: 'ADD_INCOME',
        summaryMl: `രസീത് ${receiptNumber} ചേർത്തു (₹${payload.amount.toLocaleString('en-IN')})`,
        amount: Math.round(payload.amount),
        userEmail: SUPER_ADMIN_EMAIL,
        timestamp: nowIso,
      });

      return { status: 'COMMITTED', receiptNumber, nextSeq, docData: incomeDocData };
    });

    const fullTx: IncomeTransaction = {
      id: incId,
      receiptNumber: res.receiptNumber,
      date: payload.date,
      headingId: payload.headingId,
      headingName: payload.headingName,
      amount: Math.round(payload.amount),
      paymentMode: payload.paymentMode,
      description: payload.description,
      donorName: payload.donorName,
      donorAddress: payload.donorAddress,
      referenceNumber: payload.referenceNumber,
      collectedBy: payload.collectedBy,
      createdAt: nowIso,
    };

    return { success: true, transaction: fullTx, receiptNumber: res.receiptNumber };
  } catch (err: any) {
    console.error('Firestore income transaction failed:', err);
    return { success: false, error: err.message || 'ഇടപാട് ഫയർബേസിലേക്ക് സേവ് ചെയ്യാൻ സാധിച്ചില്ല.' };
  }
}

/**
 * 2. COMMIT EXPENSE TRANSACTION (Atomic 4-document transaction)
 */
export async function commitExpenseToFirestore(
  yearId: string,
  payload: {
    date: string;
    headingId: string;
    headingName: string;
    amount: number;
    paymentMode: 'CASH' | 'BANK' | 'UPI' | 'CHEQUE';
    description: string;
    paidTo: string;
    voucherCategory?: string;
    referenceNumber?: string;
    authorizedBy?: string;
    approvedBy?: string;
  }
): Promise<{ success: boolean; transaction?: ExpenseTransaction; voucherNumber?: string; error?: string }> {
  if (!db || !isFirebaseClientConfigured()) {
    return { success: false, error: 'Firebase is not configured.' };
  }

  // Ensure sequence counter is initialized before live allocation
  const checkInit = await ensureSequenceInitialized(yearId);
  if (!checkInit.success) {
    return { success: false, error: checkInit.error || 'Sequence initialization failed.' };
  }

  const opId = generateV4Uuid();
  const expId = generateV4Uuid();
  const auditId = `audit_${opId}`;
  const nowIso = new Date().toISOString();

  const canonicalStr = canonicalizeExpensePayload({
    ...payload,
    paidTo: payload.paidTo || '',
  });
  const payloadHash = await computePayloadFingerprint(canonicalStr);

  const opRef = doc(db, `festivals/${yearId}/operations/${opId}`);
  const expRef = doc(db, `festivals/${yearId}/expenses/${expId}`);
  const seqRef = doc(db, `festivals/${yearId}/sequences/accounting`);
  const headRef = doc(db, `festivals/${yearId}/headings/${payload.headingId}`);
  const auditRef = doc(db, `festivals/${yearId}/audit_logs/${auditId}`);

  try {
    const res = await runTransaction(db, async (tx) => {
      // 1. Reads
      const opSnap = await tx.get(opRef);
      if (opSnap.exists()) {
        return { status: 'ALREADY_COMMITTED', voucherNumber: opSnap.data().allocatedNumber, nextSeq: opSnap.data().seqNumber };
      }

      const seqSnap = await tx.get(seqRef);
      if (!seqSnap.exists()) {
        throw new Error('Accounting sequence counter not initialized in Firestore.');
      }
      const seqData = seqSnap.data();

      const headSnap = await tx.get(headRef);
      if (!headSnap.exists()) {
        throw new Error(`Heading ${payload.headingId} not found in Firestore.`);
      }

      const nextSeq = seqData.lastVoucherSeq + 1;
      const voucherNumber = formatVoucherNumber(nextSeq, yearId);

      // 2. Writes
      tx.update(seqRef, {
        lastVoucherSeq: nextSeq,
        lastOperationId: opId,
        updatedAt: nowIso,
      });

      tx.set(opRef, {
        operationId: opId,
        type: 'EXPENSE',
        entityId: expId,
        seqNumber: nextSeq,
        allocatedNumber: voucherNumber,
        payloadHash,
        userEmail: SUPER_ADMIN_EMAIL,
        createdAt: nowIso,
      });

      const expenseDocData = {
        id: expId,
        voucherNumber,
        seqNumber: nextSeq,
        operationId: opId,
        payloadHash,
        date: payload.date,
        headingId: payload.headingId,
        headingName: payload.headingName,
        amount: Math.round(payload.amount),
        paymentMode: payload.paymentMode,
        description: payload.description.trim(),
        paidTo: payload.paidTo.trim(),
        voucherCategory: payload.voucherCategory?.trim() || '',
        referenceNumber: payload.referenceNumber?.trim() || '',
        authorizedBy: (payload.authorizedBy || payload.approvedBy)?.trim() || '',
        createdAt: nowIso,
      };

      tx.set(expRef, expenseDocData);

      tx.set(auditRef, {
        id: auditId,
        operationId: opId,
        entityId: expId,
        entityType: 'EXPENSE',
        action: 'ADD_EXPENSE',
        summaryMl: `വൗച്ചർ ${voucherNumber} ചേർത്തു (₹${payload.amount.toLocaleString('en-IN')})`,
        amount: Math.round(payload.amount),
        userEmail: SUPER_ADMIN_EMAIL,
        timestamp: nowIso,
      });

      return { status: 'COMMITTED', voucherNumber, nextSeq, docData: expenseDocData };
    });

    const fullTx: ExpenseTransaction = {
      id: expId,
      voucherNumber: res.voucherNumber,
      date: payload.date,
      headingId: payload.headingId,
      headingName: payload.headingName,
      amount: Math.round(payload.amount),
      paymentMode: payload.paymentMode,
      description: payload.description,
      paidTo: payload.paidTo || '',
      referenceNumber: payload.referenceNumber,
      authorizedBy: payload.authorizedBy || payload.approvedBy,
      createdAt: nowIso,
    };

    return { success: true, transaction: fullTx, voucherNumber: res.voucherNumber };
  } catch (err: any) {
    console.error('Firestore expense transaction failed:', err);
    return { success: false, error: err.message || 'ചിലവ് ഫയർബേസിലേക്ക് സേവ് ചെയ്യാൻ സാധിച്ചില്ല.' };
  }
}

/**
 * 3. COMMIT / CREATE HEADING CATEGORY
 * Satisfies firestore.rules lines 65-72
 */
export async function commitHeadingToFirestore(yearId: string, heading: Heading): Promise<boolean> {
  if (!db || !isFirebaseClientConfigured()) return false;
  try {
    const headRef = doc(db, `festivals/${yearId}/headings/${heading.id}`);
    const nowIso = new Date().toISOString();
    await setDoc(headRef, {
      id: heading.id,
      name: heading.name.trim(),
      type: heading.type,
      description: heading.description || '',
      isDefault: Boolean(heading.isDefault),
      createdAt: heading.createdAt || nowIso,
    });
    return true;
  } catch (err) {
    console.error('Failed to commit heading to Firestore:', err);
    return false;
  }
}

/**
 * 3b. UPDATE HEADING CATEGORY
 * Satisfies firestore.rules lines 74-82:
 * - affectedKeys: ['name', 'description', 'updatedAt']
 * - Immutable fields: id, type, createdAt
 * - Requires valid ISO updatedAt
 */
export async function updateHeadingInFirestore(
  yearId: string,
  heading: Pick<Heading, 'id' | 'name' | 'description'>
): Promise<boolean> {
  if (!db || !isFirebaseClientConfigured()) return false;
  try {
    const headRef = doc(db, `festivals/${yearId}/headings/${heading.id}`);
    const nowIso = new Date().toISOString();
    await updateDoc(headRef, {
      name: heading.name.trim(),
      description: heading.description || '',
      updatedAt: nowIso,
    });
    return true;
  } catch (err) {
    console.error('Failed to update heading in Firestore:', err);
    return false;
  }
}

/**
 * 3c. COMMIT ADMINISTRATIVE AUDIT LOG DIRECTLY TO FIRESTORE
 * Satisfies firestore.rules lines 310-318 (Branch 2):
 * Allows administrative and security logs: 'LOGIN', 'LOGOUT', 'ADD_HEADING', 'EDIT_HEADING', 'DELETE_HEADING', 'BACKUP_EXPORT', 'BACKUP_RESTORE', 'MIGRATION_BOOTSTRAP'
 */
export async function commitAdminAuditLogToFirestore(
  yearId: string,
  log: {
    action: string;
    summaryMl: string;
    amount?: number;
    details?: Record<string, any>;
  }
): Promise<boolean> {
  if (!db || !isFirebaseClientConfigured()) return false;
  try {
    const auditId = `audit_adm_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const auditRef = doc(db, `festivals/${yearId}/audit_logs/${auditId}`);
    const nowIso = new Date().toISOString();
    await setDoc(auditRef, {
      id: auditId,
      operationId: 'administrative-event',
      timestamp: nowIso,
      userEmail: SUPER_ADMIN_EMAIL,
      action: log.action,
      entityType: 'SECURITY',
      entityId: log.action,
      summaryMl: log.summaryMl.trim().slice(0, 300),
      ...(typeof log.amount === 'number' && log.amount >= 0 ? { amount: Math.round(log.amount) } : {}),
      ...(log.details ? { details: log.details } : {}),
    });
    return true;
  } catch (err) {
    console.warn('Direct Firestore admin audit log notice:', err);
    return false;
  }
}

/**
 * 4. REAL-TIME SUBSCRIPTION TO YEAR ACCOUNTING DATA
 */
export function subscribeToYearAccounting(
  yearId: string,
  onUpdate: (data: Partial<YearAccountingData>) => void,
  onError?: (err: any) => void
): () => void {
  if (!db || !isFirebaseClientConfigured()) {
    return () => {};
  }

  const unsubs: Unsubscribe[] = [];

  try {
    // 1. Subscribe to Headings
    const headingsCol = collection(db, `festivals/${yearId}/headings`);
    unsubs.push(
      onSnapshot(
        headingsCol,
        (snap) => {
          const headings: Heading[] = snap.docs.map((d) => d.data() as Heading);
          onUpdate({ headings });
        },
        onError
      )
    );

    // 2. Subscribe to Incomes
    const incomesCol = collection(db, `festivals/${yearId}/incomes`);
    unsubs.push(
      onSnapshot(
        incomesCol,
        (snap) => {
          const incomes: IncomeTransaction[] = snap.docs.map((d) => d.data() as IncomeTransaction);
          onUpdate({ incomes });
        },
        onError
      )
    );

    // 3. Subscribe to Expenses
    const expensesCol = collection(db, `festivals/${yearId}/expenses`);
    unsubs.push(
      onSnapshot(
        expensesCol,
        (snap) => {
          const expenses: ExpenseTransaction[] = snap.docs.map((d) => d.data() as ExpenseTransaction);
          onUpdate({ expenses });
        },
        onError
      )
    );

    // 4. Subscribe to Sequences
    const seqDocRef = doc(db, `festivals/${yearId}/sequences/accounting`);
    unsubs.push(
      onSnapshot(
        seqDocRef,
        (snap) => {
          if (snap.exists()) {
            const seq = snap.data();
            onUpdate({
              lastReceiptSeq: seq.lastReceiptSeq || 0,
              lastVoucherSeq: seq.lastVoucherSeq || 0,
            });
          }
        },
        onError
      )
    );
  } catch (err) {
    console.warn('Subscription setup notice:', err);
  }

  return () => {
    unsubs.forEach((u) => u());
  };
}
