/**
 * Firebase Client Initialization & Google Authentication Service
 * Manjankal Mar Shemavoon Desthuni Orthodox Syrian Church - 2026 Festival Accounts
 * Sole Super Admin: jijopjohn@gmail.com
 */

import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import {
  getAuth,
  Auth,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  signOut,
  onAuthStateChanged,
  User,
  connectAuthEmulator,
} from 'firebase/auth';
import {
  getFirestore,
  Firestore,
  connectFirestoreEmulator,
} from 'firebase/firestore';
import { SUPER_ADMIN_EMAIL, AuthSession, saveSession, clearSession } from '../utils/auth';

export interface FirebaseClientConfig {
  apiKey?: string;
  authDomain?: string;
  projectId?: string;
  storageBucket?: string;
  messagingSenderId?: string;
  appId?: string;
}

const clientEnv: Record<string, string | undefined> =
  typeof import.meta !== 'undefined' && (import.meta as any).env
    ? (import.meta as any).env
    : typeof process !== 'undefined' && process.env
    ? process.env
    : {};

// Read Vite client environment variables
export const firebaseClientConfig: FirebaseClientConfig = {
  apiKey: clientEnv.VITE_FIREBASE_API_KEY,
  authDomain: clientEnv.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: clientEnv.VITE_FIREBASE_PROJECT_ID,
  storageBucket: clientEnv.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: clientEnv.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: clientEnv.VITE_FIREBASE_APP_ID,
};

/**
 * Check whether Firebase Web client configuration is configured in environment
 */
export function isFirebaseClientConfigured(): boolean {
  return (
    typeof firebaseClientConfig.projectId === 'string' &&
    firebaseClientConfig.projectId.trim().length > 0 &&
    typeof firebaseClientConfig.apiKey === 'string' &&
    firebaseClientConfig.apiKey.trim().length > 0
  );
}

let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let db: Firestore | null = null;
const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

if (isFirebaseClientConfigured()) {
  try {
    app = getApps().length === 0 ? initializeApp(firebaseClientConfig as Record<string, string>) : getApp();
    auth = getAuth(app);
    db = getFirestore(app);

    // Optional: Connect to local emulators if explicitly requested in environment
    if (clientEnv.VITE_USE_FIREBASE_EMULATOR === 'true') {
      try {
        connectAuthEmulator(auth, 'http://127.0.0.1:9099', { disableWarnings: true });
        connectFirestoreEmulator(db, '127.0.0.1', 8088);
        console.log('Connected Firebase Web Client SDK to local emulators (Auth 9099, Firestore 8088)');
      } catch {
        // Emulator already connected
      }
    }
  } catch (err) {
    console.warn('Firebase client SDK initialization notice:', err);
  }
}

export { app, auth, db, googleProvider };

/**
 * Detect Android native environment (Capacitor Android or Android WebView)
 */
export function isAndroidNativeEnvironment(): boolean {
  if (typeof window === 'undefined') return false;
  const win = window as any;
  if (win.Capacitor?.isNativePlatform?.() && win.Capacitor?.getPlatform?.() === 'android') {
    return true;
  }
  const ua = (typeof navigator !== 'undefined' ? navigator.userAgent : '') || '';
  const isAndroid = /Android/i.test(ua);
  const isWebView = /wv/.test(ua) || /Version\/[\d.]+/i.test(ua);
  return isAndroid && (isWebView || window.location.protocol === 'capacitor:');
}

/**
 * Common authorization processing for authenticated Google User
 */
export async function processAuthenticatedUser(user: User): Promise<{
  success: boolean;
  user?: User;
  idToken?: string;
  session?: AuthSession;
  error?: string;
}> {
  // Strict email check
  if (!user.email || user.email.toLowerCase() !== SUPER_ADMIN_EMAIL.toLowerCase()) {
    if (auth) await signOut(auth);
    clearSession();
    return {
      success: false,
      error: `അനധികൃത ഇമെയിൽ വിലാസം: ${user.email}. ${SUPER_ADMIN_EMAIL} എന്ന സൂപ്പർ അഡ്മിൻ ഇമെയിലിന് മാത്രമേ പ്രവേശനമുള്ളൂ.`,
    };
  }

  if (!user.emailVerified) {
    if (auth) await signOut(auth);
    clearSession();
    return {
      success: false,
      error: 'ഗൂഗിൾ അക്കൗണ്ട് ഇമെയിൽ വേരിഫൈ ചെയ്തിട്ടില്ല. വേരിഫൈ ചെയ്ത ശേഷം വീണ്ടും ശ്രമിക്കുക.',
    };
  }

  const idToken = await user.getIdToken(true);

  // Bootstrap backend authorization record if endpoint exists
  try {
    await fetch('/api/auth/bootstrap', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${idToken}`,
      },
    });
  } catch {
    // Ignore if unmounted or already initialized
  }

  const session: AuthSession = {
    userEmail: SUPER_ADMIN_EMAIL,
    role: 'SUPER_ADMIN',
    loginTime: Date.now(),
    expiresAt: Date.now() + 30 * 60 * 1000,
    token: idToken,
  };

  saveSession(session);
  return { success: true, user, idToken, session };
}

/**
 * Super Admin Google Authentication
 * Supports:
 * - Desktop/Mobile Web: signInWithPopup
 * - Android WebView / Capacitor: signInWithRedirect (reliable on real devices)
 */
export async function signInWithGoogle(): Promise<{
  success: boolean;
  user?: User;
  idToken?: string;
  session?: AuthSession;
  error?: string;
  isRedirecting?: boolean;
}> {
  if (!auth) {
    return {
      success: false,
      error: 'ഫയർബേസ് കോൺഫിഗറേഷൻ പൂർത്തിയായിട്ടില്ല (Firebase is not configured). ദയവായി Netlify-ൽ എൻവയോൺമെന്റ് വേരിയബിളുകൾ നൽകുക.',
    };
  }

  try {
    // In Android Native / Capacitor WebView, signInWithPopup fails with disallowed_useragent.
    // Use signInWithRedirect for 100% reliable login on real Android devices.
    if (isAndroidNativeEnvironment()) {
      console.log('Android Native / Capacitor WebView detected: initiating signInWithRedirect');
      await signInWithRedirect(auth, googleProvider);
      return { success: true, isRedirecting: true };
    }

    // Standard Web Browser environment
    try {
      const cred = await signInWithPopup(auth, googleProvider);
      return await processAuthenticatedUser(cred.user);
    } catch (popupErr: any) {
      if (
        popupErr.code === 'auth/popup-blocked' ||
        popupErr.code === 'auth/cancelled-popup-request' ||
        popupErr.code === 'auth/operation-not-supported-in-this-environment'
      ) {
        console.log('Popup blocked, falling back to signInWithRedirect');
        await signInWithRedirect(auth, googleProvider);
        return { success: true, isRedirecting: true };
      }
      throw popupErr;
    }
  } catch (err: any) {
    console.error('Google Sign-In failed:', err);
    return {
      success: false,
      error: err.message || 'ഗൂഗിൾ ലോഗിൻ പരാജയപ്പെട്ടു.',
    };
  }
}

/**
 * Check and process redirect authentication result (Runs on app startup for Android)
 */
export async function checkRedirectAuthResult(): Promise<{
  handled: boolean;
  success?: boolean;
  user?: User;
  session?: AuthSession;
  error?: string;
}> {
  if (!auth) return { handled: false };
  try {
    const cred = await getRedirectResult(auth);
    if (!cred || !cred.user) {
      return { handled: false };
    }
    const processed = await processAuthenticatedUser(cred.user);
    return {
      handled: true,
      success: processed.success,
      user: processed.user,
      session: processed.session,
      error: processed.error,
    };
  } catch (err: any) {
    console.warn('Redirect auth check notice:', err);
    return { handled: true, success: false, error: err.message };
  }
}

/**
 * Sign out of Firebase and clear active session
 */
export async function signOutGoogle(): Promise<void> {
  if (auth) {
    try {
      await signOut(auth);
    } catch {
      // ignore
    }
  }
  clearSession();
}

/**
 * Auth state change observer
 */
export function onFirebaseAuthStateChanged(callback: (user: User | null) => void): () => void {
  if (!auth) {
    callback(null);
    return () => {};
  }
  return onAuthStateChanged(auth, callback);
}
